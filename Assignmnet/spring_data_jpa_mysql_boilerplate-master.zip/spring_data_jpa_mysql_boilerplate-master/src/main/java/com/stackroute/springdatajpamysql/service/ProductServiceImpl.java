package com.stackroute.springdatajpamysql.service;


import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

//Implement ProductService here
@Service
public class ProductServiceImpl implements ProductService {
    //Override all the methods here
    private final ProductRepo productRepo;

    public ProductServiceImpl(ProductRepo productRepo) {
        this.productRepo = productRepo;
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    @Override
    public List<Product> getAllProductsHavingPriceLessThan(double price) {
        return productRepo.findProductsLessThanPrice(price);
    }

    @Override
    public Product getProductById(long id) {
        return productRepo.findById(id).orElseThrow();
    }

    @Override
    public Product saveProduct(Product product) {
        return productRepo.save(product);
    }

    @Override
    public Product updateProduct(Product newproduct, long id) {
        Product oldproduct = productRepo.findById(id).orElseThrow();
        oldproduct.setName(newproduct.getName());
        oldproduct.setPrice(newproduct.getPrice());
        return productRepo.save(oldproduct);
    }

    @Override
    public String deleteProduct(long id) {
        productRepo.deleteById(id);
        return "Product Deleted";
    }

}
