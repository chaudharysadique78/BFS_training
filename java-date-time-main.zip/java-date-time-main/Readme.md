**LocalDate**

- LocalDate is an immutable class that represents Date with default format yyyy-MM-dd. 
- It is used to represent Date without time in ISO-8601 calendar system.

**LocalTime**

- LocalTime is an immutable class that represents time with default format hh:mm:ss:nnn.
- It is used to represent time without date in ISO-8601 calendar system.

**LocalDateTime**

- LocalDateTime is an immutable class that represents Date with time in ISO-8601 calendar system.
- It is used to represent date-time without time-zone in ISO-8601 calendar system.
- It is a combination of LocalDate and LocalTime.

**ZonedDateTime**

- ZonedDateTime is an immutable class that represents Date with time and timezone in ISO-8601 calendar system.
- It is used to represent date-time with a time-zone in ISO-8601 calendar system.
- It is a combination of LocalDateTime and ZoneId.

**OffsetDateTime**

- OffsetDateTime is an immutable class that represents Date with time and timezone with an offset from Greenwich/UTC time in ISO-8601 calendar system.
- It is used to represent date-time with a time-zone offset in ISO-8601 calendar system.

**Instant**

- Instant is an immutable class that represents Date with time in UNIX timestamp format.
- It is used to represent a point in time in UNIX timestamp format.

**Duration**

- Duration is an immutable class that represents a time span between two time instances in seconds and nanoseconds.
- It is used to represent a time span between two time instances in seconds and nanoseconds.

**Period**

- Period is an immutable class that represents a time span between two dates in years, months, and days.
- It is used to represent a time span between two dates in years, months, and days.