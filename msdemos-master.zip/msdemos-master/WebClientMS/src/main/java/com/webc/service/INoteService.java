package com.webc.service;

import com.webc.dto.NoteDto;

import reactor.core.publisher.Mono;

public interface INoteService 
{
	public NoteDto getNotes();
	public Mono<NoteDto> addNotes();

}
