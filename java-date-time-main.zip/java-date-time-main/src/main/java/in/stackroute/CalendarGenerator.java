package in.stackroute;

import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;

public class CalendarGenerator {
    public static void main(String[] args) {
        // Input year and month
        int year = 2024;
        int month = 6; // June

        generateCalendar(year, month);
    }

    public static void generateCalendar(int year, int month) {
        YearMonth yearMonth = YearMonth.of(year, month);
        int daysInMonth = yearMonth.lengthOfMonth();
        String monthName = yearMonth.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);

        System.out.println(monthName + " " + year);
        System.out.println("Su Mo Tu We Th Fr Sa");

        // Get the day of the week of the first day of the month
        int dayOfWeek = yearMonth.atDay(1).getDayOfWeek().getValue() % 7;

        // Print leading spaces for the first week
        for (int i = 0; i < dayOfWeek; i++) {
            System.out.print("   ");
        }

        // Print the days of the month
        for (int day = 1; day <= daysInMonth; day++) {
            System.out.printf("%2d ", day);

            // Move to the next line after Saturday
            if ((day + dayOfWeek) % 7 == 0) {
                System.out.println();
            }
        }
        System.out.println();
    }
}

