package in.stackroute.creational.absfct.button;

public class WindowsOSButton implements Button {
    @Override
    public void render() {
        System.out.println("WindowsOSButton is rendered");
    }

    @Override
    public void onClick() {
        System.out.println("WindowsOSButton is clicked");
    }
}
