package in.stackroute;

import java.time.*;
import java.time.format.DateTimeFormatter;


public class Main {
    public static void main(String[] args) {
        LocalDate date = LocalDate.of(2000, 6, 10);
        LocalDate currentDate = LocalDate.now();
        System.out.println("Date: " + date);
        System.out.println("Current Date: " + currentDate);

        LocalTime time24 = LocalTime.of(21, 30, 45);
        LocalTime currentTime = LocalTime.now();
        System.out.println("Time: " + time24);
        System.out.println("Current Time: " + currentTime);

        LocalDateTime dateTime = LocalDateTime.of(2000, 6, 10, 21, 30, 45);
        LocalDateTime currentDateTime = LocalDateTime.now();
        System.out.println("Date Time: " + dateTime);
        System.out.println("Current Date Time: " + currentDateTime);

        ZonedDateTime zonedDateTimeUS = ZonedDateTime.of(2000, 6, 10, 21, 30, 45, 0,
                    ZoneId.of("America/New_York"));
        ZonedDateTime zonedDateTime = ZonedDateTime.now();
        System.out.println("Zoned Date Time US: " + zonedDateTimeUS);
        System.out.println("Current Zoned Date Time: " + zonedDateTime);

        System.out.println();

        // Offset datetime - GMC offset
        OffsetDateTime now = OffsetDateTime.now();
        OffsetDateTime deviationFromUTC = OffsetDateTime.of(2000, 6, 10, 21, 30, 45, 0,
                ZoneOffset.ofHoursMinutes(5, 30));
        System.out.println("Offset Date Time: " + deviationFromUTC);
        System.out.println("Current Offset Date Time: " + now);

        DateTimeFormatter hourClockFormatter = DateTimeFormatter.ofPattern("HH:mm:ss a");
        System.out.println("Current Time in 12 hour clock: " + time24.format(hourClockFormatter));

        String usTimeString = "2023-06-10 10:30";
        String usTimeZone = "America/New_York";

        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss a z");

        // Read the Date, Time and Zone information from String and convert to ZonedDateTime
        LocalDateTime localDateTime = LocalDateTime.parse(usTimeString, inputFormatter);
        ZoneId usZoneId = ZoneId.of(usTimeZone);
        ZonedDateTime usZonedDateTime = ZonedDateTime.of(localDateTime, usZoneId);

        // Convert the US Time to IST Time
        ZoneId istTimeZone = ZoneId.of("Asia/Kolkata");
        ZonedDateTime istZonedDateTime = usZonedDateTime.withZoneSameInstant(istTimeZone);

        System.out.println();
        System.out.println();
        System.out.println("US Time: " + usZonedDateTime.format(outputFormatter));
        System.out.println("IST Time: " + istZonedDateTime.format(outputFormatter));

        Instant instant = Instant.now();
        Instant epoch = Instant.ofEpochMilli(31556926 * 1000L);
        System.out.println("Current Instant: " + instant);
        System.out.println("Epoch Instant: " + epoch);

        System.out.println();
        Duration duration = Duration.between(epoch, instant);
        System.out.println("Duration between Current and Epoch Instant: " + duration.toDays() + " days " +
                duration.toHours() + " hours " + duration.toMinutes() + " minutes " );

        System.out.println();
        Period period = Period.between(LocalDate.of(1970, 1, 1), LocalDate.now());
        System.out.println("Period between 1970 and Current Date: " + period.getDays() + " days " +
                period.getMonths() + " months " + period.getYears() + " years");

        LocalTime tokenTime = LocalTime.now();
        LocalTime tokenExpiryTime = tokenTime.plusMinutes(30);

        System.out.println();
        System.out.println("Token Time: " + tokenTime);
        System.out.println("Token Expiry Time: " + tokenExpiryTime);

        LocalDate productionDate = LocalDate.now();
        LocalDate expiryDate = productionDate.plusDays(2);

        System.out.println();
        System.out.println("Production Date: " + productionDate);
        System.out.println("Expiry Date: " + expiryDate);

        Clock clock = Clock.systemUTC();
        System.out.println("Current Time using Clock: " + clock.withZone(ZoneId.of("America/New_York")).instant());

        System.out.println();
        Clock utcClock = Clock.fixed(Instant.now(), ZoneId.of("UTC"));
        ZonedDateTime fixedTime = ZonedDateTime.now(utcClock);
        System.out.println("Fixed Time: " + fixedTime);

        Clock istClock = Clock.offset(Clock.systemUTC(), Duration.ofHours(5));
        ZonedDateTime adjustedTime = ZonedDateTime.now(istClock);
        System.out.println("Adjusted Time: " + adjustedTime);
    }
}