package com.natwest.cust.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.Map;

@SpringBootApplication
@RestController
@CrossOrigin("*")
public class Application {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @GetMapping("/details/{customerid}")
    public Map<String, Object> getDetails(@PathVariable int customerid) {
        String query = "SELECT * FROM transaction WHERE customerid = ?";
        return jdbcTemplate.queryForMap(query, customerid);
    }
    
    @ExceptionHandler(EmptyResultDataAccessException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<String> handleEmptyResultDataAccessException(EmptyResultDataAccessException ex) {
        return new ResponseEntity<>("Data not found for the provided ID", HttpStatus.NOT_FOUND);
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}