package in.stackroute.behavioral.observer;

public class Main {
    public static void main(String[] args) {

        WeatherInfo weatherData = new WeatherInfo(); // Subject
        WeatherChangeObserver currentConditionsDisplay = new WeatherChangeObserver(); // Observer
        weatherData.registerObserver(currentConditionsDisplay); // Register Observer

        weatherData.setWeatherData(30.0f, 65.0f, 30.4f);
        weatherData.setWeatherData(32.0f, 70.0f, 29.2f);
        weatherData.setWeatherData(28.0f, 90.0f, 29.2f);

        weatherData.removeObserver(currentConditionsDisplay); // Remove Observer

        weatherData.setWeatherData(25.0f, 80.0f, 29.2f);
    }
}
