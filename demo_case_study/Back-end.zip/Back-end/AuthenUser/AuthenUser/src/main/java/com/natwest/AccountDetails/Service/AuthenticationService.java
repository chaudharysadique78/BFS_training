package com.natwest.AccountDetails.Service;

import org.springframework.stereotype.Service;

import com.natwest.AccountDetails.Repo.UserRepository;

@Service
public class AuthenticationService {

    private final UserRepository userRepository;

    public AuthenticationService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean validateAuthenticationService(Integer customerId, String debitCardNo, Integer pinCode) {
        return userRepository.findByCustomeridAndDebitcardnoAndPincode(customerId, debitCardNo, pinCode) != null;
    }
}
