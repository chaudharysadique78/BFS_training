package com.natwest.cs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.natwest.cs.model.Complaint;
@Repository
public interface IComplaintRepo extends JpaRepository<Complaint, String> {

}
