import { Component } from '@angular/core';
import { user } from '../users';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrl: './template-driven-form.component.css'
})
export class TemplateDrivenFormComponent {
  user:user={
    id:1,
    name:"",
    email:"",
    phone:0
  }
  onSubmit(formdetails:any)
  {
    alert("Form Submitted");
    console.log(formdetails);

    //console.log("Phone no **********  "+this.user.phone)
  }
}
