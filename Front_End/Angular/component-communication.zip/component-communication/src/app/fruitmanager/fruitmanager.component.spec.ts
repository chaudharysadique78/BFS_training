import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FruitmanagerComponent } from './fruitmanager.component';

describe('FruitmanagerComponent', () => {
  let component: FruitmanagerComponent;
  let fixture: ComponentFixture<FruitmanagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FruitmanagerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FruitmanagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
