package in.stackroute.lambdas;

import in.stackroute.persons.Person;

import java.util.Arrays;
import java.util.List;
import java.util.function.*;
import java.util.stream.Collectors;

public class LambdaMain {

    public static void main(String[] args) {

        Supplier<String> supplier = () -> "Hello World!";
        System.out.println(supplier.get());

        Supplier<Person> personSupplier = () -> new Person("John", 25, "Male");
        System.out.println(personSupplier.get());

        List<String> names = List.of("John", "Doe", "Jane", "Doe");
        Consumer<String> printName = (name) -> System.out.println(name);
        names.forEach(printName);

        Predicate<String> namePredicate = (name) -> name.startsWith("J");
        names.stream().filter(namePredicate).forEach(printName);

        Function<String, Integer> lengthFunction = (name) -> name.length();
        System.out.println(lengthFunction.apply("John"));

        BiFunction<String, String, String> concatFunction = (name1, name2) -> name1 + " " + name2;
        System.out.println(concatFunction.apply("John", "Doe"));

        BiConsumer<String, Integer> lengthConsumer = (name, length) -> System.out.println(name + " has length " + length);
        BiConsumer<String, Integer> printConsumer = (s, i) -> System.out.println("String : " + s + " Integer: " + i);
        BiConsumer<String, Integer> joinedConsumer = lengthConsumer.andThen(printConsumer);
        joinedConsumer.accept("John", 4);

        // Create a list of 4 trainees
        List<Trainee> trainees = List.of(
                new Trainee("John", "Java"),
                new Trainee("Jane", "Python"),
                new Trainee("Doe", "Java"),
                new Trainee("Smith", "Java")
        );
    }

    private static void countingList() {
        List<Integer> myList = Arrays.asList(10, 15, 10, 15, 25, 25, 8, 49, 25, 98, 32);
        myList.stream()
                .collect(Collectors.groupingBy(n -> n, Collectors.counting()))
                .entrySet().forEach(System.out::println);
    }


}

class Trainee {
    private String name;
    private String course;

    public Trainee(String name, String course) {
        this.name = name;
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public String getCourse() {
        return course;
    }
}
