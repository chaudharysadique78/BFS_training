import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AboutComponent } from './about/about.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { VegeatableComponent } from './vegeatable/vegeatable.component';
import { FruitsComponent } from './fruits/fruits.component';
import { PotatoComponent } from './potato/potato.component';
import { TomatoComponent } from './tomato/tomato.component';
import { Veg0detailsComponent } from './veg0details/veg0details.component';

const routes: Routes = [
  {path:'',redirectTo:'/reg',pathMatch:'full'},
  {path:'login',component:LoginComponent},
  {path:'dash',component:DashboardComponent,children:[
       {path:'veg',component:VegeatableComponent,children:[
        {path:'pot',component:PotatoComponent},
        {path:'tom',component:TomatoComponent}
       ]},
       {path:'fruit',component:FruitsComponent}]},
  {path:'dash/veg/:id',component:Veg0detailsComponent},

  {path:'about',component:AboutComponent},
  {path:'reg',component:ReactiveFormComponent},
   {path:'**',component:PagenotfoundComponent},
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
