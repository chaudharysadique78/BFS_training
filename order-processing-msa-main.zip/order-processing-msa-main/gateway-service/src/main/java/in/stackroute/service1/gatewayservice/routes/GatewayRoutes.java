package in.stackroute.service1.gatewayservice.routes;

import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.ServerResponse;

import static org.springframework.cloud.gateway.server.mvc.handler.GatewayRouterFunctions.route;
import static org.springframework.cloud.gateway.server.mvc.handler.HandlerFunctions.http;
import static org.springframework.web.servlet.function.RequestPredicates.*;

//@Configuration(proxyBeanMethods = false)
public class GatewayRoutes {

    /**
     * Inventory routes
     * @return RouterFunction<ServerResponse>
     * /api/inventory/**
     */
    @Bean
    public RouterFunction<ServerResponse> inventoryRoutes() {
        return route("inventory_service")
                .route(path("/api/inventory/**"), http("http://localhost:9000"))
                .build();
    }
}
