package in.stackroute.bookservice.service;

import in.stackroute.bookservice.domain.Book;
import in.stackroute.bookservice.dto.AuthorDto;

import java.util.List;
import java.util.Optional;

public interface BookService {

    Optional<Book> getBookById(int id);

    Book saveBook(Book book);

    Book updateBook(Book book);

    void deleteBook(int id);

    List<Book> getAllBooks();

    List<Book> getBooksByAuthorName(String authorName);


}
