package in.stackroute;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Comparator;
import java.util.List;

public class LapTimingCalc {
    public static void main(String[] args) throws IOException {
        var athletes = loadData();
        var fastestAthlete = athletes.stream().min(Comparator.comparing(Athlete::getTotalTime)).orElseThrow();
        var fastestTotalTime = fastestAthlete.getTotalTime();
        System.out.println("Fastest athlete: " + fastestAthlete.getName() + " with time " + fastestTotalTime.toSeconds()
                + "." + fastestTotalTime.toMillis() + "s");
        athletes.stream()
                .map(athlete -> new AthleteLapDiff(athlete.getName(), fastestTotalTime,
                        athlete.getTotalTime().minus(fastestTotalTime).abs()))
                .toList().forEach(a -> System.out.println(a.name() + "\t" +
                        a.difference().toSeconds() + "." + a.difference().toMillis() + "s"));
    }

    static List<Athlete> loadData() throws IOException {
        return Files.readAllLines(Paths.get("lap_times.csv")).stream().skip(1)
                .map(line -> line.split(","))
                .map(data -> new Athlete(data[0], toDuration(data[1]), toDuration(data[2]), toDuration(data[3])))
                .toList();
    }

    static Duration toDuration(String time) {
        String[] parts = time.split("\\.");
        return Duration.ofSeconds(Long.parseLong(parts[0]), Long.parseLong(parts[1].substring(0, 3)));
    }
}


