package in.stackroute.behavioral.strategy.billing;

public class Customer {

    private String name;
    private boolean isPremiumCustomer;

    public Customer(String name, boolean isPremiumCustomer) {
        this.name = name;
        this.isPremiumCustomer = isPremiumCustomer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isPremiumCustomer() {
        return isPremiumCustomer;
    }

    public void setPremiumCustomer(boolean premiumCustomer) {
        isPremiumCustomer = premiumCustomer;
    }
}
