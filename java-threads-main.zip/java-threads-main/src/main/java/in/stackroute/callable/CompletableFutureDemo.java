package in.stackroute.callable;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFutureDemo {
    public static void main(String[] args) {

        CompletableFuture<Void> future = CompletableFuture.supplyAsync(() -> { // Stage 1
            System.out.println("Stage 1: Fetching data from the database");
            String data = fetchData();
            System.out.println("Stage 1: Data fetched from the database ");
            return data;
        }).thenApply(stage1Data -> { // Stage 2
            System.out.println("Stage 2: Processing data");
            Integer processedData = processData(stage1Data);
            System.out.println("Stage 2: Data processed");
            return processedData;
        }).thenApply(processedData -> { // Stage 3
            System.out.println("Stage 3: Transforming data");
            DataObject dataObject = transformData(processedData);
            System.out.println("Stage 3: Data transformed");
            return dataObject;
        }).thenAccept(dataObject -> { // Stage 4
            System.out.println("Stage 4: Saving data to the database");
            saveData(dataObject);
            System.out.println("Stage 4: Data saved to the database");
        });
        try {
            future.get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }

    }

    private static void saveData(DataObject dataObject) {
        System.out.println("Data saved: " + dataObject);
    }

    private static DataObject transformData(Integer processedData) {
        return new DataObject(processedData, "Transformed Data");
    }

    private static Integer processData(String stage1Data) {
        return Integer.parseInt(stage1Data);
    }

    private static String fetchData() {
        return "123";
    }
}
