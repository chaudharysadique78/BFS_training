package com.natwest.rs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.natwest.rs.model.Request;
import com.natwest.rs.service.IRequestService;

@CrossOrigin
@RestController
@RequestMapping("rapi/v1")
public class RequestController {
	
	@Autowired
	private IRequestService reqservice;
	private ResponseEntity<?> respentity;
	
	
	@PostMapping("/addreq")
	public ResponseEntity<?>saveDataRequestHandler(@RequestBody Request reqObj)
	
	{
		Request dataadded = this.reqservice.saveRequest(reqObj);
				
				respentity = new ResponseEntity(dataadded,HttpStatus.CREATED);
				return  respentity;
			}

@GetMapping("/getreq")
	public ResponseEntity<?>getAllRequestsHandler()
	
	{
		List<Request> reqdata = this.reqservice.getAllRequests();
		
		respentity = new ResponseEntity(reqdata,HttpStatus.CREATED);
		return  respentity;
	}
	
}
