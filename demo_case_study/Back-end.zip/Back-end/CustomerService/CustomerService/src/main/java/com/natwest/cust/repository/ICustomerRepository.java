package com.natwest.cust.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.natwest.cust.model.Customer;

@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer> {
	
	@Query("SELECT c FROM Customer c WHERE c.customerid = :customerid AND c.password = :password")
	public Customer validateUser(@Param("customerid") Integer customerid, @Param("password") String password);

	public Customer findByCustomerid(int customerid);
	

	

}
