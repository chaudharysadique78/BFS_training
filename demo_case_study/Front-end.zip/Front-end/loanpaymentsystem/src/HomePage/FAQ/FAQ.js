import React from 'react'
import { Accordion } from 'react-bootstrap'
import faq from '../Images/fq.JPG'
import Header from '../Header/Header'
import './FAQ.css'
import Footer from '../Footer/Footer'


export default function FAQ() {
  return (
<div>

<Header></Header>
    <div>
<br></br>
<br></br>
    <img className="pro-block" src={faq} alt="product1"></img>
    <br></br>
<br></br>
<br></br>
<br></br>
    </div>


    <div className="centered-content">

    <Accordion >
      <Accordion.Item eventKey="0" className="hed">
        <Accordion.Header >
          {" "}
          <b>When is my first loan payment due?</b>
        </Accordion.Header>
        <Accordion.Body>
        You can find the date of your first repayment in your loan confirmation letter. This also applies for customers who've recently applied for an Initial Repayment Holiday during their loan application.
<br></br>
<br></br>
If you applied for your loan online, the loan confirmation letter can be found in your online banking mailbox. 
<br></br>
<br></br>
If you applied for your loan in branch or telephony, the loan confirmation letter was given to you in person, or sent to you by post.
        </Accordion.Body>
      </Accordion.Item>
   </Accordion>
   <br></br>
   <Accordion >
      <Accordion.Item eventKey="1" className="hed" >
        <Accordion.Header >
          {" "}
          <b>What's my loan interest rate?</b>
        </Accordion.Header>
        <Accordion.Body>
        Interest is a charge on borrowing money and the interest rate is the size of this charge. You can find your interest rate on the original loan agreement, your confirmation letter as well as your annual statements. If you applied for your loan online, the loan confirmation letter can be found in your online banking mailbox.
        <br></br>
        <br></br>
Simply follow the link below, you will then be asked to fill in your details and we'll be in touch within 3 working days with your loan interest rate. You can choose to receive this by email, text or both.
        </Accordion.Body>
      </Accordion.Item>
   </Accordion>
   <br></br>
   <Accordion >
      <Accordion.Item eventKey="2" className="hed">
        <Accordion.Header >
          {" "}
          <b>
I'm struggling to pay my loan, what should I do?</b>
        </Accordion.Header>
        <Accordion.Body>
        If you've missed a payment or are worried about missing a future payment, please get in touch so we can help. 

Find out how we can support you and how to get in touch.
        </Accordion.Body>
      </Accordion.Item>
   </Accordion>
   <br></br>
   <Accordion >
      <Accordion.Item eventKey="3" className="hed">
        <Accordion.Header >
          {" "}
          <b>How do I request a copy of my existing loan agreement document?</b>
        </Accordion.Header>
        <Accordion.Body>
        To request a copy of your existing loan agreement document, you can write to us at:
        <br></br>
        <br></br>
NatWest
<br></br>
Loan Information Department
<br></br>
6th Floor, 1 Hardman Boulevard
<br></br>
Manchester
<br></br>
M3 3AQ

<br></br>
<br></br>
You'll need to include the following:
<br></br>
<br></br>
Full name and address including post code
<br></br>
Any sort code and account numbers
<br></br>
Previous addresses including post codes and dates you lived there
<br></br>
Dates of the loan, if known
<br></br>
Details of any changes and dates, if applicable

        </Accordion.Body>
      </Accordion.Item>
   </Accordion>
   <br></br>
   <Accordion >
      <Accordion.Item eventKey="4" className="hed">
        <Accordion.Header >
          {" "}
          <b>Did taking a 3-month loan repayment break or extension impact my credit score?</b>
        </Accordion.Header>
        <Accordion.Body>
        No, you don't need to worry. If your loan repayments were up-to-date when requesting your original repayment break, then we didn't report negative data to the credit reference agencies. However, this is provided you either repaid the missed payments in full at the end of your break or added your missed payments to your loan via an extension to your term. As notified, we will charge additional interest if the loan was extended, so you will pay more interest overall.

If your missed payments remain outstanding, contact us to agree next steps. Any outstanding arrears may impact your ability to obtain further credit from us.
        </Accordion.Body>
      </Accordion.Item>
   </Accordion>
   <br></br>
   <Accordion >
      <Accordion.Item eventKey="5" className="hed" >
        <Accordion.Header >
          {" "}
          <b>How did a Coronavirus repayment break affect my loan?</b>
        </Accordion.Header>
        <Accordion.Body>
        For customers impacted by coronavirus we offered the ability to take a 3 month repayment break, which could be extended to 6 months. This option finished on 31 July 2021.
        <br></br>
        At the end of the break we provided the following options:
<br></br>
1. If you were able to make your deferred repayments (known as arrears) in full at that time, no extra interest was charged.
<br></br>
2. If you are unable to make your deferred payments in full, and you were not in arrears at the time you applied for a repayment break, you could extend your loan term in order to maintain your existing monthly repayment amount.  As notified, we will charge additional interest if the loan term was extended, so you will pay more interest overall.
        </Accordion.Body>
      </Accordion.Item>
   </Accordion>
   <br></br>
   <Accordion >
      <Accordion.Item eventKey="6" className="hed" >
        <Accordion.Header >
          {" "}
          <b>How can I request a loan statement?</b>
        </Accordion.Header>
        <Accordion.Body>
        You can request your loan statement online. Simply follow the link below, you will then be asked to fill in your details and we will send your annual statement to your account address, you should receive this in 7 – 10 working days.
        </Accordion.Body>
      </Accordion.Item>
   </Accordion>
   <br></br>
   <br></br>
   <br></br>

</div>
<Footer></Footer>
</div>
  )
}