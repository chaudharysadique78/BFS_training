package in.stackroute;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLOutput;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDataLoader {

    public static void main(String[] args) throws IOException {
        loadEmployeeData();
    }

    static void loadEmployeeData() throws IOException {
        List<Employee> employees = new ArrayList<>(10);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z");
        Files.readAllLines(Paths.get("employees.csv"))
                .stream().skip(1)
                .forEach(line -> {
                    String[] data = line.split(",");
                    employees.add(new Employee(data[0], LocalDate.parse(data[1]), ZonedDateTime.parse(data[2], formatter)));
                });
        employees.forEach(Employee::print);
    }
}

