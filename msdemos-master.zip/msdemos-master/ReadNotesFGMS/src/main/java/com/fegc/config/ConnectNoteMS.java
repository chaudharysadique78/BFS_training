package com.fegc.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.fegc.model.Note;

@FeignClient(name = "NoteService")
public interface ConnectNoteMS {

	
	@GetMapping("/api/v1/allNotes")
	public List<Note> getAllNotes();
	
}
