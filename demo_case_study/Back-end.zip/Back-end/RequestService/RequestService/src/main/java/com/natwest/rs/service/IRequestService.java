package com.natwest.rs.service;


import java.util.List;


import com.natwest.rs.model.Request;

public interface IRequestService {
	
	public Request saveRequest(Request reqObj);
	
	public List<Request> getAllRequests();
}
