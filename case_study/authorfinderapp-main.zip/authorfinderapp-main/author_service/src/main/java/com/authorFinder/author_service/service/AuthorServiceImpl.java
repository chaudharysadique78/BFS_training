package com.authorFinder.author_service.service;

import com.authorFinder.author_service.entity.ApiResponse;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class AuthorServiceImpl implements AuthorService {

    @Value("${thirdparty.url}")
    String baseUrl;

    @Autowired
    RestTemplate restTemplate;
    @Override
    public ApiResponse fetchAuthor(String name) {
        val response = restTemplate.getForEntity(baseUrl + name, ApiResponse.class);
        System.out.println(response.getBody());
        return response.getBody();
    }
}
