package in.stackroute;

public class Customer implements Runnable {

    private int customerId;
    private Restaurant restaurant;
    private int groupSize;

    public Customer(int customerId, Restaurant restaurant, int groupSize) {
        this.customerId = customerId;
        this.restaurant = restaurant;
        this.groupSize = groupSize;
    }

    @Override
    public void run() {
        System.out.println("Customer " + customerId + " with group size " + groupSize + " arrived.");
        Table table;
        while ((table = restaurant.getAvailableTable(groupSize)) == null) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        restaurant.occupyTable(table);

        //Simulate dining time
        try {
            Thread.sleep((long) (Math.random() * 6000) + 1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        restaurant.leaveTable(table);
        System.out.println("Customer " + customerId + " with group size " + groupSize + " left.");

    }
}
