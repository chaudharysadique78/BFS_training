package in.stackroute.authorservice.dto;

import java.util.List;

public record AuthorDto(String id, String name, List<String> genres) {
}
