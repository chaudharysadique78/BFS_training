package in.stackroute;

import java.util.List;

public class BasicList<T> {

    private List<T> list;

    public BasicList(List<T> list) {
        this.list = list;
    }

    public void add(T element) {
        list.add(element);
    }

    public void remove(T element) {
        list.remove(element);
    }

    public void print() {
        for (T element : list) {
            System.out.println(element);
        }
    }

    public boolean contains(T element) {
        return list.contains(element);
    }
}
