package com.natwest.complimentform.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.natwest.complimentform.modal.ComplimentForm;
import com.natwest.complimentform.repository.CompFormRepository;

@Service
public class CompFormServiceImpl implements ICompFormService {

	 private final CompFormRepository compRepos;

	    @Autowired
	    public CompFormServiceImpl(CompFormRepository compRepos) {
	        this.compRepos = compRepos;
	    }

	@Override
	public ComplimentForm saveComplimentForm(ComplimentForm cObj) {
		// TODO Auto-generated method stub
		return compRepos.save(cObj);
	}

}
