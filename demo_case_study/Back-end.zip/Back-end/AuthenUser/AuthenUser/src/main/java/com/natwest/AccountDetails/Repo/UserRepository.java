package com.natwest.AccountDetails.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.natwest.AccountDetails.Model.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Integer> {
    UserEntity findByCustomeridAndDebitcardnoAndPincode(Integer customerid, String debitcardno, Integer pincode);
}
