import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import './Footer.css'

const Footer = () => {
  return (
    <footer className="ftr">
  <div className="container">
        <div className="row">
          <div className="col-md-4">
            <h4>Contact Us</h4>
            <p>Email: contact@natwest.com</p>
            <p>Phone: 1-800-123-4567</p>
          </div>
          
          <div className="col-md-4">
            <h4>Quick Links</h4>
            <ul>
              <li><a href="/">Home</a></li>
              <li><a href="/about">About Us</a></li>
              <li><a href="/faq">FAQs</a></li>
         
            </ul>
          </div>
          <div className="col-md-4">
            <h4>Follow Us</h4>
            <ul>
              <li><a href="https://www.facebook.com/NatWest/"><i className="fab fa-facebook"></i> Facebook</a></li>
              <li><a href="https://twitter.com/NatWestGroup"><i className="fab fa-twitter"></i> Twitter</a></li>
              <li><a href="https://uk.linkedin.com/company/natwest?trk=affiliated-pages"><i className="fab fa-linkedin"></i> LinkedIn</a></li>
              {/* <li><a href="#"><i className="fab fa-instagram"></i> Instagram</a></li> */}
            </ul>
          </div>
        </div>
      </div>
      <div className="linee">
        &copy; {new Date().getFullYear()} National Westminster Bank plc 2023.Registered Office:250 Bishopsgate, London, EC2M 4AA.
      </div>
    </footer>
  );
};

export default Footer;