package com.natwest.rs.model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Request {
	
	@Id
	private String customerid;
	private String name;
	private String email;
	private String phoneno;
	private String requestfor;
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getRequestfor() {
		return requestfor;
	}
	public void setRequestfor(String requestfor) {
		this.requestfor = requestfor;
	}
	@Override
	public String toString() {
		return "Request [customerid=" + customerid + ", name=" + name + ", email=" + email + ", phoneno=" + phoneno
				+ ", requestfor=" + requestfor + "]";
	}
	
	
	
	}
	

