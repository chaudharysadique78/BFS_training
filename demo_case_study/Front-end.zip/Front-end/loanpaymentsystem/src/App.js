
import './App.css';
import TransactionHistory from './Transaction/TransactionHistory/TransactionHistory';
import { BrowserRouter, Routes, Route } from "react-router-dom"
import Home from './HomePage/Home/Home';
import LoginForm from './Loggin/Login/Login';
import Registration from './Registration/Registration';
import AuthenticationForm from './Authentication/AuthenticationForm'
import AcDetails from './WelcomePage/AcDetails/AcDetails';
import Paymentapp from './Bankingpayapp/Paymentapp'
import Fullpayment from './Fullpaymentapp/Fullpayment';
import Reviews from './HomePage/Reviews/Reviews'
import FAQ from './HomePage/FAQ/FAQ';
import Complaint from './Shivani/Complaint/Complaint';
import Trial from './Shivani/Trial/Trial';
import Aboutus from './Aboutus/Aboutus';


function App() {
  return (
    <div className="App">

<BrowserRouter>      
<Routes>
<Route path="/" element={<Home />} />
<Route path='/logn' element={<LoginForm/>}/>
<Route path='/register' element={<AuthenticationForm/>}/>
<Route path='/reg2' element={<Registration/>}/>
<Route path='/dash' element={<AcDetails/>}/>
<Route path='/PartialPayment' element={<Paymentapp/>}/>
<Route path='/his' element={<TransactionHistory/>}/>
<Route path='/Fullpayment' element={<Fullpayment/>}/>
<Route path='/reviews' element={<Reviews/>}/>
<Route path='/faq' element={<FAQ/>}/>
<Route path='/Request' element={<Trial/>}/>
<Route path='/Complaint' element={<Complaint/>}/>
<Route path='/Aboutus' element={<Aboutus/>}/>



</Routes>
</BrowserRouter> 


      
     
    </div>
  );
}


export default App;
