package com.natwest.complimentform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplimentFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplimentFormApplication.class, args);
	}

}
