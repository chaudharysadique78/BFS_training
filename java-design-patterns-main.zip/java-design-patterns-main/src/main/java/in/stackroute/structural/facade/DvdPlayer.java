package in.stackroute.structural.facade;

public class DvdPlayer {
    public void on() {
        System.out.println("DvdPlayer is on");
    }

    public void off() {
        System.out.println("DvdPlayer is off");
    }

    public void play(String movieName) {
        System.out.println("DvdPlayer is playing: " + movieName);
    }
}
