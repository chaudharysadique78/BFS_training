import React, { useEffect, useState } from 'react';
import swal from 'sweetalert';
import Header from '../Loggin/Header/Header';
import Footr from '../Loggin/Footr/Footr';
import { useNavigate } from "react-router-dom";
import './Registration.css'; // Import your CSS file here

export default function Registration() {
    let navigate = useNavigate();
    function regg(){
      navigate("/logn")}
  const [userData, setUserData] = useState({
    customerid: '',
    name: '',
    dateofbirth: '',
    emailid: '',
    address: '',
    accountno: '',
    sortcode: '',
    mobileno: '',
    password: '',
    confirmPassword: '',
  });

  useEffect(() => {
    const storedCustomerId = localStorage.getItem('customerId');

    if (storedCustomerId) {
      fetch(`http://localhost:8080/capi/v1/customers/${storedCustomerId}`)
        .then((response) => response.json())
        .then((data) => {
          setUserData({
            ...data,
            password: '',
            confirmPassword: '',
          });
        })
        .catch((error) => console.error('Error fetching user data:', error));
    }
  }, []);

  const handleFormSubmit = (event) => {
    event.preventDefault();
    const storedCustomerId = localStorage.getItem('customerId');

    if (userData.password === userData.confirmPassword) {
      fetch(`http://localhost:8080/capi/v1/updateCustomer/${storedCustomerId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ password: userData.password }),
      })
        .then((res) => {
          if (res.status === 200) {
            console.log('Password Updated Successfully');
            swal('Password Updated Successfully', { icon: 'success' });
            localStorage.removeItem('customerId');
            navigate("/logn")
          } else {
            console.error('Password Update Failed');
            swal('Password Update Failed', { icon: 'error' });
          }
        })
        .catch((error) => {
          console.error('Password Update Failed:', error);
          swal('Password Update Failed', { icon: 'error' });
        });
    } else {
      swal('Password and Confirm Password do not match', { icon: 'error' });
    }
  };

  const reg = () => {
    // Add your logic here for redirection
  };

  return (
    <section className="register">
      <Header />
      <br/>
      <div className="container">
        <div className="row">
          <section className="register-section">
            <div className="register-container">
              <div className="register-box">
                <h2 className="register-heading">Register for Online Banking</h2>
              </div>
            </div>
            <br/>
            <div className="register-description">
              <h5 className="register-description-text">
                You are all set for Online Banking
                <br />
                <br />
               Please create your password for Online Banking
                <br /> <br/>
              </h5>
            </div>

            <div className="register-form-container">
              <div className="register-form">
                <form onSubmit={handleFormSubmit}>
                  <p className="register-field">Customer ID: {userData.customerid}</p>
                  <p className="register-field">Name: {userData.name}</p>
                  <p className="register-field">Date of Birth: {userData.dateofbirth}</p>
                  <p className="register-field">Email: {userData.emailid}</p>
                  <p className="register-field">Address: {userData.address}</p>
                  <p className="register-field">Account Number: {userData.accountno}</p>
                  <p className="register-field">Sort Code: {userData.sortcode}</p>
                  <p className="register-field">Mobile Number: {userData.mobileno}</p>
                  <input
                    type="password"
                    id="password"
                    value={userData.password}
                    onChange={(e) => setUserData({ ...userData, password: e.target.value })}
                    placeholder="Enter your password"
                  /> <p>         </p>
                  <input
                    type="password"
                    id="confirmpassword"
                    value={userData.confirmPassword}
                    onChange={(e) => setUserData({ ...userData, confirmPassword: e.target.value })}
                    placeholder="Confirm your password"
                  />
                  <button type="submit" className="register-button">
                    Submit
                  </button>
                </form>
                <div className="register-form-description">
                  <button type="buuton" onClick={regg} className="register-button-secondary">
                    Click here if Already Registered
                  </button>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
      <Footr />
    </section>
  );
}



