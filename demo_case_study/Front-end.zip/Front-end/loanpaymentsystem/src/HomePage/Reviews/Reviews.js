import React from 'react'
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import './Reviews.css';
import Header from '../Header/Header';
import { Container } from 'react-bootstrap';
import Footer from '../Footer/Footer';


export default function Reviews() {
  return (
    <div>
<Header></Header>
    <div>
        <br></br>
<br></br>
<br></br>

<div className="co">

<h3 className="he">
<br></br>
<br></br>
We smile, when you smile 😊
<br></br>
<br></br>
 More than 90% customer rated NatWest Bank Services 5 star 
 <br></br>
 <span className="y">&#9733;</span>
 <span className="y">&#9733;</span>
 <span className="y">&#9733;</span>
 <span className="y">&#9733;</span>
 <span className="y">&#9733;</span>
 {/* <i className="fas fa-star"></i>
 <i className="fas fa-star"></i>
 <i className="fas fa-star"></i>
 <i className="fas fa-star"></i>
 <i className="fas fa-star"></i> */}

 <br></br>
  {/* &#9733;  &#9733;  &#9733;  &#9733;  &#9733; */}


<br></br>
<br></br>
<br></br>
</h3>

</div>

  <div className="mar">
    <Row>
        <Col>
    <Card className="purple-card">
    <div className="image-top-center  ">
    <Card.Img variant="top " src="IMG-20230929-WA0011.jpg"  alt="Card image "  className="smaller-image"/>
    </div>
     <Card.Body>
      <Card.Title>Kanchan Mahara </Card.Title>
      <h6>27sep2023</h6>
      <Card.Text>
      Thanks for your support and I really admire your help, understanding related to the issue and follow up with concerned team. It's very nice interaction experience with Natwest Customer Support Team specially "Fauziya M". Thanks again for your help, have a great day.

      </Card.Text>
    </Card.Body>
  </Card>
  </Col>
  <Col>
  <Card className="purple-card">
    <div className="image-top-center">
    <Card.Img variant="top" src="sunil.JPG" alt="Card image"  className="smaller-image"/>
    </div>
    <Card.Body>
      <Card.Title>Sunil Kumar</Card.Title>
      <h6>15sep2023</h6>
      <Card.Text>
      Great service, I have received the foreclosure letter now, I wanted to close the loan by making RTGS payment, your service executive Ashi gave a very good service and fast service too. I will also give her a rating of 10 when I will receive the feedback
      </Card.Text>

    </Card.Body>
  </Card>
  </Col>
  <Col>
  <Card className="purple-card">
    <div className="image-top-center">
    <Card.Img variant="top" src="shivani.JPG" alt="Card image"  className="smaller-image"/>
    </div>
    <Card.Body>
      <Card.Title>Shivani Budhiraja</Card.Title>
      <h6>07sep2023</h6>
      <Card.Text>
       It was a wonderful experience , instant solution , all my queries being patiently resolved its the best bank services ever . I am happy with your response, I will mail again if I have any problem again in the future.Thanks

      </Card.Text>
      
    </Card.Body>
  </Card>
  </Col>
  
  </Row>
  </div>


<br></br>
<br></br>
<br></br>
</div>

<div className="mar">
    <Row>
        <Col>
    <Card className="purple-card">
    <div className="image-top-center  ">
    <Card.Img variant="top " src="veenus.JPG"  alt="Card image "  className="smaller-image "/>
    </div>
     <Card.Body>
      <Card.Title>Veenus Kumar </Card.Title>
      <h6>15aug2023</h6>
      <Card.Text>
      Thanks for your support and I really admire your help, understanding related to the issue and follow up with concerned team. It's very nice interaction experience with Natwest Customer Support Team specially "Fauziya M". Thanks again for your help, have a great day.

      </Card.Text>
    </Card.Body>
  </Card>
  </Col>
  <Col>
  <Card className="purple-card">
    <div className="image-top-center">
    <Card.Img variant="top" src="ayush.JPG" alt="Card image"  className="smaller-image"/>
    </div>
    <Card.Body>
      <Card.Title>Aayush Bhandari</Card.Title>
      <h6>15sep2023</h6>
      <Card.Text>
      Great service, I have received the foreclosure letter now, I wanted to close the loan by making RTGS payment, your service executive Ashi gave a very good service and fast service too. I will also give her a rating of 10 when I will receive the feedback
      </Card.Text>

    </Card.Body>
  </Card>
  </Col>
  <Col>
  <Card className="purple-card">
    <div className="image-top-center">
    <Card.Img variant="top" src="Sahil.jpg" alt="Card image"  className="smaller-image"/>
    </div>
    <Card.Body>
      <Card.Title>Sahil Pandey</Card.Title>
      <h6>07sep2023</h6>
      <Card.Text>
      . I want to express my sincere gratitude to Rakesh for his exceptional support throughout the process. His prompt attention, dedication, and diligent efforts in initiating the address update process were truly commendable. 
      </Card.Text>
      
    </Card.Body>
  </Card>
  </Col>
  
  </Row>
  
  </div>

<br></br>
<br></br>
<br></br>


<div className="mar">
    <Row>
        <Col>
    <Card className="purple-card">
    <div className="image-top-center  ">
    <Card.Img variant="top " src="Gaurav.jpg"  alt="Card image "  className="smaller-image "/>
    </div>
     <Card.Body>
      <Card.Title>Gaurav</Card.Title>
      <h6>27sep2023</h6>
      <Card.Text>
      Thanks for your support and I really admire your help, understanding related to the issue and follow up with concerned team. It's very nice interaction experience with Natwest Customer Support Team specially "Fauziya M". Thanks again for your help, have a great day.

      </Card.Text>
    </Card.Body>
  </Card>
  </Col>
  <Col>
  <Card className="purple-card">
    <div className="image-top-center">
    <Card.Img variant="top" src="Preeti.jpeg" alt="Card image"  className="smaller-image"/>
    </div>
    <Card.Body>
      <Card.Title>Preeti Aggarwal</Card.Title>
      <h6>15sep2023</h6>
      <Card.Text>
      Great service, I have received the foreclosure letter now, I wanted to close the loan by making RTGS payment, your service executive Ashi gave a very good service and fast service too. I will also give her a rating of 10 when I will receive the feedback
      </Card.Text>

    </Card.Body>
  </Card>
  </Col>
  <Col>
  <Card className="purple-card">
    <div className="image-top-center">
    <Card.Img variant="top" src="Shekhar.png" alt="Card image"  className="smaller-image"/>
    </div>
    <Card.Body>
      <Card.Title>Shekhar Kumar Tripathi</Card.Title>
      <h6>07sep2023</h6>
      <Card.Text>
      Great service, I have received the foreclosure letter now, I wanted to close the loan by making RTGS payment, your service executive Ashi gave a very good service and fast service too. I will also give her a rating of 10 when I will receive the feedback
      </Card.Text>
      
    </Card.Body>
  </Card>
  </Col>
  </Row>
  </div>

<br></br>
<br></br>
<br></br>
<Footer></Footer>
</div>


);
}