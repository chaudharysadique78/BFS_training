package in.stackroute.generics;

public class Engineer extends Employee{

    private String specialization;

    public Engineer() {
    }

    public Engineer(String name, int id, String specialization) {
        super(name, id);
        this.specialization = specialization;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    @Override
    public String toString() {
        return super.toString() + " Engineer{" + "specialization=" + specialization + '}';
    }


}
