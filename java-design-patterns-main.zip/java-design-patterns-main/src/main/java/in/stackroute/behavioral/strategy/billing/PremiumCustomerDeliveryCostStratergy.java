package in.stackroute.behavioral.strategy.billing;

public class PremiumCustomerDeliveryCostStratergy implements DeliveryCostStratergy {
    @Override
    public double calculateDeliveryCost(double distance) {
        return distance * 5;
    }
}
