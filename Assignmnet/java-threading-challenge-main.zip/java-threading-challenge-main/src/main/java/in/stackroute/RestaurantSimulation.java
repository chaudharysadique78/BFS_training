package in.stackroute;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class RestaurantSimulation {
    public static void main(String[] args) {
        int noOfTables = 5;
        int capacityPerTable = 4;
        Restaurant restaurant = new Restaurant(noOfTables, capacityPerTable);

        ExecutorService executorService = Executors.newCachedThreadPool();
        // Suppose 20 customers arriving
        for (int i = 1; i <= 20; i++) {
            int groupSize = (int) Math.random() * capacityPerTable + 2;
            Customer customer = new Customer(i, restaurant, groupSize);
            executorService.execute(customer);

            try {
                //Random interval between customer arrival
                Thread.sleep((int) (Math.random() * 2000) + 500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            executorService.shutdown();
            try {
                executorService.awaitTermination(1, TimeUnit.HOURS);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}