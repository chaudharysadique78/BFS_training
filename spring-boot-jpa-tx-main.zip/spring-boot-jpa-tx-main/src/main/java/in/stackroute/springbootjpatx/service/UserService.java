package in.stackroute.springbootjpatx.service;

import in.stackroute.springbootjpatx.domain.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    Optional<User> findByEmail(String email);

    Optional<User> findWithCredentials(String email, String password);

    User save(User user);

    List<User> findAll();
}
