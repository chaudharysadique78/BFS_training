package in.stackroute;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {

    private List<Table> tables;

    public Restaurant(int numTables, int tableCapacity) {
        tables = new ArrayList<>();
        for (int i = 1; i <= numTables; i++) {
            tables.add(new Table(i, tableCapacity));
        }
    }

    public Table getAvailableTable(int requiredCapacity) {
        return null;
    }

    public void occupyTable(Table table) {
    }

    public void leaveTable(Table table) {
    }
}
