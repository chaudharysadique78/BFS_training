Insert into inventory (id, product_id, quantity) values (1, 1, 100);
Insert into inventory (id, product_id, quantity) values (2, 2, 100);
Insert into inventory (id, product_id, quantity) values (3, 3, 100);
Insert into inventory (id, product_id, quantity) values (4, 4, 100);
Insert into inventory (id, product_id, quantity) values (5, 5, 100);