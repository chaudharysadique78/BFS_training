import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TwowybindingComponent } from './twowybinding.component';

describe('TwowybindingComponent', () => {
  let component: TwowybindingComponent;
  let fixture: ComponentFixture<TwowybindingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TwowybindingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TwowybindingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
