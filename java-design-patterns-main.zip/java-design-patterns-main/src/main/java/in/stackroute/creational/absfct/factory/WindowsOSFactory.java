package in.stackroute.creational.absfct.factory;

import in.stackroute.creational.absfct.button.Button;
import in.stackroute.creational.absfct.button.WindowsOSButton;
import in.stackroute.creational.absfct.dialog.Dialog;
import in.stackroute.creational.absfct.dialog.WindowsOSDialog;

public class WindowsOSFactory implements ComponentFactory {
    @Override
    public Button createButton() {
        return new WindowsOSButton();
    }

    @Override
    public Dialog createDialog() {
        return new WindowsOSDialog();
    }
}
