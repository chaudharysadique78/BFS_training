import { Component } from '@angular/core';
import { Fruit } from '../../../fruit';

@Component({
  selector: 'app-fruitmanager',
  templateUrl: './fruitmanager.component.html',
  styleUrl: './fruitmanager.component.css'
})
export class FruitmanagerComponent {

  fruits:Fruit[]=[
    {name:'Apple',color:'Red',price:100},
    {name:'Banana',color:'Yellow',price:50},
    {name:'Grapes',color:'Green',price:150},
    {name:'Orange',color:'Orange',price:80}
  ];
  search:string='';
  fruitsTemp:Fruit[]=this.fruits;

 
  recieveSearchText(searchTest:any)
  {
    if(searchTest=='')
    {
      this.fruits=this.fruitsTemp;
    }
    else
    {
    this.fruits=this.fruits.filter(fruit=>fruit.name==searchTest);
    }
  }

}
