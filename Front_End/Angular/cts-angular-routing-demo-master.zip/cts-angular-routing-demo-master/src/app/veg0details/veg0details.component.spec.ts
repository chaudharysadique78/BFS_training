import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Veg0detailsComponent } from './veg0details.component';

describe('Veg0detailsComponent', () => {
  let component: Veg0detailsComponent;
  let fixture: ComponentFixture<Veg0detailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Veg0detailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Veg0detailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
