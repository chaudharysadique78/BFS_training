import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-veg0details',
  templateUrl: './veg0details.component.html',
  styleUrl: './veg0details.component.css'
})
export class Veg0detailsComponent {
constructor(private activateRoute:ActivatedRoute) { }
id:number=0;
ngOnInit() {
this.activateRoute.params.subscribe(params=>{
this.id=params['id'];
alert(this.id);
});
}
}