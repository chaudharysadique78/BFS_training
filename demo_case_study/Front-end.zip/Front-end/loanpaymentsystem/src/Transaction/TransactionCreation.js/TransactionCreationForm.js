import React, { useState } from 'react';
import './Transcre.css';

const TransactionCreationForm = ({ addTransaction }) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState('Debit'); // Assuming you have a type field

  const handleSubmit = (e) => {
    e.preventDefault();
    const newTransaction = {
      description,
      amount: parseFloat(amount), // Ensure amount is a number
      type, // Debit or Credit based on user selection
    };
    addTransaction(newTransaction);
    setDescription('');
    setAmount('');
    setType('Debit'); // Reset type to 'Debit' for a new transaction
  };

  return (
    <div className="transaction-creation-form">
      <h2>Create a Transaction</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Description:</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        <div>
          <label>Amount:</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>
        <div>
          <label>Type:</label>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="Debit">Debit</option>
            <option value="Credit">Credit</option>
          </select>
        </div>
        <button type="submit">Add Transaction</button>
      </form>
    </div>
  );
};

export default TransactionCreationForm;