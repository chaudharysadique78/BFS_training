import React, { useState, useEffect } from 'react';
import { Accordion, AccordionSummary, AccordionDetails, Typography } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import './AccountsComponent.css';
import DashHeader from '../WelcomePage/DashHeader/DashHeader';
import Footer from '../HomePage/Footer/Footer';

const AccountsComponent = () => {
    const [accountDetails, setAccountDetails] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchAccountDetails = async () => {
            try {
                const responseCurrent = await fetch('http://localhost:8086/dashboard/api/accounts');
                const responseLoan = await fetch('http://localhost:8086/dashboard/api/loans');

                if (!responseCurrent.ok || !responseLoan.ok) {
                    throw new Error('Network response was not ok');
                }

                const dataCurrent = await responseCurrent.json();
                const dataLoan = await responseLoan.json();

                setAccountDetails({ currentAccounts: dataCurrent, loanAccounts: dataLoan });
            } catch (error) {
                setError('Error fetching data. Please try again later.');
            }
        };
        fetchAccountDetails();
    }, []);

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div>
            
            <DashHeader/>
        <div className="container">
            <div className="index">
                <Typography variant="h2">Banking Details</Typography>
                <ul>
                    <li>Personal Details</li>
                    <li>Account Summary</li>
                    <li>Transaction History</li>
                    <li>Net Banking Details</li>
                    <li>Settings</li>
                </ul>
            </div>
            <div className="content">
                <Typography variant="h1">Bank Account Details</Typography>
                <Typography variant="h2">Accounts</Typography>
                {accountDetails.currentAccounts && accountDetails.loanAccounts ? (
                    <div>
                        {accountDetails.currentAccounts.map((account) => (
                            <Accordion key={`current-${account.id}`}>
                                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                                    <Typography>{account.accountType}</Typography>
                                </AccordionSummary>
                                <AccordionDetails>
                                    <Typography>Balance: {account.balance}</Typography>
                                    <Typography>Account Number: {account.accountNumber}</Typography>
                                    <Typography>Sort Code: {account.sortCode}</Typography>
                                    
                                </AccordionDetails>
                              
                            </Accordion>
                            
                        ))}
                        {accountDetails.loanAccounts.map((account) => (
                            <Accordion key={`loan-${account.id}`}>
                                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                                    <Typography>{`Loan - ${account.id}`}</Typography>
                                </AccordionSummary>
                                <AccordionDetails>
                                    <Typography>Loan Amount: {account.loanAmount}</Typography>
                                    <Typography>Account Number: {account.accountNumber}</Typography>
                                    <Typography>Sort Code: {account.sortCode}</Typography>
                                </AccordionDetails>
                            </Accordion>
                        ))}
                    </div>
                ) : (
                    <div>Loading...</div>
                )}
            </div>
        </div>
        <Footer/>
        </div>
    );
};

export default AccountsComponent;
