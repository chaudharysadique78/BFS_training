package in.stackroute.persons;

import java.util.ArrayList;
import java.util.List;

public class SocialNetwork {

    private List<Person> roster;

    public SocialNetwork() {
        roster = new ArrayList<>();
        roster.add(new Person("John", 25, "MALE"));
        roster.add(new Person("Jane", 24, "FEMALE"));
        roster.add(new Person("Jack", 18, "MALE"));
    }

    // MONTH -> J

    public void print(CheckPerson filter) {
        for (Person p : roster) {
            if (filter.test(p)) {
                System.out.println(p);
            }
        }
    }

    public void print(List<CheckPerson> filters) {
        roster.parallelStream()
                .filter(p -> filters.stream().allMatch(f -> f.test(p)))
                .forEach(System.out::println);
    }
}
