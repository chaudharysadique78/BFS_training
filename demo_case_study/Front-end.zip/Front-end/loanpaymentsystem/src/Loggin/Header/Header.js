import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import logo from '../Images/nwlogo.svg'
import './Header.css';



export default function alHeader(){
    return(
        <div>
        <Navbar expand="lg" className="navcol">
      <Container >
      <img className="logo" src={logo} alt="Image One"/>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <div className="logbtn"> 
            <Nav.Link href="/logn"><button className="b2" >Login </button></Nav.Link>
            </div>
            <div className="logbtn"> 
            <Nav.Link href="/register"><button className="b2" >Register </button></Nav.Link>
            </div>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>

    
        
        </div>
        

    )

}