package com.sr.service.registery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
