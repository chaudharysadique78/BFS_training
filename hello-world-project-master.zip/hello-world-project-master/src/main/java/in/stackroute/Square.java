package in.stackroute;

public final class Square extends Rectangle  {
}
