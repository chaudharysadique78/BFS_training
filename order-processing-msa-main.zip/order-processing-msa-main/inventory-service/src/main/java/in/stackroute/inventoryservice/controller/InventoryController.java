package in.stackroute.inventoryservice.controller;

import in.stackroute.inventoryservice.model.Inventory;
import in.stackroute.inventoryservice.service.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/inventory")
@Tag(name = "Inventory API", description = "Inventory API for managing products")
public class InventoryController {

    private final InventoryService inventoryService;

    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @GetMapping("/{productId}")
    @Operation(summary = "Get inventory by product ID", description = "Get inventory by product ID")
    @ApiResponse(responseCode = "200", description = "Successful operation")
    @Parameter(name = "productId", description = "Product ID", required = true)
    public Inventory getInventoryByProductId(@PathVariable Long productId) {
        return inventoryService.getInventoryByProductId(productId);
    }

    @PostMapping
    @Operation(summary = "Add inventory", description = "Add inventory")
    @ApiResponse(responseCode = "200", description = "Successful operation")
    @Schema(implementation = Inventory.class)
    @Parameter(name = "inventory", description = "Inventory object", required = true)
    public Inventory updateInventory(@RequestBody Inventory inventory) {
        return inventoryService.updateInventory(inventory);
    }
}
