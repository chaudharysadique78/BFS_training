package com.natwest.cust.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.cust.model.Customer;
import com.natwest.cust.service.ICustomerService;

import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Customer", description = "The Customer Service")
@CrossOrigin("*")
@RestController
@RequestMapping("capi/v1")
public class CustomerController {
	
	@Autowired
	private ICustomerService custservice;
	private ResponseEntity<?> respentity;
	
	@PostMapping("/addcust")
	public ResponseEntity<?>saveCustomerDataRequestHandler(@RequestBody Customer custObj)
	
	{
Customer dataadded = this.custservice.saveCustomer(custObj);
		
		respentity = new ResponseEntity(dataadded,HttpStatus.CREATED);
		return  respentity;
	}
	
	
	@GetMapping("/getcust")
	public ResponseEntity<?>getAllCustomersDataRequestHandler()
	{
		List<Customer> custdata = this.custservice.getAllCustomers();
		
		respentity = new ResponseEntity(custdata,HttpStatus.CREATED);
		return  respentity;
	}
	
	 @GetMapping("/customers/{customerid}")
	    public ResponseEntity<Customer> getCustomerById(@PathVariable int customerid) {
	        Customer customer = custservice.findnamebycustid(customerid);
	        if (customer != null) {
	            return new ResponseEntity<>(customer, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }
	
	 
	 @PutMapping("/updateCustomer/{customerId}")
	 public ResponseEntity<?> updateCustomerPasswordHandler(@RequestBody Customer custObj, @PathVariable int customerId) {
	     Customer updatedCustomer = this.custservice.updateCustomer(custObj, customerId);

	     if (updatedCustomer != null) {
	         return new ResponseEntity<>(updatedCustomer, HttpStatus.OK);
	     } else {
	         return new ResponseEntity<>("Some Internal Error Occurred while updating the Data.", HttpStatus.CONFLICT);
	     }
	 }


	
	
	
	
}
