package org.example;

public class Square implements Shape{
    public void draw() {
        System.out.println("Draw Square");

    }
}
