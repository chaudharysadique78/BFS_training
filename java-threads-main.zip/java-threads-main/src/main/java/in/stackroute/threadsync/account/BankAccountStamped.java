package in.stackroute.threadsync.account;

import java.util.concurrent.locks.StampedLock;

public class BankAccountStamped {

    /**
     * StampedLock is a specialized lock in Java introduced in Java 8, designed to provide higher throughput under
     * certain conditions compared to traditional locks like ReentrantReadWriteLock. It supports three modes of access:
     * Writing: For exclusive access.
     * Reading: For shared access.
     * Optimistic reading: For optimistic access.
     * <a href="https://medium.com/@aayushbhatnagar_10462/java-concurrency-through-stamped-locks-eb65e9a675c1">...</a>
     */

    private long balance;
    private final StampedLock lock = new StampedLock();

    public BankAccountStamped(long balance) {
        this.balance = balance;
    }

    public long getBalance() {
        long stamp = lock.readLock();
        try {
            return balance;
        } finally {
            lock.unlockRead(stamp);
        }
    }

    public long getOptimizedBalance() {
        long stamp = lock.tryOptimisticRead();
        // if stamp == 0, then the lock is not in a valid state for an optimistic read
        // aka the lock has been acquired by a writer
        long bal = balance;
        if (lock.validate(stamp)) {
            stamp = lock.readLock();
            try {
                bal = balance;
            } finally {
                lock.unlockRead(stamp);
            }
        }
        return bal;
    }

    public void deposit(long amount) {
        long stamp = lock.writeLock();
        try {
            balance += amount;
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    public void withdraw(long amount) {
        long stamp = lock.writeLock();
        try {
            balance -= amount;
        } finally {
            lock.unlockWrite(stamp);
        }
    }
}
