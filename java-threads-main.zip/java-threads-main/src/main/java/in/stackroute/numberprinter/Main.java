package in.stackroute.numberprinter;

public class Main {
    public static void main(String[] args) {

        Task task = new Task();

        Thread t1 = new Thread(task::printDivisibleBy3);
        Thread t2 = new Thread(task::printDivisibleBy5);
        Thread t3 = new Thread(task::printRemaining);

        t1.start();
        t2.start();
        t3.start();
    }
}
