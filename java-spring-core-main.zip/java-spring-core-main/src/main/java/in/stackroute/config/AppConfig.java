package in.stackroute.config;

import in.stackroute.beans.HelloWorldBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
// This annotation is used to mark this class as a configuration class
@ComponentScan(basePackages = {"in.stackroute.beans", "in.stackroute.service", "in.stackroute.repository"})
// This annotation is used to scan the packages for the beans
public class AppConfig {

    @Bean                   // default scope is singleton
    @Scope("singleton")     // this annotation is used to define the scope of the bean
    public HelloWorldBean getHelloWorldBean() {
        System.out.println("getHelloWorldBean loaded");
        return new HelloWorldBean();
    }
}
/**
 * Transaction and Transactional Rollback
 */
