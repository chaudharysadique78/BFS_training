package in.stackroute.bookservice.service;

import in.stackroute.bookservice.domain.Book;
import in.stackroute.bookservice.dto.AuthorDto;
import in.stackroute.bookservice.repository.BookRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final RestTemplate restTemplate;

    public BookServiceImpl(BookRepository bookRepository, RestTemplate restTemplate) {
        this.bookRepository = bookRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Book> getBookById(int id) {
        return bookRepository.findById(id);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class, isolation = Isolation.DEFAULT, timeout = 60)
    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = RuntimeException.class, isolation = Isolation.DEFAULT)
    public Book updateBook(Book book) {
        return bookRepository.save(book);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void deleteBook(int id) {
        bookRepository.deleteById(id);
    }

    @Override
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    @Override
    public List<Book> getBooksByAuthorName(String authorName) {
        return bookRepository.findByAuthorName(authorName);
    }


}
