package com.natwest.cs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.natwest.cs.model.Complaint;
import com.natwest.cs.repository.IComplaintRepo;


@Service
public class ComplaintImpl implements IComplaintService {

	@Autowired
	private IComplaintRepo comrepository;
	
	@Override
	public Complaint saveComplaint(Complaint comObj) {
		// TODO Auto-generated method stub
Optional<Complaint> comoptinal = this.comrepository.findById(comObj.getCustomerid());
		
		
Complaint addcom =null;
		if(comoptinal.isPresent())
		{
			
			System.out.println("Data already exist");
		}
		
		
		else
		{
			addcom = this.comrepository.save(comObj);
		}
		return addcom;
	}

	@Override
	public List<Complaint> getAllComplaints() {
		// TODO Auto-generated method stub
		return this.comrepository.findAll();
	}

}
