package in.stackroute.behavioral.strategy.billing;

public class ShipmentContext {

    private final DeliveryCostStratergy deliveryCostStratergy;

    public ShipmentContext(DeliveryCostStratergy deliveryCostStratergy) {
        this.deliveryCostStratergy = deliveryCostStratergy;
    }

    public ShipmentContext() {
        deliveryCostStratergy = new RegularCustomerDeliveryCostStratergy();
    }


    public double calculateDeliveryCost(double distance) {
        return deliveryCostStratergy.calculateDeliveryCost(distance);
    }
}
