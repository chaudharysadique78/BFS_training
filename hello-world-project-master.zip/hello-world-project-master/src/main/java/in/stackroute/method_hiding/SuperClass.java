package in.stackroute.method_hiding;

public class SuperClass {
    static void display() {
        System.out.println("Static method in SuperClass.");
    }

    void instanceMethod() {
        System.out.println("Instance method in SuperClass.");
    }
}
