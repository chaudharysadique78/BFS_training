package com.natwest.LoanClosure.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.LoanClosure.Model.CurrentAccount;
import com.natwest.LoanClosure.Model.LoanAccount;
import com.natwest.LoanClosure.Repository.CurrentAccountRepository;
import com.natwest.LoanClosure.Repository.LoanAccountRepository;

@RestController
@RequestMapping("/dashboard")
@CrossOrigin
public class DashboardAcs {

	 @Autowired
	    private CurrentAccountRepository currentAccountRepository;

	    @Autowired
	    private LoanAccountRepository loanAccountRepository;
	
	    @GetMapping("/api/accounts")
	    public List<CurrentAccount> getAccounts() {
	        return currentAccountRepository.findAll();
	    }

	    @GetMapping("/api/loans")
	    public List<LoanAccount> getLoans() {
	        return loanAccountRepository.findAll();
	    }
}
