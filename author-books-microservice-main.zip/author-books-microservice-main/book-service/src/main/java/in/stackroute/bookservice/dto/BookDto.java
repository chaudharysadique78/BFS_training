package in.stackroute.bookservice.dto;

import java.util.List;

public record BookDto(int id, String title, String authorName, List<String> genre, String authorId) {
}
