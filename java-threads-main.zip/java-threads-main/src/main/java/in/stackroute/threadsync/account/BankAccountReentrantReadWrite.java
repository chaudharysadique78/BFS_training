package in.stackroute.threadsync.account;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public class BankAccountReentrantReadWrite {

    private long balance;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    public BankAccountReentrantReadWrite(long balance) {
        this.balance = balance;
    }

    public long getBalance() {
        lock.readLock().lock();
        try{
            return balance;
        } finally {
            lock.readLock().unlock();
        }
    }

    public void deposit(long amount) {
        lock.writeLock().lock();
        try {
            balance += amount;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void withdraw(long amount) {
        lock.writeLock().lock();
        try {
            balance -= amount;
        } finally {
            lock.writeLock().unlock();
        }
    }
}
