package in.stackroute.greeting;

public class BonjourGreeting implements Greeting {
    @Override
    public void greet() {
        System.out.println("Bonjour, le monde!");
    }
}
