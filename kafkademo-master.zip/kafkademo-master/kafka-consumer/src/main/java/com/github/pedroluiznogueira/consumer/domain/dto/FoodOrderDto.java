package com.github.pedroluiznogueira.consumer.domain.dto;

import lombok.Data;
import lombok.Value;

@Data
@Value
public class FoodOrderDto {
    
	String item;
    Double amount;
	
    public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "FoodOrderDto [item=" + item + ", amount=" + amount + "]";
	}
}
