package com.note.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.note.model.Note;
import com.note.service.INoteService;

@RestController
@RequestMapping("api/v1")
public class NoteController 
{
	
	@Autowired
	private INoteService noteservice;
	
	private ResponseEntity responseEntity;
	
	@PostMapping("/addNote")
	public ResponseEntity saveNoteHandler(@RequestBody Note nObj)
	{
		Note noteObj = this.noteservice.saveNote(nObj);
		responseEntity = new ResponseEntity(noteObj,HttpStatus.CREATED);
		return responseEntity;
	}
	
	
	@GetMapping("/allNotes")
	public ResponseEntity getAllNoteHandler()
	{
		List<Note> noteObj = this.noteservice.getAllNotes();
		responseEntity = new ResponseEntity(noteObj,HttpStatus.OK);
		return responseEntity;
	}
	
	@GetMapping("/noteById/{noteId}")	
	public ResponseEntity getNoteHandler(@PathVariable String noteId)
	{
		Note noteObj = this.noteservice.getNote(noteId);
		responseEntity = new ResponseEntity(noteObj,HttpStatus.OK);
		return responseEntity;
	}
	
	@PutMapping("/updatenote/{noteId}")	
	public ResponseEntity updateNoteHandler(@RequestBody Note nObj, @PathVariable String noteId)
	{
		Note noteObj = this.noteservice.updateNote(nObj, noteId);
		responseEntity = new ResponseEntity(noteObj,HttpStatus.OK);
		return responseEntity;
	}
	
//	@PatchMapping("/updatenote/{noteId}")	
//	public ResponseEntity updateNoteTitleHandler(@RequestBody String noteTitle, @PathVariable String noteId)
//	{
//		Note noteObj = this.noteservice.updateNoteTitle(noteTitle, noteId);
//		responseEntity = new ResponseEntity(noteObj,HttpStatus.OK);
//		return responseEntity;
//	}
	
	
	@DeleteMapping("/delById/{noteId}")	
	public ResponseEntity delNoteHandler(@PathVariable String noteId)
	{
		boolean status = this.noteservice.deleteNote(noteId);
		responseEntity = new ResponseEntity("Data Deleted !!!",HttpStatus.OK);
		return responseEntity;
	}
}
