package in.stackroute.structural.adapter;

public class PaymentService {

    private final PaymentProcessor paymentProcessor;

    public PaymentService(String gateway) {
        if (gateway.equals("stripe")) {
            paymentProcessor = new StripeAdapter(new Stripe());
        } else {
            paymentProcessor = new PayPalAdapter(new PayPal());
        }
    }

    public void processPayment(double amount) {
        paymentProcessor.pay(amount);
    }
}
