package in.stackroute.behavioral.observer;

public interface Observer {
    void update(float temperature,
                float humidity, float pressure);
}
/**
 *      +-------------+        +-------------------+
 *      |   Subject   |------->|    Observer       |
 *      +-------------+        +-------------------+
 *      | + attach(observer)  |    update()       |
 *      | + detach(observer)  +-------------------+
 *      | + notifyObservers() |
 *      +-------------+
 *            |
 *            | 1..*
 *     +-------------------+
 *     |   ConcreteSubject |
 *     +-------------------+
 *     |                   |
 *     +-------------------+
 *            |
 *            | 1..*
 *     +-------------------+
 *     |   ConcreteObserver|
 *     +-------------------+
 */
