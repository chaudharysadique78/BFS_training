package com.natwest.LoanClosure.Service;

import java.util.List;

import com.natwest.LoanClosure.Model.CurrentAccount;

public interface ICurrentAccountService {
	
	 List<CurrentAccount> getAccountsByCustomerId(Long customerId);
}
