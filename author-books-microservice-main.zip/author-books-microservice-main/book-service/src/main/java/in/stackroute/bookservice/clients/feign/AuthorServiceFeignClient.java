package in.stackroute.bookservice.clients.feign;

import in.stackroute.bookservice.dto.AuthorDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "authorService", url = "http://localhost:8081/api/v1/author")
public interface AuthorServiceFeignClient {

    // Method to get author by id
    @GetMapping("/{id}")
    AuthorDto getAuthorByIdViaFeignClient(@PathVariable String id);

    @PostMapping
    AuthorDto createAuthorViaFeignClient(
            @RequestHeader("Content-Type") String contentType,
            @RequestBody AuthorDto authorDto);
}

/**
 * Provides the author service client, to access the author service.
 * Uses Declarative Syntax to define the client.
 * Has integration with Spring Cloud.
 * Supports Automatic Deserialization and Serialization.
 */