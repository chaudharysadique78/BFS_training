package in.stackroute.service1.gatewayservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewayServiceApplication.class, args);
    }

}

/**
 * Routes
 * A combination of an id, a url aka destination, a collection of predicates and filters
 *
 * Predicates
 * A criteria or a condition which must be met by the incoming requests in order for the route to be executed
 *
 * Filters
 * Filters are used to modify the request or response as it passes through the gateway
 */
