package com.restt.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.restt.service.ReadNoteService;

@RestController
@RequestMapping("/rtapi/v1")
public class readNoteController 
{
	
	@Autowired
	ReadNoteService readNoteService;
	
	@GetMapping("/readNote")
	public String readNote() throws RestClientException, IOException 
	{
		return readNoteService.getNote();
	}
}
