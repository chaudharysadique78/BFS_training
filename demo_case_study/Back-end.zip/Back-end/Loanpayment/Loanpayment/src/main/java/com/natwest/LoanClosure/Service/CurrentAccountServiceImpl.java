package com.natwest.LoanClosure.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.natwest.LoanClosure.Model.CurrentAccount;
import com.natwest.LoanClosure.Repository.CurrentAccountRepository;

@Service
public class CurrentAccountServiceImpl implements ICurrentAccountService {
	
	
	private final CurrentAccountRepository currentacRepository;
	
	@Autowired
    public CurrentAccountServiceImpl(CurrentAccountRepository currentacRepository) {
        this.currentacRepository = currentacRepository;
	}
	
	@Override
	public List<CurrentAccount> getAccountsByCustomerId(Long customerId) {
		return currentacRepository.findByCustomerId(customerId);
	}

}
