package in.stackroute.bookservice.repository;

import in.stackroute.bookservice.domain.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Integer> {

    List<Book> findByAuthorName(String authorName);
}
