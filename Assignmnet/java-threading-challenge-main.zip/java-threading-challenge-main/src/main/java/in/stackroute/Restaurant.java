package in.stackroute;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {

    private List<Table> tables;

    public Restaurant(int numTables, int tableCapacity) {
        tables = new ArrayList<>();
        for (int i = 1; i <= numTables; i++) {
            tables.add(new Table(i, tableCapacity));
        }
    }

    public synchronized Table getAvailableTable(int requiredCapacity) {
        for (Table table : tables) {
            if (!table.isOccupied() && table.getCapacity() >= requiredCapacity) {
                return table;
            }
        }
        return null;
    }

    public synchronized void occupyTable(Table table) {
        table.occupy();
        System.out.println("Table " + table.getTableId() + " is now occupied");
    }

    public synchronized void leaveTable(Table table) {
        table.leave();
        System.out.println("Table " + table.getTableId() + " is now free");
    }
}
