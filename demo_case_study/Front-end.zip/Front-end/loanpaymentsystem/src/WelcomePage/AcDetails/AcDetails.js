import React, { useState, useEffect } from 'react';
import { Accordion, AccordionSummary, AccordionDetails, Typography } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import './AcDetails.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useNavigate } from "react-router-dom";
import Footer from '../../HomePage/Footer/Footer';
import DashHeader from '../DashHeader/DashHeader';

const AcDetails = () => {

  let navigate = useNavigate();
  function pp(){
    navigate("/PartialPayment")};

  function fp(){
    navigate("/Fullpayment")};
    
  const [accountDetails, setAccountDetails] = useState({});
  const [customerDetails, setCustomerDetails] = useState({});
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAccountDetails = async () => {
      try {
        const customerId = localStorage.getItem('customerid');
        const responseCurrent = await fetch(`http://localhost:8086/transactions/accounts/${customerId}`);
        const responseLoan = await fetch(`http://localhost:8086/transactions/loans/${customerId}`);
        const responseCustomer = await fetch(`http://localhost:8080/capi/v1/customers/${customerId}`);

        if (!responseCurrent.ok || !responseCustomer.ok || !responseLoan.ok) {
          throw new Error('Network response was not ok');
        }

        const dataCurrent = await responseCurrent.json();
        const dataLoan = await responseLoan.json();
        const dataCustomer = await responseCustomer.json();

        setAccountDetails({ currentAccounts: dataCurrent, loanAccounts: dataLoan });
        setCustomerDetails(dataCustomer);
      } catch (error) {
        setError('Error fetching data. Please try again later.');
      }
    };
    fetchAccountDetails();
  }, []);

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <DashHeader />
      <br/>
        <div className="content">
          <Typography variant="h4">Customer Details</Typography>
          <div>
            <p className="register-field">Customer ID: {customerDetails.customerid}</p>
            <p className="register-field">Name: {customerDetails.name}</p>
            <p className="register-field">Date of Birth: {customerDetails.dateofbirth}</p>
            <p className="register-field"> Email: {customerDetails.emailid}</p>
            <p className="register-field">Address: {customerDetails.address}</p>
            <p className="register-field">Mobile Number: {customerDetails.mobileno}</p>
          </div>
        </div>
        <br/>
        <Typography variant="h4">Accounts</Typography>
        <br/>
        <div className="container">

                 
                  {accountDetails.currentAccounts && accountDetails.loanAccounts ? (
                      <div>
                        <Row>
                            <Col>
                          {accountDetails.currentAccounts.map((account) => (
                              <Accordion className='ord' key={`current-${account.id}`}>
                                  <AccordionSummary expandIcon={<ExpandMoreIcon />}style={{ display: 'flex', alignItems: 'center' }}>
                                      <Typography style={{ marginLeft: '190px'  }} >{account.accountType}</Typography>
                                     
                                  </AccordionSummary>
                                  <AccordionDetails>
                                      <Typography>Balance: £{account.balance}</Typography>
                                      <Typography>Account Number: {account.accountNumber}</Typography>
                                      <Typography>Sort Code: {account.sortCode}</Typography>
                                      
                                      
                                      
                                      
                                  </AccordionDetails>
                              </Accordion>
                          ))}</Col>
                          <Col>
                          {accountDetails.loanAccounts.map((account) => (
                              <Accordion className='ord' key={`loan-${account.id}`}>
                                  <AccordionSummary expandIcon={<ExpandMoreIcon />}style={{ display: 'flex', alignItems: 'center' }}>
                                      <Typography style={{ marginLeft: '190px' }}>{`Loan - ${account.id}`}</Typography>
                                  </AccordionSummary>
                                  <AccordionDetails>
                                      <Typography>Loan Amount: £{account.loanBalance}</Typography>
                                      <Typography>Account Number: {account.accountNumber}</Typography>
                                      <Typography>Sort Code: {account.sortCode}</Typography>
                                      <Typography>Rate Of Interest: {account.roi}%</Typography>
                                      <Typography>Loan Tenure: {account.tenure} Months</Typography> 
                                      <br/>

                                     
                                      <button  href="/PartialPayment" onClick={pp} > Partial Payment </button>  
                                      <button href="/Fullpayment" style={{ marginLeft: '14px' }} onClick={fp}> Full Payment </button>
                                  </AccordionDetails>
                              </Accordion>
                          ))}</Col>
                          </Row>
                      </div>
                  ) : (
                      <div>Loading...</div>
                  )}
              </div> <br/><br/><br/>
              <Footer />
          </div> 

        
    
  );
};

export default AcDetails;

