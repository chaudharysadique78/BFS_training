package in.stackroute.creational.builder;

public class Payment {

    private double amount;
    private String paymentMode;
    private String currency;
    private String recipient;
    private String sender;

    Payment() {
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "amount=" + amount +
                ", paymentMode='" + paymentMode + '\'' +
                ", currency='" + currency + '\'' +
                ", recipient='" + recipient + '\'' +
                ", sender='" + sender + '\'' +
                '}';
    }

    public static class Builder {

        private final Payment payment;

        public Builder() {
            payment = new Payment();
        }

        public Builder setAmount(double amount) {
            payment.setAmount(amount);
            return this;
        }

        public Builder setPaymentMode(String paymentMode) {
            payment.setPaymentMode(paymentMode);
            return this;
        }

        public Builder setCurrency(String currency) {
            payment.setCurrency(currency);
            return this;
        }

        public Builder setRecipient(String recipient) {
            payment.setRecipient(recipient);
            return this;
        }

        public Builder setSender(String sender) {
            payment.setSender(sender);
            return this;
        }

        public Payment build() {
            return payment;
        }   
    }       
}
