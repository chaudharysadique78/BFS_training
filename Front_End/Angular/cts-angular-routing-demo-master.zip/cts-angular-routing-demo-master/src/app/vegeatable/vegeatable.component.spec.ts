import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VegeatableComponent } from './vegeatable.component';

describe('VegeatableComponent', () => {
  let component: VegeatableComponent;
  let fixture: ComponentFixture<VegeatableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VegeatableComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VegeatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
