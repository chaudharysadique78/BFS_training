package in.stackroute.springbootjpatx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaTxApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJpaTxApplication.class, args);
    }

}
