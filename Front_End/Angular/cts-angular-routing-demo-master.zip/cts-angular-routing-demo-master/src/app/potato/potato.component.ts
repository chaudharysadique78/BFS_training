import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-potato',
  templateUrl: './potato.component.html',
  styleUrl: './potato.component.css'
})
export class PotatoComponent {
  constructor(private router:Router) { }
Login()
{
this.router.navigate(['reg']);
}
}
