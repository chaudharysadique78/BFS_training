package com.kafka.notificationProducer.entity;

import lombok.*;
import org.apache.kafka.common.protocol.types.Field;

@AllArgsConstructor
@Getter
@NoArgsConstructor
@Setter
@ToString
public class Notification {

    private int id;
    private String message;
    private String recipient;
}
