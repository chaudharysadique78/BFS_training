package program;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.*;

public class SeliniumJavaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver webd = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
		webd.get("http://localhost:3001");
		
//		webd.findElement(By.xpath("//*[@id=\\\"root\\\"]/div/div/div[1]/nav/div/form/div[2]/div/a")).click();
		
		webd.get("http://localhost:3001/Register");
		
		webd.findElement(By.id("firstname")).sendKeys("Angela");
		webd.findElement(By.id("lastname")).sendKeys("Johnson");
		webd.findElement(By.id("address")).sendKeys("Britain");
		webd.findElement(By.id("email")).sendKeys("Angel@gmail.com");
		webd.findElement(By.id("mobile")).sendKeys("0000000009");
		webd.findElement(By.id("account")).sendKeys("00000000000009");
		webd.findElement(By.id("password")).sendKeys("mygitlab#143");
		webd.findElement(By.id("confirmpassword")).sendKeys("mygitlab#143");
		webd.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div/div/div/form/div[9]")).click();
		
		
		
		webd.get("http://localhost:3001/Login");
		
		webd.findElement(By.id("email")).sendKeys("Angel@gmail.com");
		webd.findElement(By.id("password")).sendKeys("mygitlab#143");
		
		webd.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
		webd.get("http://localhost:3001/product");
		
		String url = webd.getCurrentUrl();
		
		if(url.equals("http://localhost:3001/product"))
		{
			System.out.println("Test Case Completed Successfully ...");
		}
		else
		{
			System.out.println("Test Case did not Complete Successfully ...");
		}
		
		
		webd.close();
	}

}
