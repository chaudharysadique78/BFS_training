package com.authorFinder.favorite_service.controller;

public interface IFavoriteController {
}
