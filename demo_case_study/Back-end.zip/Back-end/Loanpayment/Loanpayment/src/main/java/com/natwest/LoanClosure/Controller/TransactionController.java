package com.natwest.LoanClosure.Controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.LoanClosure.Model.CurrentAccount;
import com.natwest.LoanClosure.Model.LoanAccount;
import com.natwest.LoanClosure.Model.TransactionRequest;
import com.natwest.LoanClosure.Repository.CurrentAccountRepository;
import com.natwest.LoanClosure.Repository.LoanAccountRepository;
import com.natwest.LoanClosure.Service.ICurrentAccountService;
import com.natwest.LoanClosure.Service.ILoanAccountService;

@RestController
@RequestMapping("/transactions")
@CrossOrigin
public class TransactionController {

    @Autowired
    private CurrentAccountRepository currentAccountRepository;

    @Autowired
    private LoanAccountRepository loanAccountRepository;
    
    
    private final ICurrentAccountService accountService;
    private final ILoanAccountService loanService;
    @Autowired
    public TransactionController(ICurrentAccountService accountService, ILoanAccountService loanService) {
        this.accountService = accountService;
        this.loanService = loanService;
 
    }
 
    
//    ------
    @GetMapping("/{accountNumber}/Loanbalance")
    public ResponseEntity<String> checkloanBalance(@PathVariable String accountNumber) {
    	LoanAccount loan = loanAccountRepository.findByAccountNumber(accountNumber);
        if (loan != null) {
            return ResponseEntity.ok("Balance for account number " + accountNumber + ": " + loan.getLoanBalance());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    
    @GetMapping("/{accountNumber}/Currentbalance")
    public ResponseEntity<String> checkcurrentBalance(@PathVariable String accountNumber) {
    	CurrentAccount current = currentAccountRepository.findByAccountNumber(accountNumber);
        if (current != null) {
            return ResponseEntity.ok("Balance for account number " + accountNumber + ": " + current.getBalance());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
  
//    ------
//    For fetching the ac number for payment section
   
    
    @PostMapping("/transfer")
    public ResponseEntity<String> transferAmount(@RequestBody TransactionRequest transactionRequest) {
        try {
            // Fetch the accounts
            CurrentAccount fromAccount = currentAccountRepository.findByAccountNumber(transactionRequest.getFromAccountNumber());
            LoanAccount toAccount = loanAccountRepository.findByAccountNumber(transactionRequest.getToAccountNumber());

            // Check if accounts exist
            if (fromAccount == null || toAccount == null) {
                return ResponseEntity.badRequest().body("Invalid account details");
            }

            // Perform the transfer operation
            double amount = transactionRequest.getAmount();
            if (fromAccount.getBalance() < amount) {
                return ResponseEntity.badRequest().body("Insufficient funds");
            }
            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setLoanBalance(toAccount.getLoanBalance() - amount);

            // Save the updated account balances
            currentAccountRepository.save(fromAccount);
            loanAccountRepository.save(toAccount);

            return ResponseEntity.ok("Transaction successful");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing the transaction");
        }
    }

//    @PostMapping("/transfer")
//    public ResponseEntity<String> transferAmount(@RequestBody TransactionRequest transactionRequest) {
//        try {
//            // Fetch the accounts
//            CurrentAccount fromAccount = currentAccountRepository.findByAccountNumber(transactionRequest.getFromAccountNumber());
//            LoanAccount toAccount = loanAccountRepository.findByAccountNumber(transactionRequest.getToAccountNumber());
//
//            // Check if accounts exist
//            if (fromAccount == null || toAccount == null) {
//                return ResponseEntity.badRequest().body("Invalid account details");
//            }
//
//            // Perform the transfer operation
//            // Adjust the balances and save the accounts
//
//           
//            return ResponseEntity.ok("Transaction successful");
//            
//            
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing the transaction");
//        }
//    }
    
    
    @GetMapping("/accounts/{customerId}")
    public ResponseEntity<List<CurrentAccount>> getAccountsByCustomerId(@PathVariable Long customerId) {
        List<CurrentAccount> accounts = accountService.getAccountsByCustomerId(customerId);
        return new ResponseEntity<>(accounts, HttpStatus.OK);
    }
    
    @GetMapping("/loans/{customerId}")
    public ResponseEntity<List<LoanAccount>> getLoansByCustomerId(@PathVariable Long customerId) {
        List<LoanAccount> loans = loanService.getLoansByCustomerId(customerId);
        return new ResponseEntity<>(loans, HttpStatus.OK);
    }
}
