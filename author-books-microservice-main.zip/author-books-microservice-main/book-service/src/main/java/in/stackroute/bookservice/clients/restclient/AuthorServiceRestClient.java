package in.stackroute.bookservice.clients.restclient;

import in.stackroute.bookservice.dto.AuthorDto;

public interface AuthorServiceRestClient {

    AuthorDto getAuthorByIdViaRestClient(String id);

    AuthorDto postAuthorViaRestClient(AuthorDto authorDto);
}
