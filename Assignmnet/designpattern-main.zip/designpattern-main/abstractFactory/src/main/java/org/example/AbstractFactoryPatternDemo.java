package org.example;

public class AbstractFactoryPatternDemo {
    public static void main(String[] args) {
        //Get shape factory
        AbstractFactory shapeFactory = FactoryProducer.getFactory(false);
        //Get an object of shape Ractangle
        Shape ractangel = shapeFactory.getShape("RECTANGLE");
        //call draw method of Ractangle
        ractangel.draw();
        //Get an object of shape Square
        Shape square = shapeFactory.getShape("SQUARE");
        //call draw method of Square
        square.draw();

        //Get rounded shape factory
        AbstractFactory roundedShapeFactory = FactoryProducer.getFactory(true);
        //Get an object of shape Rounded Ractangel
        Shape roundedRactangel = roundedShapeFactory.getShape("RECTANGLE");
        //call draw method of Rounded Ractangel
        roundedRactangel.draw();
        //Get an object of shape RoundedSquare
        Shape roundedSquare = roundedShapeFactory.getShape("SQUARE");
        //call draw method of RoundedSquare
        roundedSquare.draw();
    }
}
