package in.stackroute.callable;

public record DataObject(Integer processedData, String transformedData) {
}
