import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent {
  search:string='';

  @Output()
  eem:EventEmitter<string>=new EventEmitter();
  searchFruit()
  {
    this.eem.emit(this.search);
  }
}
