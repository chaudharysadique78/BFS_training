package in.stackroute.method_hiding;

public class Child extends Parent {

    @Override
    public void hello() {
        System.out.println("Hello from Child");
    }

    public static void method() {
        System.out.println("Child static method");
    }

    public static void main(String[] args) {
        Parent parent = new Child();
        parent.hello();
        parent.method();

        Child child = new Child();
        child.method();
    }

}
