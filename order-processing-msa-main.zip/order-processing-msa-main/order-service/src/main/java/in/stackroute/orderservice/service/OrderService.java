package in.stackroute.orderservice.service;

import in.stackroute.orderservice.exceptions.ResourceNotFoundException;
import in.stackroute.orderservice.model.Inventory;
import in.stackroute.orderservice.model.Order;
import in.stackroute.orderservice.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final InventoryClient inventoryClient;

    public OrderService(OrderRepository orderRepository, InventoryClient inventoryClient) {
        this.orderRepository = orderRepository;
        this.inventoryClient = inventoryClient;
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(Long id) {
        return orderRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
    }

    public Order createOrder(Order order) {
        // Check if enough inventory exists
        Inventory inventory = inventoryClient.getInventoryByProductId(order.getProductId());
        if (inventory.getQuantity() < order.getQuantity()) {
            throw new RuntimeException("Not enough inventory for product id: " + order.getProductId());
        }

        // Reduce the inventory
        inventory.setQuantity(inventory.getQuantity() - order.getQuantity());
        inventoryClient.updateInventory(inventory);

        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
}
