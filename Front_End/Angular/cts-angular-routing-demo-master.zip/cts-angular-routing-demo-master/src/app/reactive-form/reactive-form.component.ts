import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrl: './reactive-form.component.css'
})
export class ReactiveFormComponent {
  loginForm:FormGroup=new FormGroup({
    username:new FormControl('',Validators.required),
    password:new FormControl('',[Validators.required,Validators.minLength(6),Validators.pattern('^[a-zA-Z]+$')]),
  });

  onSubmit()
  {
    alert('Form Submitted');
  }
}
