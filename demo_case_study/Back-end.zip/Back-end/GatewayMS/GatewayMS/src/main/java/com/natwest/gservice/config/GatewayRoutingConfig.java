package com.natwest.gservice.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayRoutingConfig {

	

	
	@Bean
	public RouteLocator configureRoute(RouteLocatorBuilder builder)
	{
		return builder.routes()
				.route("CustomerService", r -> r.path("/capi/v1/**").uri("http://localhost:8080"))
				.route("Authentication-2",r -> r.path("/auth/v1/**").uri("http://localhost:8080"))
				.route("Authentication-1",r -> r.path("/Authen1/**").uri("http://localhost:8083"))
				.build();
	}
	
	
	
}
