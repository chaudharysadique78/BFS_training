import React from 'react'
// import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

import './DashHeader.css'
import logo from '../../HomePage/Images/nwlogo.svg'



export default function DashHeader() {


  const handleLogout = () => {
    // Clear customerid and token from local storage
    localStorage.removeItem('customerid');
    localStorage.removeItem('token');
  };

  return (
//     <div>
// <div>  <HeaderTop></HeaderTop></div>
// <div>
    <Navbar expand="lg" className="bg-body-tertiary">
    <Container fluid>
      <Navbar.Brand href="#">   
      <img
            src={logo} 
            alt="Company Logo"
            width="120" 
            height="60"
            className="d-inline-block align-top "
          />{' '}
          </Navbar.Brand>
      <Navbar.Toggle aria-controls="navbarScroll" />
      <Navbar.Collapse id="navbarScroll">
        <Nav
          className="me-auto my-2 my-lg-0"
          style={{ maxHeight: '100px' }}
          navbarScroll
        >
          <Nav.Link href="/dash">Home</Nav.Link>
          <Nav.Link href="/reviews">Compliments</Nav.Link>
          <Nav.Link href="/faq">FAQs</Nav.Link>
         
          <NavDropdown className='navv' title="Customer Support" id="navbarScrollingDropdown">
            <NavDropdown.Item href="/Request">Raise a Request</NavDropdown.Item>
            <NavDropdown.Item href="/Complaint">Raise a Complaint</NavDropdown.Item>
          
           
          </NavDropdown>
       
        </Nav>
        
        
        {/* <Form className="d-flex">
          <Form.Control 
            type="search"
            placeholder="Search" 
            className="me-2"
            aria-label="Search"
          />
          <Button variant="outline-success">Search</Button>
        </Form> */}
          

        
<Form className="d-flex">   

          <div className='regis'>
          <Nav className="me-auto">
            <Nav.Link onClick={handleLogout} href="/">Logout</Nav.Link>
          </Nav>
      
          </div>
          </Form>
      </Navbar.Collapse>
    </Container>
  </Navbar>

  // </div>
  // </div>
);
}
