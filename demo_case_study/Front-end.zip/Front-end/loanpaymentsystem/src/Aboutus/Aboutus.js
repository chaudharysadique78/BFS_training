import React from 'react'
import pic1 from './Images/1.jpg'
import pic2 from './Images/2.jpg'
import pic3 from './Images/3.jpg'
import pic4 from './Images/4.jpg'
import Header from '../HomePage/Header/Header'
import Footer from '../HomePage/Footer/Footer'

export default function Aboutus() {
  return (
    <div>
    <Header/>
    <img src={pic1} alt="Image One"/>
    <img src={pic2} alt="Image One"/>
    <img src={pic3} alt="Image One"/>
    <img src={pic4} alt="Image One"/>
    <Footer/>
    </div>
  )
}
