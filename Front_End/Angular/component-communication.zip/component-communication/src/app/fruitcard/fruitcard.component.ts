import { Component, Input } from '@angular/core';
import { Fruit } from '../../../fruit';

@Component({
  selector: 'app-fruitcard',
  templateUrl: './fruitcard.component.html',
  styleUrl: './fruitcard.component.css'
})
export class FruitcardComponent {
  @Input()
  fruitss:Fruit={name:'',color:'',price:0};

}
