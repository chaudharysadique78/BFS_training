package in.stackroute.persons;

import java.util.List;

public class PersonMain {

    public static void main(String[] args) {
        SocialNetwork socialNetwork = new SocialNetwork();

        System.out.println("Persons older than 20:");
        socialNetwork.print(new AgeGreater(20));


        System.out.println("Persons between 20 and 25:");
        socialNetwork.print(new AgeBetween(20, 25));

        CheckPerson ageLessThan = (p) -> p.getAge() < 20;
        System.out.println("Persons younger than 20:");

        socialNetwork.print(ageLessThan);

        List<CheckPerson> filters = List.of(
                p -> p.getAge() > 20,
                p -> p.getGender().equals("MALE")
        );
        System.out.println("Males older than 20");
        socialNetwork.print(filters);
    }
}
