package com.natwest.AccountDetails.Controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.AccountDetails.Service.AuthenticationService;

import io.swagger.v3.oas.annotations.tags.Tag;



@RestController
@CrossOrigin("*")
public class AuthenController {

    private final AuthenticationService authenticationService;
    

    @Autowired
    public AuthenController(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }
    
    @PostMapping("/validate")
    public ResponseEntity<?> validateAuthentication(@RequestBody AuthenRequest request) {
    	 try {
             boolean isValid = authenticationService.validateAuthenticationService(request.getCustomerId(), request.getDebitCardNo(), request.getPinCode());

             if (isValid) {
                 return new ResponseEntity<>("Authentication successful", HttpStatus.OK);
             } else {
                 return new ResponseEntity<>("Invalid credentials. Access denied.", HttpStatus.UNAUTHORIZED);
             }
         } catch (Exception e) {
             // Log the exception for debugging purposes
             // You can also return a custom error message or handle the exception differently
             return new ResponseEntity<>("An error occurred. Please try again later.", HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }
    
    

//    @PostMapping("/validate")
//    public String validateAuthentication(@RequestBody AuthenticationRequest request) {
//        boolean isValid = authenticationService.validateAuthenticationService(request.getCustomerId(), request.getDebitCardNo(), request.getPinCode());
//        if (isValid) {
//            return "Authentication successful";
//        } else {
//            return "Authentication failed";
//        }
    }

