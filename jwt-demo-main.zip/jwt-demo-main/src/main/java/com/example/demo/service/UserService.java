package com.example.demo.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepo;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class UserService {
	@Autowired
	private UserRepo repo;
	
	public User registerUser(User u) {
		
		return repo.save(u);
		
	}
	public Map<String,String> Login(String uname,String password)
	{
		Map<String,String> token=new HashMap<>();
		User u=repo.findByEmailAndPassword(uname, password);
		if(u!=null)
		{
			token=getJWTToken(u);
		}
		return token;
		
	}

	public List<User> getAllUsers() {
		return repo.findAll();
	}

	public Map<String,String> getJWTToken(User u)
    {
        String tok=Jwts.builder().setSubject(u.getEmail())
        .setIssuedAt(new Date(0)).signWith(SignatureAlgorithm.HS256,"secret").compact();
        Map<String,String> tok1=new HashMap<>();
        tok1.put("token", tok);
        return tok1;
    }

}




