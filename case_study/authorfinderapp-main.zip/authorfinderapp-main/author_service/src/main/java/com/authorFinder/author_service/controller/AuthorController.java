package com.authorFinder.author_service.controller;

import com.authorFinder.author_service.entity.ApiResponse;
import com.authorFinder.author_service.service.AuthorServiceImpl;
import lombok.Getter;
import lombok.val;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/author")
public class AuthorController implements IAuthorController {

    @Autowired
    AuthorServiceImpl authorService;

    @GetMapping("/search")
    public ResponseEntity<ApiResponse> fetchAuthor(@RequestParam String name) {
        val response = authorService.fetchAuthor(name);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
