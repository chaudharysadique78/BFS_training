package in.stackroute.creational.builder;

public class Main {
    public static void main(String[] args) {
        PaymentBuilder builder   = new PaymentBuilder();
        PaymentGateway gateway   = new PaymentGateway(builder);

        Payment creditCardPayment = gateway.buildCreditCardPayment();
        System.out.println(creditCardPayment);

        Payment payPalPayment     = gateway.buildPayPalPayment();
        System.out.println(payPalPayment);
    }
}
