package com.natwest.complimentform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.complimentform.modal.ComplimentForm;
import com.natwest.complimentform.services.ICompFormService;

@RestController
@CrossOrigin
@RequestMapping("/comapi/v1")
public class CompFormController {

	private final ICompFormService compServ;

    @Autowired
    public CompFormController(ICompFormService compServ) {
        this.compServ = compServ;
    }

    @PostMapping("/compliments")
    public ComplimentForm saveComplimentForm(@RequestBody ComplimentForm cObj) {
        return compServ.saveComplimentForm(cObj);
        
        
    }
}
