export type user={
    id:number;
    name:string;
    email:string;
    phone:number;

}