package com.natwest.complimentform.services;


import com.natwest.complimentform.modal.ComplimentForm;

public interface ICompFormService {

	public ComplimentForm saveComplimentForm(ComplimentForm cObj);
	
}
