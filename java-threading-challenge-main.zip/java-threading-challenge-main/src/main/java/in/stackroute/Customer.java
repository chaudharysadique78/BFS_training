package in.stackroute;

public class Customer implements Runnable {

    private int customerId;
    private Restaurant restaurant;
    private int groupSize;

    public Customer(int customerId, Restaurant restaurant, int groupSize) {
        this.customerId = customerId;
        this.restaurant = restaurant;
        this.groupSize = groupSize;
    }

    @Override
    public void run() {

    }
}
