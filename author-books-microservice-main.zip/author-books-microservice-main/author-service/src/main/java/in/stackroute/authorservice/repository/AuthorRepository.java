package in.stackroute.authorservice.repository;

import in.stackroute.authorservice.domain.Author;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface AuthorRepository extends MongoRepository<Author, String> {

    // This method will find all authors in the following genres
    List<Author> findByGenreIn(List<String> genre);

    List<Author> findByName(String name);

}
