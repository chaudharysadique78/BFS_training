package org.example;

public class RoundedRectangle implements Shape{
    public void draw() {
        System.out.println("Draw RoundedRectangle");

    }
}
