import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatamgmtService {

  nameOfEmp:string='Rajeev';

  constructor() { }
}


