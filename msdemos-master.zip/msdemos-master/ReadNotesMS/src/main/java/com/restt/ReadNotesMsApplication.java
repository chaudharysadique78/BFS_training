package com.restt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ReadNotesMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadNotesMsApplication.class, args);
	}

}
