package com.authorFinder.favorite_service.service;

public interface FavouriteService {
}
