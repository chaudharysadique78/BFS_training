import React , { useState } from 'react';
import Carousel from 'react-bootstrap/Carousel';
import { Modal } from 'react-bootstrap';
import Review from './Review'; 
import './Caraousel.css'; 
import ComplimentForm from '../ComplimentForm/ComplimentForm';

const reviews = [
    [
      {
        text: "The query is address and I am happy for resolving the issue. Thank you Sathya.",
        author: "Annu",
      },
      {
        text: "To Dear Bharti, She is a very nice executive and she helped in a very nice way.",
        author: "Abha",
      },
      {
        text: "Very prompt and good service even the interaction with the executive was pleasant!",
        author: "Janakiram",
      },
    ],
    [
      {
        text: "Thank you so much for this quick turnaround and support. Thanks for support", 
        author: "Silvester",
      },
      {
        text: "Thank you so much. Will highly recommend NatWest bank services to my family and friends.",
        author: "Mahitha",
      },
      {
        text: "Dear team, Thank you so much for resolving my issue within frame time. Thanks for guidance. ",
        author: "Ayesha",
      },
    ],
    // Add more sets of reviews as needed
  ];
  
  export default function Caraousel() {
    const [isFormOpen, setIsFormOpen] = useState(false);
    
    const openForm = () => {
      setIsFormOpen(true);
    };
  
    const closeForm = () => {
      setIsFormOpen(false);
    };

    const handleSubmit = () => {
         setIsFormOpen(false);
    };
  
    // const handleSubmit = () => {
    //   // Send form data to the backend for saving to the database (you may replace this with your actual API call)
  
    
    //   setIsFormOpen(false);
    // };
  
    return (
      <div className="carousel-container">
        <Carousel className="custom-carousel-background">
          {reviews.map((reviewSet, index) => (
            <Carousel.Item key={index}>
              <div className="d-flex flex-column align-items-center justify-content-between align-items-center">
                <p className="text-line">
                  Hear from our happy customers
                  <a href="#compliments" className="add-compliment-link" onClick={openForm}>
                    Add Your Compliments +
                  </a>
                </p>
                <div className="card-container d-flex">
                  {reviewSet.map((review, innerIndex) => (
                    <div key={innerIndex} className="mr-3">
                      <Review text={review.text} author={review.author} />
                      <div className="explore-link">
                        <a href="/reviews">Explore More</a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Carousel.Item>
          ))}
        </Carousel>
        <Modal show={isFormOpen} onHide={closeForm} centered >
        <Modal.Body>
          <ComplimentForm onClose={closeForm} onSubmit={handleSubmit} />
        </Modal.Body>
      </Modal>
        {/* {isFormOpen && (
            <Modal show={isFormOpen} onHide={closeForm}>
            <Modal.Header closeButton>
              <Modal.Title>Add Your Compliments</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <ComplimentForm onClose={closeForm} onSubmit={handleSubmit} />
            </Modal.Body>
          </Modal>
        )}
   */}
  {/* {isFormOpen && <ComplimentForm onClose={closeForm} />} */}

    </div>
    );
  }

