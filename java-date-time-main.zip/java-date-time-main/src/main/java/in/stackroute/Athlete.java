package in.stackroute;

import java.time.Duration;

public class Athlete {

    private String name;
    private Duration lap1Time;
    private Duration lap2Time;
    private Duration lap3Time;

    public Athlete(String name, Duration lap1Time, Duration lap2Time, Duration lap3Time) {
        this.name = name;
        this.lap1Time = lap1Time;
        this.lap2Time = lap2Time;
        this.lap3Time = lap3Time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Duration getLap1Time() {
        return lap1Time;
    }

    public void setLap1Time(Duration lap1Time) {
        this.lap1Time = lap1Time;
    }

    public Duration getLap2Time() {
        return lap2Time;
    }

    public void setLap2Time(Duration lap2Time) {
        this.lap2Time = lap2Time;
    }

    public Duration getLap3Time() {
        return lap3Time;
    }

    public void setLap3Time(Duration lap3Time) {
        this.lap3Time = lap3Time;
    }

    public Duration getTotalTime() {
        return lap1Time.plus(lap2Time).plus(lap3Time);
    }
}
