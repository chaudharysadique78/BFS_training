package in.stackroute.method_hiding;

public class Main {
    public static void main(String[] args) {
        SuperClass superClass = new SuperClass();
        SuperClass subClassAsSuper = new SubClass();
        SubClass subClass = new SubClass();

        // Static method calls
        superClass.display(); // Calls SuperClass's static method
        subClassAsSuper.display(); // Calls SuperClass's static method
        subClass.display(); // Calls SubClass's static method

        // Instance method calls
        superClass.instanceMethod(); // Calls SuperClass's instance method
        subClassAsSuper.instanceMethod(); // Calls SubClass's instance method (dynamic method dispatch)
        subClass.instanceMethod(); // Calls SubClass's instance method
    }
}
