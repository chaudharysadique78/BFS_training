package com.natwest.cs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.natwest.cs.model.Complaint;
import com.natwest.cs.service.IComplaintService;

@CrossOrigin
@RestController
@RequestMapping("capi/v1")
public class ComplaintController {

	
	
	@Autowired
	private IComplaintService comservice;
	private ResponseEntity<?> respentity;
	
	
	@PostMapping("/addcom")
	public ResponseEntity<?>saveDataComplaintHandler(@RequestBody Complaint comObj)
	
	{
		Complaint dataadded = this.comservice.saveComplaint(comObj);
				
				respentity = new ResponseEntity(dataadded,HttpStatus.CREATED);
				return  respentity;
			}

	
	@GetMapping("/getcom")
	public ResponseEntity<?>getAllComplaintsHandler()
	
	{
		List<Complaint> reqdata = this.comservice.getAllComplaints();
		
		respentity = new ResponseEntity(reqdata,HttpStatus.CREATED);
		return  respentity;
	}
	
	
}
