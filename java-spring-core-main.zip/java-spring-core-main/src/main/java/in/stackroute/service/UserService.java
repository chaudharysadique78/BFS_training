package in.stackroute.service;

import in.stackroute.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
// This annotation is used to mark this class as a bean
public class UserService {

    // Declaring the dependency
    private final UserRepository userRepository; // Mandatory dependency

    // Constructor based dependency injection
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public void registerUser(String email) {
        System.out.println("[Service]: User registered with email: " + email);
        userRepository.saveUser(email);
    }

}
