package in.stackroute.structural.adapter;

public interface PaymentProcessor {
    void pay(double amount);
}
