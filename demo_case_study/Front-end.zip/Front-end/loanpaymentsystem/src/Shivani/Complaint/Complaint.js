import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import './Complaint.css';
import DashHeader from '../../WelcomePage/DashHeader/DashHeader';
import Footer from '../../HomePage/Footer/Footer';
import swal from 'sweetalert';

const Complaint = () => {
  const initialValues = {
    customerid: '',
    name: '',
    email: '',
    phoneno: '',
    complaintfor: '',
  };
  const validationSchema = Yup.object({
    customerid: Yup.string()
      .required('Customer ID is required')
      .max(8, 'Customer ID must be 8 characters or less'),
    name: Yup.string().required('Name is required'),
    email: Yup.string()
      .email('Invalid email address')
      .required('Email is required'),
    phoneno: Yup.string()
      .matches(/^[0-9]+$/, 'Must be a number')
      .max(10, 'Phone number must be 10 digits')
      .required('Phone number is required'),
      complaintfor: Yup.string().required('Please fill this field'),
  });
  const handleSubmit = (values, { resetForm }) => {
    // Send the request to the backend
    fetch('http://localhost:8085/capi/v1/addcom', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(values),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Response from the server:', data);
        // Handle success or error here
        swal('Complaint Registered Succesfully! We will get back to you!', { icon: 'success' });
        resetForm();
      })
      .catch((error) => {
        console.error('Error:', error);
        // Handle error here
        alert('An error occurred. Please try again later.');
      });
  };
  return (
  <div>
    <DashHeader/>
    <br/>
  <div className='ff'>
    <div className="con">
      <div className="K2">
        <h2 style={{ backgroundColor:'indigo', color:'white'}}>Complaint Form</h2>
      </div>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        <Form className="K1" autoComplete='off'>
          <div className="lab">
            <label htmlFor="customerid">Customer ID</label>
            <Field type="text" id="customerid" name="customerid" />
            <ErrorMessage name="customerid" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="name">Name</label>
            <Field type="text" id="name" name="name" />
            <ErrorMessage name="name" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="email">Email</label>
            <Field type="email" id="email" name="email" />
            <ErrorMessage name="email" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="phoneno">Phone Number</label>
            <Field type="text" id="phoneno" name="phoneno" />
            <ErrorMessage name="phoneno" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="complaintfor">Complaint For</label>
            <Field type="text" id="complaintfor" name="complaintfor" />
            <ErrorMessage name="complaintfor" component="div" className="error" />
          </div>
          <button style={{ marginLeft: '115px' }} type="submit">Submit</button>
        </Form>
      </Formik>
    </div>
    </div>
     <br/>
    <Footer/>
   
    </div>
  );
};
export default Complaint;