package in.stackroute.bookservice.clients.resttemplate;

import in.stackroute.bookservice.dto.AuthorDto;

public interface AuthorServiceRestTemplateClient {

    AuthorDto getAuthorByIdViaRestTemplate(String id);

    AuthorDto postAuthorViaRestTemplate(AuthorDto authorDto);

}
