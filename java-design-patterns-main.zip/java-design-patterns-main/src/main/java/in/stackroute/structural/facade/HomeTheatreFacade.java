package in.stackroute.structural.facade;

public class HomeTheatreFacade {

    private final DvdPlayer dvdPlayer;
    private final Projector projector;
    private final Screen screen;

    public HomeTheatreFacade(DvdPlayer dvdPlayer, Projector projector, Screen screen) {
        this.dvdPlayer = dvdPlayer;
        this.projector = projector;
        this.screen = screen;
    }

    public void watchMovie(String movieName) {
        System.out.println("Get ready to watch a movie...");
        screen.down();
        projector.on();
        dvdPlayer.on();
        projector.wideScreenMode();
        dvdPlayer.play(movieName);
    }

    public void stopMovie(){
        System.out.println("Shutting movie theater down...");
        screen.up();
        projector.off();
        dvdPlayer.off();
    }
}
