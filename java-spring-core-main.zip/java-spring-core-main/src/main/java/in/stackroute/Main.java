package in.stackroute;

import in.stackroute.beans.HelloWorldBean;
import in.stackroute.repository.UserRepository;
import in.stackroute.service.UserService;
import in.stackroute.config.AppConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {

        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        UserService userService = context.getBean(UserService.class);

        userService.registerUser("john.doe");

    }

    static void hellWoldBean(ApplicationContext context) {
        HelloWorldBean helloWorldBean = context.getBean(HelloWorldBean.class);
        helloWorldBean.setMessage("Hello World!");
        helloWorldBean.getMessage();
    }
}
