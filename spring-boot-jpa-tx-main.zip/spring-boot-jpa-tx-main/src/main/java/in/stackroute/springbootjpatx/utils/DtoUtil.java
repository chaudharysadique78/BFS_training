package in.stackroute.springbootjpatx.utils;

import in.stackroute.springbootjpatx.domain.User;
import in.stackroute.springbootjpatx.dto.UserRequestDto;
import in.stackroute.springbootjpatx.dto.UserResponseDto;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;

@Component
public class DtoUtil {

    public User toEntity(UserRequestDto dto) {
        return new User(dto.name(), dto.email(), dto.password());
    }

    public UserResponseDto toResponseDto(User entity, HttpStatusCode code) {
        return new UserResponseDto(entity.getId(), entity.getName(), entity.getEmail(), code);
    }
}
