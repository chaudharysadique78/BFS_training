package com.stackroute.lamdbaexpression;

import java.util.List;
import java.util.stream.Collectors;

public class PredicateFunctionalInterface {
    //write logic to find the values that starts with letter I in the given list
    public List<String> findPattern(List<String> list) {
        return list.stream().distinct().filter(name -> name.startsWith("I")).collect(Collectors.toList());
    }
}
