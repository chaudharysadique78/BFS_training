package com.sr.hotel.service;

import java.util.List;

import com.sr.hotel.model.Hotel;

public interface HotelService {

    //create

    Hotel create(Hotel hotel);

    //get all
    List<Hotel> getAll();

    //get single
    Hotel get(String id);

}
