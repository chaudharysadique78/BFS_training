# Why introduce Spring framework?

Spring is a lightweight, open-source framework that is used to develop enterprise applications. 
It was developed by Rod Johnson in 2003. It is a framework that is based on two design principles: 
Dependency Injection and Aspect Oriented Programming.

- Address the J2EE (Web) development complexity and it's dependency on Enterprise Java Beans (Session Beans, Entity Beans, Message Driven Beans).
 EJB Applications required an application server to run, which was expensive and complex to manage. 
- Enable development using POJO's (Plain Old Java Objects) and provide a way to manage these POJO's.
- Simplify the development of enterprise applications by providing a container that manages the lifecycle of Java objects
  by promoting DI and IOC.

# IOC Container

The Spring container is at the core of the Spring Framework. The container will create the objects, wire them together, 
configure them, and manage their complete lifecycle from creation till destruction. The Spring container uses DI 
to manage the components that make up an application.