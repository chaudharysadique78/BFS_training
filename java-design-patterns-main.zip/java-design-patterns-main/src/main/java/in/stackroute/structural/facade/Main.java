package in.stackroute.structural.facade;

public class Main {
    public static void main(String[] args) {
        DvdPlayer dvdPlayer = new DvdPlayer();
        Projector projector = new Projector();
        Screen screen = new Screen();

        HomeTheatreFacade homeTheatreFacade = new HomeTheatreFacade(dvdPlayer, projector, screen);

        homeTheatreFacade.watchMovie("Inception");
        System.out.println();
        homeTheatreFacade.stopMovie();
    }
}
/**
 *        +------------+      +------------------+
 *        |  Client    |      |      Facade      |
 *        +------------+      +------------------+
 *             |                    |
 *             |    simplified()    |
 *             +------------------->|
 *                                  |   +----------------+
 *                                  |   |  Subsystem1    |
 *                                  |   +----------------+
 *                                  |   |  operation1()  |
 *                                  |   +----------------+
 *                                  |          |
 *                                  |          |
 *                                  |          v
 *                                  |   +----------------+
 *                                  |   |  Subsystem2    |
 *                                  |   +----------------+
 *                                  |   |  operation2()  |
 *                                  |   +----------------+
 *                                  |          |
 *                                  |          |
 *                                  |          v
 *                                  |   +----------------+
 *                                  |   |  SubsystemN    |
 *                                  |   +----------------+
 *                                  |   |  operationN()  |
 *                                  |   +----------------+
 *                                  v
 */
