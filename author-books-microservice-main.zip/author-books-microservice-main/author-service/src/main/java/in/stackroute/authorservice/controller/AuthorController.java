package in.stackroute.authorservice.controller;

import in.stackroute.authorservice.domain.Author;
import in.stackroute.authorservice.dto.AuthorDto;
import in.stackroute.authorservice.service.AuthorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/author")
public class AuthorController {

    private final AuthorService authorService;

    public AuthorController(AuthorService authorService) {
        this.authorService = authorService;
    }

    // POST - Create a new Author
    @PostMapping
    public ResponseEntity<AuthorDto> createAuthor(@RequestBody AuthorDto request) {
        // Convert AuthorDto to Author
        Author author = convertToAuthor(request);
        // Save Author to database
        author = authorService.saveAuthor(author);
        // Convert Author to AuthorDto
        AuthorDto response = convertToAuthorDto(author);
        // Return AuthorDto
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // GET - Get author by id
    @GetMapping("/{id}")
    public ResponseEntity<AuthorDto> getAuthor(@PathVariable("id") String id) {
        // Get Author by id
        Author author = authorService.getAuthorById(id).orElseThrow();
        // Convert Author to AuthorDto
        AuthorDto response = convertToAuthorDto(author);
        // Return AuthorDto
        return ResponseEntity.ok(response);
    }

    private AuthorDto convertToAuthorDto(Author author) {
       return new AuthorDto(author.getId(), author.getName(), author.getGenre());
    }

    private Author convertToAuthor(AuthorDto authorDto) {
        Author author = new Author();
        author.setId(authorDto.id());
        author.setName(authorDto.name());
        author.setGenre(authorDto.genres());
        return author;
    }

}
