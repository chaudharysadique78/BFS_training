package in.stackroute;

public sealed class Rectangle extends Shape permits Square{
}
