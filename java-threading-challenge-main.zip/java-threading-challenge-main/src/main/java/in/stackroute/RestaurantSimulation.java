package in.stackroute;

public class RestaurantSimulation {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}