package com.webc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebClientMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
