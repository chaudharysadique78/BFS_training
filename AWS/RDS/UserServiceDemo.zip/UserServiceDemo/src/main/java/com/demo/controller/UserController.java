package com.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.User;
import com.demo.repository.IUserRepository;
import com.demo.service.IUserService;

@RestController

//http://localhost:8081/api/v1/adduser

@RequestMapping("api/v1")
public class UserController 
{
	@Autowired
	private IUserService iuService;

	private ResponseEntity<?> respentity;
	
	@PostMapping("/adduser")
	public ResponseEntity<?> saveUser(@RequestBody User uobj)
	{
		User userobj = this.iuService.createUser(uobj);
		ResponseEntity respe = new ResponseEntity(userobj,HttpStatus.CREATED);
		return respe;
	}

	
	@PutMapping("/updateuser/{uid}")
	public ResponseEntity<?> updateUser(@RequestBody User uobj,@PathVariable int uid)
	{
		User userobj = this.iuService.updateUserById(uobj, uid);
		ResponseEntity respe = new ResponseEntity(userobj,HttpStatus.CREATED);
		return respe;
	}

	
	
	@GetMapping("/getusers")
	public ResponseEntity<?> getAllUsers()
	{
		ResponseEntity respe = new ResponseEntity(this.iuService.getAllUsers(),HttpStatus.OK);
		return respe;
	}
	
	@GetMapping("/getuserbyid/{uid}")
	public ResponseEntity<?> getUserById(@PathVariable int uid)
	{
		User uobj = this.iuService.getUserById(uid);
		ResponseEntity respe = new ResponseEntity(uobj,HttpStatus.OK);
		return respe;
	}
	
	@DeleteMapping("/deluserbyid/{uid}")
	public ResponseEntity<?> delUserById(@PathVariable int uid)
	{
		boolean status = this.iuService.deleteUserById(uid);
		ResponseEntity respe = new ResponseEntity("User details deleted ",HttpStatus.OK);
		return respe;
	}
}
