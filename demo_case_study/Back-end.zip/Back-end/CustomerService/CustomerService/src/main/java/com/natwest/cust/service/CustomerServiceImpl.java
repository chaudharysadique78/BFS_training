package com.natwest.cust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.natwest.cust.model.Customer;
import com.natwest.cust.repository.ICustomerRepository;
@Service
public class CustomerServiceImpl implements ICustomerService {

	
	@Autowired
	private ICustomerRepository custrepository;


    @Autowired
    public CustomerServiceImpl(ICustomerRepository custrepository) {
        this.custrepository = custrepository;
    }

	@Override
	public Customer saveCustomer(Customer custObj) {
		Optional<Customer> custoptinal = this.custrepository.findById(custObj.getCustomerid());
		
		Customer addcust =null;
		
		if(custoptinal.isPresent())
		{
			
			System.out.println("Data already exist");
		}
		
		
		else
		{
			addcust = this.custrepository.save(custObj);
		}
		return addcust;
	}

		
	

	@Override
	public Customer updateCustomer(Customer custObj, int custId) {
		 Optional<Customer> optionalCustomer = this.custrepository.findById(custId);

		    if (optionalCustomer.isPresent()) {
		        Customer existingCustomer = optionalCustomer.get();
		        existingCustomer.setPassword(custObj.getPassword()); // Assuming setPassword method is available in Customer class to set the password

		        return this.custrepository.save(existingCustomer);
		    } else {
		        System.out.println("Customer with the following ID does not exist.");
		        // You can return null or handle the situation based on your specific requirements
		        return null;
		    }
	}

	@Override
	public Customer getCustomerById(int custId) {
	    Optional<Customer> optionalCustomer = this.custrepository.findById(custId);
	    Customer customerData = null;
	    if (optionalCustomer.isPresent()) {
	        System.out.println("Customer with the following ID already exists...");
	        customerData = optionalCustomer.get();
	    } else {
	        System.out.println("Customer with the following ID does not exist...");
	        // You can choose to handle the absence of the customer here.
	    }
	    return customerData;
	}

	@Override
	public boolean deletCustomerBYId(int custId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> getAllCustomers() {
		return this.custrepository.findAll();
		
	}
	
	@Override
	public boolean validateUserService(Integer customerid, String password)  {
		Customer cust = custrepository.validateUser(customerid, password);
		System.out.println("Customer" + cust);
		if(cust != null)
			return true;
		else
			return false;
	}



	  @Override
	    public Customer findnamebycustid(int customerid) {
	        // Assuming your repository has a method for finding by customerid
	        return custrepository.findByCustomerid(customerid);
	    }









//	@Override
//	public String getnamebycustid(int customerid, String password) {
//		Customer customer = custrepository.findbycustid(customerid, password);
//
//        if (customer != null) {
//            return customer.getName();
//        } else {
//            return null; // Return null if no user is found
//        }
//	}






}
