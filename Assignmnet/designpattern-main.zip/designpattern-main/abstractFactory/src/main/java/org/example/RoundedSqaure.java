package org.example;

public class RoundedSqaure implements Shape{
    public void draw() {
        System.out.println("Draw RoundedSqaure");
    }
}
