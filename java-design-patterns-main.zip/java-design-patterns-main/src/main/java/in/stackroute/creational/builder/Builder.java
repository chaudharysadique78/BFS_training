package in.stackroute.creational.builder;

public interface Builder {
    Builder setAmount(double amount);
    Builder setPaymentMode(String paymentMode);
    Builder setCurrency(String currency);
    Builder setRecipient(String recipient);
    Builder setSender(String sender);
    Payment build();
}

/**
 * Tata Motors
 * ICE  Car
 * EV   Car
 * --------------------------------
 * TataMotorsAbstractFactory
 * - ICECarFactory
 * -- NexonBuilder
 * -- HarrierBuilder
 * - EVCarFactory
 * -- NexonEVBuilder
 * -- TiagoEVBuilder
 */
