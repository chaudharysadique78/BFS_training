package in.stackroute;

import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {

        int a = 10;
        int b = 10;

//        System.out.println("Addition:= " + Operation.ADD.apply(a, b));
//        System.out.println("Subtraction:= " + Operation.SUBTRACT.apply(a, b));
//        System.out.println("Multiplication:= " + Operation.MULTIPLY.apply(a, b));
//        System.out.println("Division:= " + Operation.DIVIDE.apply(a, b));

        System.out.println(HTTPStatus.OK.getCode() + " " + HTTPStatus.OK.getStatus());
    }
}