import React, { useState } from 'react';
import axios from 'axios';
import "../Authentication/AuthenticationForm.css"
import CheckBoxRoundedIcon from '@mui/icons-material/CheckBoxRounded';
import Header from '../Loggin/Header/Header';
import Footr from '../Loggin/Footr/Footr'
import Nav from 'react-bootstrap/Nav';
import { useNavigate } from 'react-router-dom';

const AuthenticationForm = () => {

    function xyz(){
        navigate("/logn");
       }
    let navigate = useNavigate();
    const [customerId, setCustomerId] = useState('');
    const [debitCardNo, setDebitCardNo] = useState('');
    const [pinCode, setPinCode] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    
    
   

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8083/validate', {
                customerId: parseInt(customerId),
                debitCardNo,
                pinCode: parseInt(pinCode)
            });

          
            if (response.status === 200) {
                console.log("You have Logged in Successfully");
                localStorage.setItem('customerId', customerId);
                navigate("/reg2");
                // Handle successful authentication here
              } 
            } catch (error) {
                if (error.response && error.response.status === 401) {
                  setError('Invalid credentials. Please check your details and try again.');
                } else {
                  console.error('Error: ', error);
                  setError('An error occurred. Please try again later.');
                }
              }
            };

    return (
        <div>
            <Header/>
            <section className='Aseca'>
            <h2 className='nbh1'>Natwest NetBanking</h2> 
            <p>Perform over 200 transactions in just a few clicks</p> <br/>
                <h3 className='nbh2'>Set up Online Banking</h3> 
                <br/>
                <p className='nbp1'>Setting up Online Banking will only take a few minutes. If we have a Debit card readily availble, we can set you up for Online Banking
                    <br/><br/>
                    Before you start, please make sure: <br/><br/>
                    <CheckBoxRoundedIcon fontSize='large'/>  You're aged 11 or over. <br/> <CheckBoxRoundedIcon fontSize='large'/>  You have your customer ID and Debit Card handy.

                    <br/><CheckBoxRoundedIcon fontSize='large'/>  Individuals having a savings account or current account at any bank can register for internet banking
                    

                </p> 

               
                <div className='Asecb'>
                
                    
                
            <form className='cfb' onSubmit={handleSubmit} autoComplete='off'>
            <div className="lc">
            <h2 className='loghh'>Registration Form <br></br> <p>Step-1</p></h2>
            </div>
                <h5>Let's start by getting a few details from you:</h5>
                <input className='icn' id="customerid" type="text" placeholder="Enter your Customer ID" value={customerId} onChange={(e) => setCustomerId(e.target.value)} />
                <br/>
                <input className='icn' id="debitcard" type="text" placeholder="Enter your Debit Card No" value={debitCardNo} onChange={(e) => setDebitCardNo(e.target.value)} />
                <br/>
                <input className='icn' id="pin" type="text" placeholder="Enter your Card Pin" value={pinCode} onChange={(e) => setPinCode(e.target.value)} />
                <br/>
                <button type="submit" className="btnlog">Submit</button>
            </form>
            
            {message && <p>{message}</p>}
            {error && <p>{error}</p>}

            <p>Already a user?</p>

          
          <button className="rsu" onClick={xyz} >Login here</button>
                
            </div>
            </section>
            <Footr/>
            
        </div>
    );
};

export default AuthenticationForm;
