package com.example.thirdpartapiintegrationinspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThirdPartApiIntegrationInSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
