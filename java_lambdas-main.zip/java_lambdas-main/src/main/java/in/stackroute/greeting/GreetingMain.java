package in.stackroute.greeting;

public class GreetingMain {

    public static void main(String[] args) {

        Greeting greeting = new HelloGreeting(); // is-a relationship
        greeting.greet();

        Greeting bonjour = new BonjourGreeting(); // is-a relationship
        bonjour.greet();

        int x = 10;
        String name = "Ashish";

        // Lambda expression
        Greeting fx = () -> System.out.println("Hello, World!");

        Math sum = (a, b) -> a + b;
        Math difference = (a, b) -> a - b;

        System.out.println("Sum: " + sum.perform(10, 20));
        System.out.println("Difference: " + difference.perform(20, 10));



    }
}
