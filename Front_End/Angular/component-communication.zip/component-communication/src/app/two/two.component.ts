import { Component } from '@angular/core';
import { OneToTwoService } from '../one-to-two.service';

@Component({
  selector: 'app-two',
  templateUrl: './two.component.html',
  styleUrl: './two.component.css'
})
export class TwoComponent {
  constructor(private ott:OneToTwoService){}
  uname:string='';
  recData()
  {
    this.uname=this.ott.username;
  }
  

}
