package in.stackroute.lambdas;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

public class MethodReference {
    /**
     * Method Reference
     */

    public static void main(String[] args) throws IOException {

        MethodReference refMain = new MethodReference();
        List<Integer> numbers = List.of(10, 12, 3, 4, 5, 6, 7, 18, 9);
        List<String> names = List.of("Tom", "Jerry", "Spike", "Tyke");

//        Consumer<Integer> print = System.out::println; // (num) -> System.out.println(num);
//        numbers.forEach(print);
//        numbers.forEach(MethodReference::printStatic);
//        numbers.forEach(refMain::printInstance);
//        System.out.println();
////        numbers.forEach(num -> refMain.printInstance(num));
//        names.stream().map(String::chars).forEach(System.out::println);
//        numbers.stream()
//                .filter(MethodReference::isEven)
//                .forEach(System.out::println);
//        numbers.stream()
//                .reduce(Integer::sum)
//                .ifPresent(System.out::println);
//        names.stream()
//                .reduce(String::concat)
//                .ifPresent(System.out::println);
//
//        //Identity, Accumulator, identity is the initial value or the default value
//        var x = names.stream()
//                .reduce("[Reducer]", String::concat);
//        System.out.println(x);
//
//        var y = names.parallelStream()
//                .reduce("", String::concat, String::concat);

        Stream<Stock> stocks = getRecords().stream()
                .map(line -> new Stock(
                        line[0],
                        Arrays.stream(line, 1, line.length)
                                .map(Double::parseDouble)
                                .collect(Collectors.toList())));
        stocks.forEach(Stock::getAverageBySymbol);
    }

    static List<String[]> getRecords() throws IOException {
        return Files.readAllLines(Paths.get("test.csv"))
                .stream()
                .skip(1)
                .map(line -> line.split(","))
                .collect(Collectors.toList());
    }

    static void csvToMap() throws IOException {
        //        Expected output: [x = 10, y = 12, z = 3]
        // Z,10.23,5.15,5.96,6.89,7.88,8.95
        Map<String, Double> averages =
                Files.readAllLines(Paths.get("test.csv"))
                        .stream()
                        .skip(1)
                        .map(line -> line.split(",")) // String[] -> Stream<String[]>
                        .filter(line -> line.length == 7) // Verify the length of the array is 7
                        // [X,10.23,5.15,5.96,6.89,7.88,8.95]
                        .collect(Collectors.toMap(
                                arr -> arr[0],
                                arr -> Arrays.stream(arr, 1, arr.length)
                                        .mapToDouble(Double::parseDouble)
                                        .average()
                                        .orElse(0.0)
                        ));
        averages.entrySet().stream().forEach(System.out::println);
    }

    static boolean isEven(Integer num) {
        return num % 2 == 0;
    }

    static void printStatic(Integer num) {
        System.out.println(num);
    }

    void printInstance(Integer num) {
        System.out.println(num);
    }
}

class Stock {
    private String symbol;
    private List<Double> price;

    Stock(String symbol, List<Double> price) {
        this.symbol = symbol;
        this.price = price;
    }

    public void getAverageBySymbol() {
        System.out.println(symbol + " : " +
                price.stream().reduce(0.0, Double::sum) / price.size());
    }

    @Override
    public String toString() {
        return "Stock{" +
                "symbol='" + symbol + '\'' +
                ", price=" + price +
                '}';
    }
}
