package com.natwest.LoanClosure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanpaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanpaymentApplication.class, args);
	}

}
