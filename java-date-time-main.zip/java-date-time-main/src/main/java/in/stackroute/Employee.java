package in.stackroute;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZonedDateTime;

public class Employee {

    private String name;
    private LocalDate dateOfBirth;
    private ZonedDateTime hiringDate;

    public Employee(String name, LocalDate dateOfBirth, ZonedDateTime hiringDate) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.hiringDate = hiringDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public ZonedDateTime getHiringDate() {
        return hiringDate;
    }

    public void setHiringDate(ZonedDateTime hiringDate) {
        this.hiringDate = hiringDate;
    }

    public int getAge() {
        return Period.between(dateOfBirth, LocalDate.now()).getYears();
    }

    public int getExperience() {
        return Period.between(hiringDate.toLocalDate(), LocalDate.now()).getYears();
    }

    public void print() {
        System.out.println("Name: " + name + ", Age: " + getAge() + ", Experience: " + getExperience());
    }
}
