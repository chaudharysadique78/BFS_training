import { Component } from '@angular/core';

@Component({
  selector: 'app-vegeatable',
  templateUrl: './vegeatable.component.html',
  styleUrl: './vegeatable.component.css'
})
export class VegeatableComponent {
  vegs=[{id:1,name:'Potato',price:20},
  {id:2,name:'Tomato',price:30},
  {id:3,name:'Onion',price:40},
  ];

}
