package in.stackroute.repository;

import org.springframework.stereotype.Repository;

@Repository
// @Component
// This annotation is used to mark this class as a repository
public class UserRepository {

    public void saveUser(String email) {
        System.out.println("[Repository]: User saved with email: " + email);
    }
}
