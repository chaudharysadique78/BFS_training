import { Component } from '@angular/core';

@Component({
  selector: 'app-tomato',
  templateUrl: './tomato.component.html',
  styleUrl: './tomato.component.css'
})
export class TomatoComponent {

}
