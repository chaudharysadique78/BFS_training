import React , { useState } from 'react'


export default function LoanAcDetails() {
    const [customerid, setCustomerId] = useState('');
    const [loanAccounts, setLoanAccounts] = useState([]);
  
    const fetchLoanDetails = () => {
      fetch(`http://localhost:8089/loanAccounts/v1/loanAcDetailsByCustomerId/${customerid}`)
        .then((response) => response.json())
        .then((data) => setLoanAccounts(data))
        .catch((error) => console.error('Error fetching loan details:', error));
    };
  
    return (
        <div>
        <h2>Loan Account Details by Customer ID</h2>
        <div>
          <label>Customer ID:</label>
          <input
            type="text"
            value={customerid}
            onChange={(e) => setCustomerId(e.target.value)}
          />
          <button onClick={fetchLoanDetails}>Fetch Loan Accounts</button>
        </div>
        <div>
          <h3>Loan Account Details:</h3>
          <ul>
            {loanAccounts.map((account) => (
              <li key={account.loanId}>

                
               
              <strong>Account Number:</strong> {account.accountNumber}<br />
              <strong>Sort Code:</strong> {account.sortCode}<br />
              <strong>Account Opening Date:</strong> {account.accountopeningdate}<br />
              <strong>Opening Loan Amount:</strong> {account.openingLoanAmount}<br />
              <strong>Outstanding Loan Amount:</strong> {account.outstandingLoanAmount}<br />
              <strong>ROI:</strong> {account.roi}<br />
              <strong>Tenure:</strong> {account.tenure}<br />
              <strong>EMI Frequency:</strong> {account.emiFrequency}<br />
            
              </li>
            ))}
          </ul>
        </div>
      </div>
   );
}
