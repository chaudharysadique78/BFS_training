import { Component } from '@angular/core';
import { HttpCallService } from '../http-call.service';
import { user } from '../users';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  constructor(private httCallObj:HttpCallService){}
users:user[]=[];
FetchData(){
  alert(this.httCallObj.getWelcome());
   this.httCallObj.getAllData().subscribe((res)=>{
    this.users=res;
      console.log(res)
   })
}
saveData(){
  this.httCallObj.saveData({id:3,name:"Rahul",email:"r@g.com"}).subscribe((res)=>{
    console.log(res)
  });
}
deleteData(){
  this.httCallObj.deleteData(2).subscribe((res)=>{
    alert("Deleted");
  });
  
}
updateData(){
  this.httCallObj.updateData().subscribe((res)=>{
    console.log(res);
  });
}
backEndData(){
  this.httCallObj.getBackendData().subscribe((res)=>{
    console.log(res);
  });
}
addExternalApi(){
  this.httCallObj.postBackEnd({id:103,name:"Rohit",email:"vir@"}).subscribe((res)=>{
    alert("Data Added");
  });
}
}
