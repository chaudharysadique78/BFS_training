import React from 'react'
import hero from '../Images/hero2.JPG'
import Header from '../Header/Header'
import './Home.css'
import Caraousel from '../Caraousel/Caraousel'
// import FAQ from '../FAQ/FAQ'
import Feature from '../Feature/Feature'
import Footer from '../Footer/Footer'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import topu from '../Images/topu.JPG'
// import HeaderTop from '../HeaderTop/HeaderTop'
import calc from '../Images/calc.JPG'
import loan from '../Images/loan.JPG'

export default function Home() {
  return (
    <div>
 <div>
 
        <Header></Header>
    <div className="hero">
        
    <div >
    <img className="pro-block" src={hero} alt="product1"></img>
    </div>

    </div>
    </div>
    <div> 
      <Feature></Feature>
    </div>
<div>
  <Row>
    <Col>
    <h2 className="hivi">Thinking of borrowing more?</h2>
    <br></br>
    <br></br>
    <p>If you already have a loan with us but need to borrow more, we may be able to help.  You can replace your existing loan with a new loan for a larger amount or open a new loan and run two side-by-side.

Borrow more</p>

</Col>
<Col>
<img className="pro-block" src={topu} alt="product2"></img>
</Col>

</Row>

<br></br>
    <br></br>

</div>
<div>
<Row>
  <Col>
  <h2 className="hivi">How long could you borrow for?</h2>
  <br></br>

  <h5 className="borr">You could pay back your loan over one to 10 years – it depends how much you're borrowing and what you're borrowing for.</h5>
  <br></br>
  <br></br>
  <img className="pro-block" src={loan} alt="product3"></img>
  <br></br>
  <br></br>
  <h5 className="borr">The interest rate you pay depends on the loan amount and your personal circumstances. A small change up or down in the amount you decide to borrow could make a big difference to how much interest you pay overall.  </h5>
  </Col>

  <Col>
  <h1 className="sidi">Loan calculator</h1>
  <br></br>
   
  <img className="pro-block" src={calc} alt="product4"></img>
  </Col>
  <br></br>
    <br></br>
    </Row>

    <br></br>
    <br></br>
</div>

<div> <Caraousel/></div>



<Footer/>
</div>
  )
}