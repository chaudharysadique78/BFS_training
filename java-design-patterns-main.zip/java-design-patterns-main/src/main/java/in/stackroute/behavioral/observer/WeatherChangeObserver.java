package in.stackroute.behavioral.observer;

public class WeatherChangeObserver implements Observer {

    private float temperature;
    private float humidity;
    private float pressure;

    @Override
    public void update(float temperature, float humidity, float pressure) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
        display();
    }

    public void display() {
        // Generate weather report on Previous data and new data
        System.out.println("Weather Report: ");
        System.out.println("Current Temperature: " + temperature + " degree Celsius" + "\n" +
                "Current Humidity: " + humidity + "%" + "\n" +
                "Current Pressure: " + pressure + " hPa");
        System.out.println();
    }
}
