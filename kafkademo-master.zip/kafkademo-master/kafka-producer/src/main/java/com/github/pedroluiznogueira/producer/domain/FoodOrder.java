package com.github.pedroluiznogueira.producer.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

import lombok.Data;
import lombok.Value;

@Data
@Value
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class FoodOrder 
{

//	private String item;
//    private Double amount;
    
    String item;
    Double amount;
	
    public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	@Override
	public String toString() {
		return "FoodOrder [item=" + item + ", amount=" + amount + "]";
	}
}
