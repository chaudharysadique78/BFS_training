package in.stackroute.behavioral.strategy.billing;

public class Shipment {

    private double distance;
    private Customer customer;
    private double deliveryCost;

    public Shipment(double distance, Customer customer) {
        this.distance = distance;
        this.customer = customer;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public double getDeliveryCost() {
        return deliveryCost;
    }

    public void setDeliveryCost(double deliveryCost) {
        this.deliveryCost = deliveryCost;
    }

    public void display() {
        System.out.println("Shipment Details: ");
        System.out.println("Customer Name: " + customer.getName());
        System.out.println("Distance: " + distance);
        System.out.println("Delivery Cost: " + deliveryCost);
    }
}
