package in.stackroute.method_hiding;

public class SubClass extends SuperClass {
    static void display() {
        System.out.println("Static method in SubClass.");
    }

    @Override
    void instanceMethod() {
        System.out.println("Instance method in SubClass.");
    }
}
