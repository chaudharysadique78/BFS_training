package in.stackroute.orderservice.service;

import in.stackroute.orderservice.model.Inventory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "inventory-service", url = "http://localhost:9000")
public interface InventoryClient {

    @GetMapping("/api/inventory/{productId}")
    Inventory getInventoryByProductId(@PathVariable("productId") Long productId);

    @PostMapping("/api/inventory")
    Inventory updateInventory(@RequestBody Inventory inventory);
}
