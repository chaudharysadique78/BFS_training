package in.stackroute.structural.adapter;

public class PayPal {

    public void makePayment() {
        System.out.println("Payment is done using PayPal");
    }
}
