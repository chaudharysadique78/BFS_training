package in.stackroute.creational.absfct.dialog;

public interface Dialog {
    void type(String type);

    String onSubmit();
}
