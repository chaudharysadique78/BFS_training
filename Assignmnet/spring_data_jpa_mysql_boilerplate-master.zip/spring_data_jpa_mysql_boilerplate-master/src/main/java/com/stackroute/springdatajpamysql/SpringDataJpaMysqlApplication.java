package com.stackroute.springdatajpamysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaMysqlApplication.class, args);
	}

}
