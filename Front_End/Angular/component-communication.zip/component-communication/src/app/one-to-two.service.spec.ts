import { TestBed } from '@angular/core/testing';

import { OneToTwoService } from './one-to-two.service';

describe('OneToTwoService', () => {
  let service: OneToTwoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OneToTwoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
