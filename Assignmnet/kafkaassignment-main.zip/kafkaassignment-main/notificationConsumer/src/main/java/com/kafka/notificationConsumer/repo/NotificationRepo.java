package com.kafka.notificationConsumer.repo;

import com.kafka.notificationConsumer.dto.NotificationDto;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationRepo extends MongoRepository<NotificationDto,Integer> {
}
