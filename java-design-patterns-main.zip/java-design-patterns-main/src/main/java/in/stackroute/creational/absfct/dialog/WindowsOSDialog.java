package in.stackroute.creational.absfct.dialog;

public class WindowsOSDialog implements Dialog {
    @Override
    public void type(String type) {
        System.out.println("Windows OS Dialog: " + type);
    }

    @Override
    public String onSubmit() {
        return "Windows OS Dialog Submitted!";
    }
}
