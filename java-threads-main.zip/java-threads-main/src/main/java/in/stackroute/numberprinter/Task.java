package in.stackroute.numberprinter;

public class Task {
    private int num = 1;
    private final int MAX = 20;

    public synchronized void printDivisibleBy3() {
        int t3Count = 0;
        while (num <= MAX) {
            System.out.println("Thread 3: being called");
            t3Count++;
            while (num % 3 != 0 && num <= MAX) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            if (num <= MAX) {
                System.out.println("Thread 3: printing " + num);
                num++;
                notifyAll();
            }
        }
        System.out.println("Thread 3 count: " + t3Count);
    }

    public synchronized void printDivisibleBy5() {
        int t5Count = 0;
        while (num <= MAX) {
            System.out.println("Thread 5: being called");
            t5Count++;
            while (num % 5 != 0 && num <= MAX) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            if (num <= MAX) {
                System.out.println("Thread 5: printing" + num);
                num++;
                notifyAll();
            }
        }
        System.out.println("Thread 5 count: " + t5Count);
    }

    public synchronized void printRemaining() {
        int t0Count = 0;
        while (num <= MAX) {
            System.out.println("Thread 0: being called");
            t0Count++;
            while ((num % 3 == 0 || num % 5 == 0) && num <= MAX) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            if (num <= MAX) {
                System.out.println("Thread 0: printing" + num);
                num++;
                notifyAll();
            }
        }
        System.out.println("Thread 0 count: " + t0Count);
    }
}
