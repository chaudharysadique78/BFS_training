
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Paymentapp.css'; // Adjust the path based on the location of your CSS file.
import DashHeader from '../WelcomePage/DashHeader/DashHeader';
import Footer from '../HomePage/Footer/Footer';
import { useNavigate } from "react-router-dom";
import swal from 'sweetalert';
import { Style, Timer } from '@mui/icons-material';

function Paymentapp() {
  let navigate = useNavigate();
  const [error, setError] = useState(null);
  const [accountDetails, setAccountDetails] = useState({});
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [amount, setAmount] = useState('');
  const [remarks, setRemarks] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchAccountDetails = async () => {
      try {
        const customerId = localStorage.getItem('customerid');
        const responseCurrent = await axios.get(`http://localhost:8086/transactions/accounts/${customerId}`);
        const responseLoan = await axios.get(`http://localhost:8086/transactions/loans/${customerId}`);

        if (responseCurrent.status !== 200 || responseLoan.status !== 200) {
          throw new Error('Network response was not ok');
        }

        setAccountDetails({ currentAccounts: responseCurrent.data, loanAccounts: responseLoan.data });
        if (responseCurrent.data.length > 0) {
          setFromAccount(responseCurrent.data[0].accountNumber);
        }
        if (responseLoan.data.length > 0) {
          setToAccount(responseLoan.data[0].accountNumber);
        }
      } catch (error) {
        setError('Error fetching data. Please try again later.');
      }
    };
    fetchAccountDetails();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8086/transactions/transfer', {
        fromAccountNumber: fromAccount,
        toAccountNumber: toAccount,
        amount: parseFloat(amount),
        remarks: remarks,
      });
      console.log(response.data);
      swal("Payment Successful!", { icon: "success" });
      
      navigate("/dash");
      
    } catch (error) {
      console.log('Error transferring amount:', error);
      swal("Insufficient funds", { icon: "warning"});
    }
  };

  if (error) {
    return <div>Error: {error}</div>;
  }


  return (
    <div>
      <DashHeader/>
      <br/><br/>
    <div className="Paymentapp">
      
      <h2>Transfer Funds</h2>
      <p className="register-field">
        From Account: {fromAccount} ({accountDetails.currentAccounts && accountDetails.currentAccounts.length > 0 && accountDetails.currentAccounts[0].accountType})
      </p>
      <p className="register-field">
        To Account: {toAccount} ({accountDetails.loanAccounts && accountDetails.loanAccounts.length > 0 && accountDetails.loanAccounts[0].accountType})
      </p>
      <form onSubmit={handleSubmit}>
      
        <label>
          Amount:
          <input type="text" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </label>
        <label>
          Remarks:
          <input type="text" value={remarks} onChange={(e) => setRemarks(e.target.value)} />
        </label>
        <button  type="submit" style={{ marginLeft: '120px' }}>Make Payment</button>
      </form>
      {message && <p>{message}</p>}
      
    </div>
    <br/>  <br/>
    <Footer/>
    </div>
  );
}

export default Paymentapp;
