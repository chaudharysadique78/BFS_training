package in.stackroute.behavioral.strategy.payments;

public interface PaymentStratergy {
    void pay(double amount);
}
