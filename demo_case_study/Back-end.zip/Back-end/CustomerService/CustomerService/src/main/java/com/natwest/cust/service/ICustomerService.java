package com.natwest.cust.service;

import java.util.List;


import com.natwest.cust.model.Customer;

public interface ICustomerService {
	
	
	
	
public Customer saveCustomer(Customer custObj);

public boolean validateUserService(Integer customerid, String password);
	
	public Customer updateCustomer(Customer custObj,int custId);
	public Customer getCustomerById(int custId);
	public boolean deletCustomerBYId(int custId);
	public List<Customer> getAllCustomers();

	

	Customer findnamebycustid(int customerid);
	
}
