package in.stackroute.bookservice.domain;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "books")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;

    private String authorName;

    @ElementCollection
    private List<String> genre;

    public Book(String title, String authorName, List<String> genre) {
        this.title = title;
        this.authorName = authorName;
        this.genre = genre;
    }
}
