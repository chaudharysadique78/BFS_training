package in.stackroute.creational.absfct.factory;

import in.stackroute.creational.absfct.button.Button;
import in.stackroute.creational.absfct.dialog.Dialog;

public interface ComponentFactory {

    Button createButton();
    Dialog createDialog();
}
