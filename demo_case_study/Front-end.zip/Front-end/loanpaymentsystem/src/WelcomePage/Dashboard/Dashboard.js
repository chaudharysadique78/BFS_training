import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import DashHeader from '../DashHeader/DashHeader';

const Dashboard = () => {
  const { customerid } = useParams();
  const [currentAccount, setCurrentAccount] = useState(null);

  useEffect(() => {
    // Make an API request to retrieve CurrentAccount data using the customerid
    // localstorage.getitem
    axios.get(`http://localhost:8091/cadapi/v1/${customerid}`)
      .then((response) => {
        // Assuming the response contains current account data
        setCurrentAccount(response.data);
      })
      .catch((error) => {
        // Handle errors, e.g., display an error message
        console.error('Error fetching current account data', error);
      });
  }, [customerid]);

  return (
    <div>

<DashHeader></DashHeader>
      <h1>Dashboard</h1>
      {currentAccount ? (
        <div>
          <h2>Current Account Details</h2>
          <p>Account Number: {currentAccount.currentaccount}</p>
          <p>Balance: {currentAccount.balance}</p>
          {/* Add more details here */}
        </div>
      ) : (
        <p>Loading Current Account details...</p>
      )}
    </div>
  );
};

export default Dashboard;
