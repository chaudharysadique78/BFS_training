package com.note.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.note.model.Note;
import com.note.repository.INoteRepository;


@Service
public class NoteServiceImpl implements INoteService 
{
	@Autowired
	private INoteRepository noteRepository;
			
//	public NoteServiceImpl(INoteRepository noteRepository)
//	{
//		this.noteRepository=noteRepository;
//	}
//	
//	@Autowired
//	public void setRepo(INoteRepository noteRepository)
//	{
//		this.noteRepository=noteRepository;
//	}

	@Override
	public Note saveNote(Note noteObj) 
	{
		
		Optional<Note> noteOptional =  this.noteRepository.findById(noteObj.getNoteId());
		
		Note nObj = null;
		
		if(noteOptional.isPresent())
		{
			System.out.println("Note Already Exists ....");
		}
		else
		{
			nObj = this.noteRepository.save(noteObj);
		}
		
		return nObj;
	}

	@Override
	public List<Note> getAllNotes() 
	{
		return this.noteRepository.findAll();
	}

	@Override
	public Note getNote(String noteId) 
	{
		Optional<Note> noteOptional =  this.noteRepository.findById(noteId);
		
		Note nObj = null;
		
		if(noteOptional.isPresent())
		{
			nObj = noteOptional.get();
		}
		else
		{
			System.out.println("Note Details Does Not Exists ....");
		}
		
		return nObj;
	}

	@Override
	public boolean deleteNote(String noteId) {
	
		Optional<Note> noteOptional =  this.noteRepository.findById(noteId);
		
		boolean status=false;
		
		if(noteOptional.isPresent())
		{
			this.noteRepository.delete(noteOptional.get());
			status=true;
		}
		else
		{
			System.out.println("Note Details Does Not Exists ....");
		}
		
		return status;
	}

	@Override
	public Note updateNote(Note noteObj,String noteId) {
	
		Optional<Note> noteOptional =  this.noteRepository.findById(noteId);
		
		Note nObj = null;
		Note noteUpdate = null;
		
		if(noteOptional.isPresent())
		{
			nObj = noteOptional.get();
			
			nObj.setNoteTitle(noteObj.getNoteTitle());
			nObj.setNoteDescription(noteObj.getNoteDescription());
			
			noteUpdate = this.noteRepository.save(nObj);
		}
		else
		{
			System.out.println("Note Details Does Not Exists ....");
		}
		
		return noteUpdate;		
	}
	
	
	@Override
	public Note updateNoteTitle(String noteTitle,String noteId) {
	
		Optional<Note> noteOptional =  this.noteRepository.findById(noteId);
		
		Note nObj = null;
		Note noteUpdate = null;
		
		if(noteOptional.isPresent())
		{
			nObj = noteOptional.get();
			
			nObj.setNoteTitle(noteTitle);			
			noteUpdate = this.noteRepository.save(nObj);
		}
		else
		{
			System.out.println("Note Details Does Not Exists ....");
		}
		
		return noteUpdate;		
	}
}
