package in.stackroute.structural.adapter;

public class Main {

    public static void main(String[] args) {

        PaymentService paymentGateway = new PaymentService("stripe");
        paymentGateway.processPayment(1000);

        paymentGateway = new PaymentService("paypal");
        paymentGateway.processPayment(2000);
    }
}
