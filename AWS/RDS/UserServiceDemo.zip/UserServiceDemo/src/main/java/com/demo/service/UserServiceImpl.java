package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.User;
import com.demo.repository.IUserRepository;

@Service
public class UserServiceImpl implements IUserService 
{
	@Autowired
	private IUserRepository userrepository;
	

	@Override
	public User createUser(User uobj) 
	{

		Optional <User> useropt = this.userrepository.findById(uobj.getUserId());
		
		User userObj = null;
		
		if(useropt.isPresent())
		{
			System.out.println("user details already exists !!!");
		}
		else
		{
			userObj = this.userrepository.save(uobj);
		}
		
		return userObj;
	}

	@Override
	public List<User> getAllUsers() 
	{
		// TODO Auto-generated method stub
		return this.userrepository.findAll();
	}

	@Override
	public User getUserById(int uid) 
	{
		Optional<User> optional =  this.userrepository.findById(uid);
		
		User uobj = null;
		
		if(optional.isPresent())
		{
			uobj = optional.get();
		}
		else
		{
			System.out.println("Records related to the user does not exists ..");
		}
		
		return uobj;
	}

	@Override
	public boolean deleteUserById(int uid) 
	{
		Optional<User> optional =  this.userrepository.findById(uid);
		
		boolean status = false;
		
		if(optional.isPresent())
		{
			this.userrepository.delete(optional.get());
			status=true;
		}
		else
		{
			System.out.println("Records related to the user does not exists ..");
		}
		
		return status;		
	}

	@Override
	public User updateUserById(User userObj, int uid) 
	{
		Optional <User> useropt = this.userrepository.findById(uid);
		
		User uObj =null;
		
		User updateduser=null;
		
		if(useropt.isPresent())
		{
			uObj = useropt.get();
			
			uObj.setUserName(userObj.getUserName());
			uObj.setUserPassword(userObj.getUserPassword());
			uObj.setUserEmail(userObj.getUserEmail());
			
			updateduser = this.userrepository.save(uObj);
		}
		else
		{
			System.out.println("User does not exists ..");
		}
		
		return userObj;
	}
}
