package in.stackroute;

import java.util.Arrays;
import java.util.Objects;

public class Trainee {

    private String fullName;
    private String email;

    public Trainee() {
    }

    public Trainee(String fullName, String email) {
        this.fullName = fullName;
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @Override
    public String toString() {
        return "Trainee{" +
                "fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trainee trainee = (Trainee) o;
        return Objects.equals(fullName, trainee.fullName) && Objects.equals(email, trainee.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fullName, email);
    }
}

/**
 * Access specifiers
 * public       - accessible from anywhere
 * private      - accessible only within the class
 * protected    - accessible within the package and outside the package through inheritance
 * default      - accessible only within the package also known as package-private
 */
