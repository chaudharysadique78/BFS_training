import { Component } from '@angular/core';
import { OneToTwoService } from '../one-to-two.service';

@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrl: './one.component.css'
})
export class OneComponent {
  constructor(private ott:OneToTwoService){}

  username:String='';

  sendData()
  {
    this.ott.username="Rohit Sharma";
  }

}
