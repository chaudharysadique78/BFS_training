import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpCallService {

  constructor(private httpC:HttpClient) { }

  getAllData():Observable<any>{
    return this.httpC.get("http://localhost:3000/users");
  }

  saveData(data:any):Observable<any>{
    return this.httpC.post("http://localhost:3000/users",data);
  }

  deleteData(id:number):Observable<any>
  {
   return this.httpC.delete("http://localhost:3000/users/"+id);
   
  }
  updateData():Observable<any>{
    return this.httpC.put("http://localhost:3000/users/1",{id:1,name:"Rahul Sharma",email:"rs@g.com"});
  }
  getWelcome():string{
    return "Welcome to Angular";
  }
  getBackendData():Observable<any>{
    return this.httpC.get("http://localhost:8083/api/v1/users");
  }

  postBackEnd(user:any):Observable<any>{
    return this.httpC.post("http://localhost:8083/api/v1/user",user);
}

}