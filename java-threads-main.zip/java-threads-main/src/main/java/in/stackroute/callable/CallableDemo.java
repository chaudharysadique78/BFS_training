package in.stackroute.callable;

import java.util.concurrent.*;

public class CallableDemo {
    public static void main(String[] args) {

        ExecutorService executor = Executors.newFixedThreadPool(2);
        Callable<String> stringCallableT1 = () -> {
            Thread.sleep(3000);
            return "Hello World 1";
        };
        Callable<String> stringCallableT2 = () -> {
            Thread.sleep(5000);
            return "Hello World 2";
        };

        CompletableFuture<String> completableFuture = CompletableFuture.supplyAsync(() -> {
            System.out.println("HW-CF1 " + Thread.currentThread().getName());
            return "Hello World from CompletableFuture 1 ";
        }, executor);
        CompletableFuture<String> completableFuture2 = CompletableFuture.supplyAsync(() -> {
            System.out.println("HW-CF2 " + Thread.currentThread().getName());
            return "Hello World from CompletableFuture 2 ";
        }, executor);
        CompletableFuture<String> chainedFuture = completableFuture.thenApply(result -> {
            return result + " Chained";
        });

        chainedFuture.thenAccept(System.out::println);
        completableFuture2.thenAccept(System.out::println);

        CompletableFuture<String> cf1 = CompletableFuture.supplyAsync(() -> "Hello World CF1");
        CompletableFuture<String> cf2 = CompletableFuture.supplyAsync(() -> "Hello World CF2");
        CompletableFuture<Void> allOf = CompletableFuture.allOf(cf1, cf2);
        allOf.thenRun(() -> {
            try {
                System.out.println(cf1.get());
                System.out.println(cf2.get());
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        });
        executor.shutdown();


//
//        Future<String> future1 = executor.submit(stringCallableT1);
//        Future<String> future2 = executor.submit(stringCallableT2);
//
//        try {
//            System.out.println(future1.get()); // 3 seconds
//            System.out.println(future2.get()); // 10 seconds
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
    }
}
