import React from 'react';
import Card from 'react-bootstrap/Card';
import './Review.css';

export default function Review({ text, author }) {
  return (
    <Card>
      <Card.Body>
        <Card.Text>{text}</Card.Text>
      </Card.Body>
      <Card.Footer className="text-muted">- {author}</Card.Footer>
     
    </Card>
  );
}
