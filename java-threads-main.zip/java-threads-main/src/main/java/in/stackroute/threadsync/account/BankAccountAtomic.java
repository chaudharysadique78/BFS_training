package in.stackroute.threadsync.account;

import java.util.concurrent.atomic.AtomicLong;

public class BankAccountAtomic {

    /**
     *  AtomicLong is a class in Java that provides atomic operations on integers. It is used in concurrency control
     *  to prevent
     *  <a href="https://www.geeksforgeeks.org/atomic-variables-in-java/">...</a>
     *  CAS (Compare and Swap) operation is used to perform atomic operations on the value of the Atomic variable.
     *  <a href="https://www.geeksforgeeks.org/atomic-variables-in-java/">...</a>
     *  CAS algorithm is used to implement lock-free data structures. It is based on three simple operations:
     *  Read the current value.
     *  Compare the current value with the expected value.
     *  Update the value if the current value is equal to the expected value.
     */

    private AtomicLong balance;

    public BankAccountAtomic(long balance) {
        this.balance = new AtomicLong(balance);
    }

    public double getBalance() {
        return balance.get();
    }

    public void deposit(long amount) {
        balance.addAndGet(amount);
    }

    public void withdraw(long amount) {
        if (balance.get() >= amount) {
            balance.addAndGet(-amount);
        } else {
            System.out.println("Insufficient " +
                    "balance");
        }
    }
}
