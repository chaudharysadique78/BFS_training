package in.stackroute.creational.absfct.dialog;

public class MacOSDialog implements Dialog {
    @Override
    public void type(String type) {
        System.out.println("MacOS Dialog: " + type);
    }

    @Override
    public String onSubmit() {
        return "MacOS Dialog Submitted!";
    }
}
