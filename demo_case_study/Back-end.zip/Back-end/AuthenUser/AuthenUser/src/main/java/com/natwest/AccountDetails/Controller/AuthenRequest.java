package com.natwest.AccountDetails.Controller;

public class AuthenRequest {
    private Integer customerId;
    private String debitCardNo;
    private Integer pinCode;
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getDebitCardNo() {
		return debitCardNo;
	}
	public void setDebitCardNo(String debitCardNo) {
		this.debitCardNo = debitCardNo;
	}
	public Integer getPinCode() {
		return pinCode;
	}
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "AuthenticationRequest [customerId=" + customerId + ", debitCardNo=" + debitCardNo + ", pinCode="
				+ pinCode + "]";
	}

 
}
