package in.stackroute.behavioral.strategy.payments;

public class CreditCardStrategy implements PaymentStratergy {

    private final int cvv;
    private final String cardNumber;

    public CreditCardStrategy(int cvv, String cardNumber) {
        this.cvv = cvv;
        this.cardNumber = cardNumber;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Amount paid using Credit Card: " + amount + " with card number: "
                + cardNumber + " and cvv: " + cvv);
    }
}
