package in.stackroute.creational.absfct;

import in.stackroute.creational.absfct.factory.ComponentFactory;
import in.stackroute.creational.absfct.factory.MacOSFactory;
import in.stackroute.creational.absfct.factory.WindowsOSFactory;

public class Main {
    public static void main(String[] args) {
        String os = System.getProperty("os.name").toLowerCase();
        ComponentFactory factory = getFactory(os);
        createUI(factory);
    }

    static ComponentFactory getFactory(String os) {
        if (os.contains("windows")) {
            return new WindowsOSFactory();
        } else {
            return new MacOSFactory();
        }
    }

    static void createUI(ComponentFactory factory) {
        factory.createButton().onClick();
        factory.createDialog().type("Hello World!");
        System.out.println(factory.createDialog().onSubmit());
    }
}
