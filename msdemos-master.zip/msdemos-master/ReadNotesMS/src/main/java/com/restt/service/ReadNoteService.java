package com.restt.service;

import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class ReadNoteService {
	
	
	public String getNote() throws IOException,RestClientException
	{
		
		String noteUrl = "http://localhost:8089/api/v1/allNotes";
		
		RestTemplate restTemplate = new RestTemplate();
		
		String noteResponse = null;
		try
		{	
			noteResponse = restTemplate. exchange(noteUrl, HttpMethod.GET, getHeaders() ,String.class).getBody();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Note Data From Note Service :: "+noteResponse;
    }
	
	public static HttpEntity<?> getHeaders() throws IOException 
	{
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
}
