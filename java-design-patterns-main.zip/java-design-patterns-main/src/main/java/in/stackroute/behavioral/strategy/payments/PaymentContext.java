package in.stackroute.behavioral.strategy.payments;

public class PaymentContext {

    private PaymentStratergy paymentStrategy;

    public PaymentContext(PaymentStratergy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void pay(double amount) {
        paymentStrategy.pay(amount);
    }

    public void setPaymentStrategy(PaymentStratergy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public PaymentStratergy getPaymentStrategy() {
        return paymentStrategy;
    }
}
