package in.stackroute.springbootjpatx.repository;

import in.stackroute.springbootjpatx.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

// @Repository - annotation is not required as JpaRepository
public interface UserRepository extends JpaRepository<User, Integer> {

    Optional<User> findByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.email = :email AND u.password = :password") // JPA Query
    Optional<User> findWithCredentials(String email, String password);
}
/**
 * JDBC                 - Java Database Connectivity
 * JPA                  - Java Persistence API
 * Spring Data JPA      - Spring Data Java Persistence API
 */
