package com.authorFinder.favorite_service.service;

public class FavouriteServiceImpl implements FavouriteService{
}
