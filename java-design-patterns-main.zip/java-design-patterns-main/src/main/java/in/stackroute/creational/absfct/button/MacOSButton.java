package in.stackroute.creational.absfct.button;

public class MacOSButton implements Button {
    @Override
    public void render() {
        System.out.println("MacOSButton is rendered");
    }

    @Override
    public void onClick() {
        System.out.println("MacOSButton is clicked");
    }
}
