package in.stackroute.greeting;

public class HelloGreeting implements Greeting {
    @Override
    public void greet() {
        System.out.println("Hello, World!");
    }
}
