package in.stackroute;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Main {

    // var x = 10; error - cannot use var at class level
    // final var y = 10; error - cannot use var at class level

    public static void main(String[] args) {

        Trainer trainer = new Trainer("John Doe", "john.doe");
        Trainer trainer2 = new Trainer("John Doe", "john.doe");

        Trainee trainee1 = new Trainee("John Doe", "john.doe");
        trainee1.setFullName("");

        Trainee trainee2 = new Trainee("Jane Doe", "jane.doe");
//        Trainee trainee3 = trainee1;

        System.out.println(trainee1.hashCode());
        System.out.println(trainee2.hashCode());
        System.out.println(trainee1.equals(trainee2));
//        System.out.println(trainee3.hashCode());
    }

    static void workingWithOptionals() {
        // Optionals
        // What is an Optional? - a container object which may or may not contain a non-null value
        // Why Optional? - to avoid NullPointerException

        String name = null;
        Optional<String> optionalName = Optional.ofNullable(name);
        optionalName.orElseThrow(() -> new IllegalArgumentException("Name cannot be empty"));
        if(optionalName.isEmpty()) {
            throw  new IllegalArgumentException("name cannot be empty");
        }
    }

    static void localTypeInference() {
        // Local type inference
        var trainees = List.of("John", "Jane", "Jack", "Jill"); // immutable list
        var numbers = List.of(1, 2, 3, 4, 5, "10");

        // var x = null; error - cannot use var with null
        // var x; // error - cannot use var without initialization
        var trainees2 = new ArrayList<>(trainees); // mutable list
        trainees2.add("James");
        // trainees2.add(1);

        for (var trainee : trainees2) {
            System.out.println(trainee);
        }
    }

    static String prepTrainees() {
        Trainee[] trainees = new Trainee[5];
        trainees[0] = new Trainee("John Doe", "john.doe");
        trainees[1] = new Trainee("Jane Doe", "jane.doe");
        trainees[2] = new Trainee("John Smith", "john.smith");
        trainees[3] = new Trainee("Jane Smith", "jane.smith");
        trainees[4] = new Trainee("John Doe", "john.doe");

        for (Trainee trainee : trainees) {
            System.out.println("Trainee Name: " + trainee.getFullName() +
                    " Email: " + trainee.getEmail());
        }

        for (Trainee trainee : trainees) {
            System.out.println(trainee);
        }
        var x = "hello";

        final var y = 10;
        // static var z = 10; // error - cannot use var with static
        return x;
    }

    static void basicArray() {
        // Arrays
        // What is an Array? - static data structure, used to store multiple values of same data type

        // Declaration of an Array
        int[] arr = new int[5]; // Declaration of an array of size 5

        // Assigning values into array
        arr[0] = 10;
        arr[1] = 20;
        arr[2] = 30;
        arr[3] = 40;
        arr[4] = 50;

        System.out.println("Size of the array: " + arr.length);
        System.out.println("The values in the array are: ");
        for (int i : arr) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}