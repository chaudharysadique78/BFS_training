package in.stackroute.springbootjpatx.service;

import in.stackroute.springbootjpatx.domain.User;
import in.stackroute.springbootjpatx.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public Optional<User> findWithCredentials(String email, String password) {
        return userRepository.findWithCredentials(email, password);
    }

    @Override
    @Transactional(rollbackOn = {SQLException.class, RuntimeException.class})
    // Rollback on SQLException
    public User save(User user) {
        return userRepository.save(user);
    }

    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }
}
