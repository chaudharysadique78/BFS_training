package com.natwest.cs.service;

import java.util.List;

import com.natwest.cs.model.Complaint;



public interface IComplaintService {

	
public Complaint saveComplaint(Complaint comObj);
	
	public List<Complaint> getAllComplaints();
	
	
}
