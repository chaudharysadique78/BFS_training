import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Fullpayment.css';
import DashHeader from '../WelcomePage/DashHeader/DashHeader';
import Footer from '../HomePage/Footer/Footer';
import { useNavigate } from "react-router-dom";
import swal from 'sweetalert';

function Fullpayment() {
  let navigate = useNavigate();
  const [error, setError] = useState(null);
  const [accountDetails, setAccountDetails] = useState({});
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [loanbalance, setLoanBalance] = useState('');
  const [remarks, setRemarks] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    
    const fetchAccountDetails = async () => {
      try {
        const customerId = localStorage.getItem('customerid');
        const responseCurrent = await axios.get(`http://localhost:8086/transactions/accounts/${customerId}`);
        const responseLoan = await axios.get(`http://localhost:8086/transactions/loans/${customerId}`);

        if (responseCurrent.status !== 200 || responseLoan.status !== 200) {
          throw new Error('Network response was not ok');
        }

        setAccountDetails({ currentAccounts: responseCurrent.data, loanAccounts: responseLoan.data });

        if (responseCurrent.data.length > 0) {
          setFromAccount(responseCurrent.data[0].accountNumber);
        }

        if (responseLoan.data.length > 0) {
          setToAccount(responseLoan.data[0].accountNumber);
          setLoanBalance(responseLoan.data[0].loanBalance);
        
        }
      } catch (error) {
        setError('Error fetching data. Please try again later.');
      }
    };
    fetchAccountDetails();
  }, []);

  const handleSubmit = async (e) => {
    console.log(loanbalance)
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8086/transactions/transfer', {
        fromAccountNumber: fromAccount,
        toAccountNumber: toAccount,
        amount: parseFloat(loanbalance),
        remarks: remarks,
      });
      console.log(response.data);
      swal('Payment Successful! Request Sent for loan Closure!', { icon: 'success' });
      navigate("/dash");
    } catch (error) {
      console.log('Error transferring amount:', error);
      swal('Insufficient funds', { icon: 'warning' });
    }
  };

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <DashHeader />
      <br />
      <br />
      <div className="Paymentapp">
        <h2>Full Loan Payment</h2>
        <p>
          From Account: {fromAccount} ({accountDetails.currentAccounts && accountDetails.currentAccounts.length > 0 && accountDetails.currentAccounts[0].accountType})
        </p>
        <p>
          To Account: {toAccount} ({accountDetails.loanAccounts && accountDetails.loanAccounts.length > 0 && accountDetails.loanAccounts[0].accountType})
        </p>
        <p>
          Loan Balance: {loanbalance} 
        </p>
        <form onSubmit={handleSubmit}>
          <label>
            Remarks:
            <input type="text" value={remarks} onChange={(e) => setRemarks(e.target.value)} />
          </label>
          <button type="submit " style={{ marginLeft: '120px' }}>Make Payment</button>
        </form>
        {message && <p>{message}</p>}
      </div>
      <br />
      <br />
      <Footer />
    </div>
  );
}

export default Fullpayment;
