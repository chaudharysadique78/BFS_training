package in.stackroute.interface_methods;

public interface Notification {

    void sendEmail(String email);

    // Introduced from version 2.0
    default void sendIM(String im) {

    }

    default void sendSMS(String sms) {

    }

    static void hello() {

    }

    private void anotherMethod() {

    }
}
