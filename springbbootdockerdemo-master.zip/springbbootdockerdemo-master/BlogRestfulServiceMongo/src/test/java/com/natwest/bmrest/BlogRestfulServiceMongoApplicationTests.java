package com.natwest.bmrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogRestfulServiceMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
