
package com.natwest.cust;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.natwest.cust.model.Customer;
import com.natwest.cust.repository.ICustomerRepository;
import com.natwest.cust.service.CustomerServiceImpl;

public class CustomerServiceImplTest {

    private CustomerServiceImpl customerService;
    private ICustomerRepository custRepository;

    @BeforeEach
    public void setUp() {
        custRepository = mock(ICustomerRepository.class);
        customerService = new CustomerServiceImpl(custRepository);
    }

    @Test
    public void testValidateUserServiceSuccess() {
        // Arrange
        Integer customerId = 1;
        String password = "password123";

        // Mock the behavior of custRepository.validateUser to return a Customer
        when(custRepository.validateUser(customerId, password)).thenReturn(new Customer());

        // Act
        boolean result = customerService.validateUserService(customerId, password);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testValidateUserServiceFailure() {
        // Arrange
        Integer customerId = 1;
        String password = "password123";

        // Mock the behavior of custRepository.validateUser to return null
        when(custRepository.validateUser(customerId, password)).thenReturn(null);

        // Act
        boolean result = customerService.validateUserService(customerId, password);

        // Assert
        assertFalse(result);
    }
}


//import static org.mockito.Mockito.*;
//import static org.junit.jupiter.api.Assertions.*;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import com.natwest.cust.model.Customer;
//import com.natwest.cust.repository.ICustomerRepository;
//import com.natwest.cust.service.CustomerServiceImpl;
//
//import java.util.Optional;
//
//	public class CustomerServiceImplTest {
//
//	    private CustomerServiceImpl customerService;
//	    private ICustomerRepository custrepository;
//
//	    @BeforeEach
//	    public void setUp() {
//	        custrepository = mock(ICustomerRepository.class);
//	        customerService = new CustomerServiceImpl(custrepository);
//	    }
//
//	    @Test
//	    public void testUpdateCustomerSuccess() {
//	        // Arrange
//	        int customerId = 1;
//	        Customer existingCustomer = new Customer(); // Create a Customer instance
//	        existingCustomer.setCustomerid(customerId);
//	        existingCustomer.setPassword("oldPassword"); // Set the old password
//
//	        Customer updatedCustomer = new Customer();
//	        updatedCustomer.setCustomerid(customerId);
//	        updatedCustomer.setPassword("newPassword"); // Set the new password
//
//	        when(custrepository.findById(customerId)).thenReturn(Optional.of(existingCustomer));
//	        when(custrepository.save(existingCustomer)).thenReturn(updatedCustomer);
//
//	        // Act
//	        Customer result = customerService.updateCustomer(updatedCustomer, customerId);
//
//	        // Assert
//	        verify(custrepository, times(1)).findById(customerId);
//	        verify(custrepository, times(1)).save(existingCustomer);
//	        assertEquals("newPassword", result.getPassword());
//	    }
//
//	    @Test
//	    public void testUpdateCustomerNotFound() {
//	        // Arrange
//	        int customerId = 1;
//	        Customer updatedCustomer = new Customer();
//	        updatedCustomer.setCustomerid(customerId);
//	        updatedCustomer.setPassword("newPassword");
//
//	        when(custrepository.findById(customerId)).thenReturn(Optional.empty());
//
//	        // Act
//	        Customer result = customerService.updateCustomer(updatedCustomer, customerId);
//
//	        // Assert
//	        verify(custrepository, times(1)).findById(customerId);
//	        verify(custrepository, never()).save(any());
//	        assertNull(result); // Assuming you return null when the customer is not found
//	    }
//	}
