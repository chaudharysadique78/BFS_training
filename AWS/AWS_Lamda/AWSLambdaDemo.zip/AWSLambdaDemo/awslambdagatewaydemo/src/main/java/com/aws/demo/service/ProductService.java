package com.aws.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.aws.demo.dto.Product;

@Service
public class ProductService 
{	
	private final List<Product> products = new ArrayList<>();
	
	//Method to add a product to the list
	public void addProduct(Product product) {
		products.add(product);
	}
	
	// Method to get all products	
	public List<Product> getProducts() {
		return products;
	}
	
	// Method to get a product by id
	public Product getProduct(String id) {
		return products.stream().filter(product -> product.getId().equals(id)).findFirst().orElse(null);
	}
	
	// Method to delete a product by id
	public void deleteProduct(String id) {
		products.removeIf(product -> product.getId().equals(id));
	}
	
	// Method to update a product by id
	public void updateProduct(String id, Product product) {
		Product existingProduct = products.stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
		if (existingProduct != null) {
			products.remove(existingProduct);
			products.add(product);
		}
	}
}