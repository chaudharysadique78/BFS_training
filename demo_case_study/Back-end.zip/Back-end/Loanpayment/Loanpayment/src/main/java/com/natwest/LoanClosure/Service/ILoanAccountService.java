package com.natwest.LoanClosure.Service;

import java.util.List;

import com.natwest.LoanClosure.Model.LoanAccount;

public interface ILoanAccountService {

	List<LoanAccount> getLoansByCustomerId(Long customerId);
}
