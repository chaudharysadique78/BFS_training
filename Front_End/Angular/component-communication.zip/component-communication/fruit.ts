export type Fruit={
    name:string;
    color:string;
    price:number;
}