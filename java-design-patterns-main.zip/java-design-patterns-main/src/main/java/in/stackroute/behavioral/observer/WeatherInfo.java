package in.stackroute.behavioral.observer;

import java.util.ArrayList;
import java.util.List;

// Concrete Subject class, WeatherInfo
public class WeatherInfo implements Subject {

    private float temperature;
    private float humidity;
    private float pressure;
    private final List<Observer> observers;

    public WeatherInfo() {
        observers = new ArrayList<>();
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        if(observers.isEmpty()) {
            System.out.println("No Observers to notify");
            return;
        }
        observers.forEach(observer -> observer.update(temperature, humidity, pressure));
    }

    public void setWeatherData(float temperature, float humidity, float pressure) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
        notifyObservers();
    }
}
