import React, { useState } from 'react';
import Stack from 'react-bootstrap/Stack';
import ban1 from '../Images/banner.jpg'
import { Formik, Form, Field } from 'formik';
import './Login.css';
import { useNavigate } from "react-router-dom";
import swal from 'sweetalert';
import pl1 from '../Images/FSCS_Protected_Logo.png'
import Header from '../Header/Header';
import Footr from '../Footr/Footr';
import { Container, Row, Col , Button} from 'react-bootstrap';
// import ban2 from '../Images/banner2.jpg'

// ------------------------
const LoginForm = () => {
    let navigate = useNavigate();
    function xyz(){
      navigate("/register")}
      
    const initialValues = {
      customerid: '',
      password: '',
    };
    
    const [loggedIn, setLoggedIn] = useState(false);

  

const handleSubmit = (values) => {
  fetch('http://localhost:8080/auth/v1/login', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify(values),
  })
  .then((response) => {
      if (response.ok) {
          return response.json();
      } else {
          setLoggedIn(false);
          swal("Invalid Credentials", { icon: "warning" });
      }
  })
  .then((data) => {
      if (data) {
          setLoggedIn(true);
          swal("You have Logged in Successfully", { icon: "success" });

          // Store customerid in local storage
          localStorage.setItem('customerid', data.customerid);
          localStorage.setItem('token', data.token);
          navigate("/dash");
      }
  })
  .catch((error) => {
      console.error('Error:', error);
      document.getElementById("message").innerText = "Login failed";
  });
};

// ... (remaining code)

  //   const handleSubmit = (values) => {
  //     fetch('http://localhost:8080/auth/v1/login', {
  //       method: 'POST',
  //       headers: {
  //           'Content-Type': 'application/json',
  //       },
  //         body: JSON.stringify(values),
  //   })
  
  //   .then((response) => {
  //     if (response.ok) {
  //       setLoggedIn(true);
  //       swal("You have Logged in Successfully" ,{icon:"success"})
  //       localStorage.setItem('customerid', values.customerid); 
        
  //       // Redirect to a dashboard or perform other actions
  //     navigate("/dash");
      
  //       return response.text();

        
        
        
        
  //     } else {
  //       setLoggedIn(false);
  //       swal("Invalid Credentials" ,{icon:"warning"})
      
        
  //     }
  // })
  // .then((token) => {
  //   localStorage.setItem('token', token);  
    
  // })
  
 
 
  // .catch((error) => {
  //   console.error('Error:', error);
  //   document.getElementById("message").innerText = "Login failed";
  // });
  // };
// ------------------------------------
    return(
<div>
  <Header/>
    
<section className='seca'>
    
<h3 className='ons1'>Online Banking services</h3>
<img className="pl1" src={pl1} alt="Image One"/>
<Stack direction="horizontal" gap={3}>

<div className="p-2">
<img className="ban1" src={ban1} alt="Image One"/>

</div>
<div className='logform'> 

    
      {loggedIn ? (
        <p>You are logged in!</p>
        
        
      ) : (
        <Formik initialValues={initialValues} onSubmit={handleSubmit}>
          <Form autoComplete="off">
            <div className="lc1">
            <h2 className='logh'>Login Form</h2>
            </div>
            <br></br>
            <p>Use your Customer ID to login</p>
            <div className='srfe'>
            <Field type="customerid" className="customerid" id="customerid" placeholder="Enter your Customer ID" name="customerid"  required />
            </div>
            <br></br>
            <div>
            <Field  type="password" className="pass" id="password" name="password" placeholder="Enter your Password" required />
            </div>
            <br></br>
            <div>
            <button type="submit" className="btlog" > Login </button>
            </div>
          </Form>  
                
        </Formik>
        
      )}

      <p className='naru'>Not a registered user?</p>
      <button className="rsu" onClick={xyz} >Sign up here</button>
  
    </div>
    {/* <div className="p-2">
    <img className="ban2" src={ban2} alt="Image One"/>

    </div> */}
      </Stack>
      </section>

      <section className='secb'>
        <p className='sbh1'>Only individuals who have a NatWest account and authorised access to <br/> Online Banking should proceed beyond this point. For the security of <br/>customers, any unauthorised attempt to access customer bank information <br/> will be monitored and may be subject to legal action.</p>
      </section>
      <Footr></Footr>
    
</div>
        
    )
    }


 

    export default LoginForm;