package in.stackroute.interface_methods;

public class NotificationImpl implements Notification {

    @Override
    public void sendEmail(String email) {
        System.out.println("Sending email to " + email);
    }

    @Override
    public void sendIM(String im) {
        System.out.println("Sending IM to " + im);
    }
}
