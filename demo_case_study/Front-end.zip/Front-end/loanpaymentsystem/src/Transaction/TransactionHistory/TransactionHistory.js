import React, { useState, useEffect } from 'react';
import TransactionCreationForm from '../TransactionCreation.js/TransactionCreationForm';

const TransactionHistory = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('http://localhost:8080/api/transactions')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        setTransactions(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err);
        setLoading(false);
      });
  }, []);

  const addTransaction = (newTransaction) => {
    // Update the local state with the new transaction in real-time
    setTransactions([...transactions, newTransaction]);

    // Make a POST request to your Spring Boot API to save the new transaction
    fetch('http://localhost:8080/api/transactions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fromAccount: newTransaction.fromAccount,
        toAccount: newTransaction.toAccount,
        amount: newTransaction.amount,
        remarks: newTransaction.remarks,
        transactionDate: newTransaction.transactionDate,
        customerid: newTransaction.customerid
      }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        // Data returned by the server can be ignored or used as needed
      })
      .catch((err) => {
        // Handle errors
      });
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (error) {
    return <div className="error">Error: {error.message}</div>;
  }

  if (transactions.length === 0) {
    return <div className="empty">No transactions to display.</div>;
  }

  return (
    <div className="transaction-history">
      <h2>Transaction History</h2>
      <ul>
        {transactions.map((transaction) => (
          <li
            key={transaction.id}
            className={
              transaction.amount < 0 ? 'debit-transaction' : 'credit-transaction'
            }
          >
            <div className="transaction-date">
              Date: {transaction.transactionDate}
            </div>
            <div className="transaction-description">
              Description: {transaction.remarks}
            </div>
            <div className="transaction-amount">
              Amount: ${transaction.amount}
            </div>
            <div className="transaction-type">
              Type: {transaction.amount < 0 ? 'Debit' : 'Credit'}
            </div>
          </li>
        ))}
      </ul>
      <TransactionCreationForm addTransaction={addTransaction} />
    </div>
  );
};

export default TransactionHistory;
