package com.natwest.rs.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.natwest.rs.model.Request;
import com.natwest.rs.repository.IRequestRepo;
@Service
public class RequestImpl implements IRequestService {
	
	
	@Autowired
	private IRequestRepo reqrepository;

	@Override
	public Request saveRequest(Request reqObj) {
		// TODO Auto-generated method stub
		
		Optional<Request> reqoptinal = this.reqrepository.findById(reqObj.getCustomerid());
		
		
		Request addreq =null;
		if(reqoptinal.isPresent())
		{
			
			System.out.println("Data already exist");
		}
		
		
		else
		{
			addreq = this.reqrepository.save(reqObj);
		}
		return addreq;
	}
		
		@Override
		public List<Request> getAllRequests() {
			return this.reqrepository.findAll();
	}

}
