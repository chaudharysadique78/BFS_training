package in.stackroute;

public record TrainerShort(String fullName) { }

