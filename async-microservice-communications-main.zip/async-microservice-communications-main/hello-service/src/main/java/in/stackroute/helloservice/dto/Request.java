package in.stackroute.helloservice.dto;

public record Request(String auditMessage) {
}
