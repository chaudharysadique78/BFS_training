package com.webc.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.webc.dto.NoteDto;

import reactor.core.publisher.Mono;

@Service
public class NoteServiceImpl implements INoteService
{
	
	private WebClient webClient;

	@Override
	public NoteDto getNotes() 
	{
		NoteDto noteDto = webClient.get()
				.uri("http://localhost:8082/api/v1/allNotes").retrieve().bodyToMono(NoteDto.class).block();
	
		return noteDto;
	}

	@Override
	public Mono<NoteDto> addNotes() {
	
		return webClient.post().uri("http://localhost:8082/api/v1/addNote")
				.body(Mono.just(new NoteDto()), NoteDto.class).retrieve().bodyToMono(NoteDto.class);
		
		
	}
	
	addNotes().subscribe(System.out::println);
}
