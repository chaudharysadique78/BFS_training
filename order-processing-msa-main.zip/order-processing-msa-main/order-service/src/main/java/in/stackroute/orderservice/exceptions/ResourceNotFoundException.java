package in.stackroute.orderservice.exceptions;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String orderNotFound) {
    }
}
