package com.kafka.notificationConsumer.dto;

import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Document(collection = "notification")
public class NotificationDto {
    @MongoId
    private int id;
    private String message;
    private String recipient;

}
