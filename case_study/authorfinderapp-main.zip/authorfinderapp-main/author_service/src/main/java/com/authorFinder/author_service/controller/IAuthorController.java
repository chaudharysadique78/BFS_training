package com.authorFinder.author_service.controller;

import com.authorFinder.author_service.entity.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.val;
import org.springframework.http.ResponseEntity;

import java.util.List;

@Tag(name = "Author API", description = "Author API for search author from third party API")
public interface IAuthorController {

    @Operation(summary = "Register users", description = "Register users")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Successful operation")
    @Schema(implementation = ApiResponse.class)
    ResponseEntity<ApiResponse> fetchAuthor(String name);

}
