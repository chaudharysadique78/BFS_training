import React, { useState } from 'react';
import './ComplimentForm.css';
import swal from 'sweetalert';
import { Modal } from 'react-bootstrap';
export default function ComplimentForm({ onClose, onSubmit }) {
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  // const [isExistingCustomer, setIsExistingCustomer] = useState(false);
  const [complimentMessage, setComplimentMessage] = useState('');
  
  const handleSubmit = () => {
    const formData = {
      fullName,
      mobileNumber,
      // isExistingCustomer,
      complimentMessage,
    };
  // Make a POST request to your backend API
  fetch('http://localhost:8089/comapi/v1/compliments', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(formData),
  })
    .then((response) => {
      if (response.ok) {
        // Handle a successful response from the server (e.g., show a success message)
        console.log('Compliment submitted successfully.');
        swal("Thank You for the Compliment !", { icon: "success" });
      } else {
        // Handle an error response from the server (e.g., show an error message)
        console.error('Error submitting compliment.');
      }
    })
    .catch((error) => {
      // Handle any network-related errors
      console.error('Network error:', error);
    });



  onClose(); // Close the modal
};

  return (
    <div className="compliment-form-modal">
      <div className="modal-content">
        <h2 className="hv">Add Your Compliment</h2>
        <div className="form-group">
          <label htmlFor="fullName">Full Name:</label>
          <input autoComplete='off'
            type="text"
            id="fullName"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="mobileNumber">Mobile Number:</label>
          <input autoComplete='off'
            type="text"
            id="mobileNumber"
            value={mobileNumber}
            onChange={(e) => setMobileNumber(e.target.value)}
          />
        </div>
        {/* <div className="form-group">
          <label>
            <input
              type="checkbox"
              checked={isExistingCustomer}
              onChange={() => setIsExistingCustomer(!isExistingCustomer)}
            />{' '}
            Existing Customer
          </label>
        </div> */}
        <div className="form-group">
          <label htmlFor="complimentMessage">Compliment Message:</label>
          <textarea
            id="complimentMessage"
            rows="4"
            value={complimentMessage}
            onChange={(e) => setComplimentMessage(e.target.value)}
          ></textarea>
        </div>
        <div>
        <button onClick={handleSubmit}>Submit</button>
        <br></br>
        <br></br>
        <button onClick={onClose}>Close</button>
        </div>
     
      </div>
    </div>
  );
}











