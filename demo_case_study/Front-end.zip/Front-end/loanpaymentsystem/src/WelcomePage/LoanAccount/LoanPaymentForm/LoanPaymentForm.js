
import React, { useState } from 'react';

export default function LoanPaymentForm() {
    const [currentAccount, setCurrentAccount] = useState('');
    const [loanAccount, setLoanAccount] = useState('');
    const [paymentType, setPaymentType] = useState('full');
    const [amount, setAmount] = useState('');
  
    const handleSubmit = async (e) => {
      e.preventDefault();
  
      // Make an API request to process the payment
      try {
        const response = await fetch('/api/payment', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            currentAccount,
            loanAccount,
            paymentType,
            amount,
          }),
        });
  
        if (response.ok) {
       // Payment successful
      const data = await response.json();
      // Update the UI with new data
      // Assuming the API response contains updated currentAccount, loanAccount, and transaction data
      setCurrentAccount(data.updatedCurrentAccount);
      setLoanAccount(data.updatedLoanAccount);
      // You may also update the transaction history components with new data
        } else {
          // Payment failed, show an error message
        }
      } catch (error) {
        console.error('Payment failed:', error);
      }
    };
  
    return (
      <div>
        <h2>Make Loan Payment</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="currentAccount">Current Account:</label>
            <input
              type="text"
              id="currentAccount"
              value={currentAccount}
              onChange={(e) => setCurrentAccount(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="loanAccount">Loan Account:</label>
            <input
              type="text"
              id="loanAccount"
              value={loanAccount}
              onChange={(e) => setLoanAccount(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="paymentType">Payment Type:</label>
            <select
              id="paymentType"
              value={paymentType}
              onChange={(e) => setPaymentType(e.target.value)}
            >
              <option value="full">Full Payment</option>
              <option value="partial">Partial Payment</option>
            </select>
          </div>
          <div>
            <label htmlFor="amount">Amount:</label>
            <input
              type="text"
              id="amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <button type="submit">Make Payment</button>
        </form>
      </div>
    );
  }