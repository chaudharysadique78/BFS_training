package in.stackroute.creational.absfct.button;

public interface Button {
    void render();
    void onClick();
}
