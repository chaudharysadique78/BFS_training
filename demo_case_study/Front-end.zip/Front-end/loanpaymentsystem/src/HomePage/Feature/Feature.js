import React from 'react'
import Accordion from 'react-bootstrap/Accordion';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import './Feature.css'; 

export default function Feature() {
  return (
    <div>

<br></br>
    <br></br> 
<h2 className='sidi'>Manage my existing loan</h2>
<br></br>
    <br></br>
        <div className="al">
        <Row>
            <Col>
    <h2>Making an extra payment</h2>
    
    </Col>
    <br></br>
    <br></br>
    <Col>
    <h2>Getting a settlement figure and closing your loan</h2>
    <br></br>
    </Col>
    </Row>
    <Accordion>
        <Row>
            <Col>
    <Accordion.Item eventKey="0">
      <Accordion.Header className="hd">Can I make an extra payment on my loan?</Accordion.Header>
      <Accordion.Body>
   
      <br></br>
To see how much it will cost to make an additional payment, you can use our online form  to request your additional payment illustration
<br></br>
<br></br>
We’ll be in touch within 2 working days to tell you how your overpayment could change your monthly payment, the length of your loan and the next steps to making this extra payment. You can choose to receive this information by email, text or both.
<br></br>
<br></br>
You can make overpayments or additional payments to your loan at any time. An overpayment can reduce the total amount of interest you’ll pay (overpayments are subject to an early repayment charge), and you can choose if you want to reduce the term of your loan, or keep your original term and reduce your monthly payments.
<br></br>
<br></br>
For more information, see paying off a loan early
<br></br>
<br></br>
</Accordion.Body>
    </Accordion.Item>
    </Col>
    <br></br>
    <br></br>
    <br></br>
   
    <Col>
    <Accordion.Item eventKey="1">
      <Accordion.Header className="hd">How do I get a settlement figure for my loan and close it?</Accordion.Header>
      <Accordion.Body>
 
      <br></br>
The quickest way to get a settlement figure and pay off your loan account is via the mobile app.
<br></br>
<br></br>
1. Download and log in to app
<br></br>
<br></br>
2. Click on loan account
<br></br>
<br></br>
3. Click pay my loan
<br></br>
<br></br>
4. Settlement quote will be shown in the journey (you will be able to download a PDF).
<br></br>
5. If you then decide to pay off your loan, you can do so by following the on-screen instructions.
<br></br>
<br></br>
For more information on closing your loan account, visit the early repayment charges page.
<br></br>
<br></br>
 If you would rather request closure of your account online, or do not have a mobile device, complete the request form  for an early settlement quote.
 <br></br>
 <br></br>
Please note, if you’ve had your loan for more than 14 days, the balance you see on Online Banking is not the amount needed to pay off your loan in full. The balance shown doesn’t include any early settlement charges nor accrued but unapplied interest.
<br></br>
<br></br>
The quickest way to view your interest is to use the mobile app.
      </Accordion.Body>
    </Accordion.Item>
    </Col>
    </Row>
    </Accordion >
    </div>
    <br></br>
    <br></br>
    <br></br>
    <br></br>

    <div className="al">
    <Row>
            <Col>
    <h2>Changing loan payment date</h2>
    </Col>
    <br></br>
    <br></br>
    <Col>
    <h2>Receiving loan funds</h2>
    <br></br>
    </Col>
    </Row>
    <Accordion>
    <Row>
            <Col>
    <Accordion.Item eventKey="2">
      <Accordion.Header className="hd">How do I change my loan payment date?</Accordion.Header>
      <Accordion.Body>
    <br></br>

You might want to change your loan payment date if you've recently started a new job and your salary date has been changed.
<br></br>
<br></br>
If you pay your loan by direct debit we are able to amend this over the phone.
<br></br>
<br></br>
If you pay your loan by standing order you can change this in Online Banking however you must also call us to let us know you would like to change the payment date.
<br></br>
<br></br>
We will normally be able to process your request during the call, unless you call us within 3 working days of your current payment date.
<br></br>
<br></br>
You may be required to make 2 payments in the same calendar month. You may be able to avoid this. Our lending team are here to help and support you, so you can choose the most appropriate loan payment date.
<br></br>
<br></br>
Changing your repayment date will change your loan term slightly, which will impact the total amount of interest you pay, we will give you more details of this on the phone.
<br></br>
<br></br>
 </Accordion.Body>
    </Accordion.Item>
    </Col>
    <br></br>
    <br></br>
    <br></br>
    <Col>
    <Accordion.Item eventKey="3">
      <Accordion.Header className="hd">How soon will I receive my money from my NatWest loan?</Accordion.Header>
      <Accordion.Body>
    
      <br></br>

If you log in and apply online or use the app and the loan application is unconditionally accepted and you sign your loan documents before 5.45pm Mon – Fri (excluding bank holidays) funds could be sent to your current account the same evening.
<br></br>
<br></br>
Sometimes  it can take longer and we may need to contact you for more information. Where this is the case, we may ask you to upload supporting documents we require (we'll let you know if we need this) via our secure online portal – DigiDocs.
<br></br>
<br></br>
</Accordion.Body>
    </Accordion.Item>
    </Col>
    </Row>
    <br></br>
    <br></br>
    <br></br>
  </Accordion>
  </div>
  </div>
  )
}
