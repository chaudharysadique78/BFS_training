package in.stackroute.bookservice.clients.restclient;

import in.stackroute.bookservice.dto.AuthorDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
@Slf4j
public class AuthorServiceRestClientImpl implements AuthorServiceRestClient {

    private final RestClient restClient;

    public AuthorServiceRestClientImpl(RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public AuthorDto getAuthorByIdViaRestClient(String id) {
        log.debug("Calling (getAuthorByIdViaRestClient) author service with id: {}", id);
        ResponseEntity<AuthorDto> response = restClient
                .get()
                .uri("/api/v1/author/{id}", id)
                .retrieve()
                .toEntity(AuthorDto.class);
        log.debug("Author data: {}", response);
        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        }
        throw new RuntimeException("Author not found");
    }

    @Override
    public AuthorDto postAuthorViaRestClient(AuthorDto authorDto) {
        log.debug("Calling (postAuthorViaRestClient) author service with authorDto: {}", authorDto);
        ResponseEntity<AuthorDto> response = restClient
                .post()
                .uri("/api/v1/author")
                .body(authorDto)
                .retrieve()
                .toEntity(AuthorDto.class);
        log.debug("Author data: {}", response);
        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        }
        throw new RuntimeException("Author not created");
    }
}
