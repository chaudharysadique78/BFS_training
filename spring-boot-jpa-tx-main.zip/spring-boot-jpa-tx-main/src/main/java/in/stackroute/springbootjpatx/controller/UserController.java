package in.stackroute.springbootjpatx.controller;

import in.stackroute.springbootjpatx.domain.User;
import in.stackroute.springbootjpatx.dto.UserRequestDto;
import in.stackroute.springbootjpatx.dto.UserResponseDto;
import in.stackroute.springbootjpatx.service.UserService;
import in.stackroute.springbootjpatx.utils.DtoUtil;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private final UserService userService;
    private  final DtoUtil dtoUtil;

    public UserController(UserService userService, DtoUtil dtoUtil) {
        this.userService = userService;
        this.dtoUtil = dtoUtil;
    }

    // GET /api/v1/users
    // Status code: 200 `OK`            if successful
    // Status code: 204 `No Content`    if no users found
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        var response = userService.findAll();
        if (response.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(response);
    }

    // GET /api/v1/users?email={email}
    // Status code: 200 `OK`            if successful
    // Status code: 204 `No Content`    if no user found
    @GetMapping(params = "email")
    public ResponseEntity<User> getUserByEmail(@RequestParam String email) {
        String emailPattern = "^(.+)@(.+)$";
//        if(email.matches(emailPattern)) {
//            return ResponseEntity.badRequest().build();
//        } // If email is not provided in the correct format, return 400 `Bad Request`
        var response = userService.findByEmail(email);
        return response.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.noContent().build());
    }

    // EMP_ID = EHR001
    // Create regEx pattern that will verify if the String starts with E and then has 2 uppercase letters and then 3 digits
    // String pattern = "^E[A-Z]{2}\\d{3}$";

    // POST /api/v1/users
    // Status code: 201 `Created`       if successful
    // Status code: 400 `Bad Request`   if user already exists
    // Status code: 500 `Internal Server Error` if any other error occurs
    // Request body:
    // {
    //     "name": "",
    //     "email": "",
    //     "password": ""
    // }
    // Response body:
    // {
    //     "id": 1,
    //     "name": "",
    //     "email": "",
    //     "status": ""
    // }
    @PostMapping
    public ResponseEntity<UserResponseDto> createUser(@RequestBody @Valid UserRequestDto dto) {
        var entity  = dtoUtil.toEntity(dto);
        // Check if user already exists by email
        userService.findByEmail(entity.getEmail()).ifPresent(user -> {
            dtoUtil.toResponseDto(user, HttpStatusCode.valueOf(400));
            ResponseEntity.status(400).body(user);
        });
        var user = userService.save(entity);
        var responseDto = dtoUtil.toResponseDto(user, HttpStatusCode.valueOf(201));
        return ResponseEntity.status(201).body(responseDto);
    }

    // POST /api/v1/users/authenticate
    // Status code: 200 `OK`            if successful
    // Status code: 401 `Unauthorized`   if user not found
    // Status code: 500 `Internal Server Error` if any other error occurs
    // Request body:
    // {
    //     "email": "",
    //     "password": ""
    // }
    // Response body:
    // {
    //     "id": 1,
    //     "name": "",
    //     "email": "",
    //     "status": ""
    // }
    @PostMapping("/authenticate")
    public ResponseEntity<UserResponseDto> authenticateUser(@RequestBody UserRequestDto dto) {
        var user = userService.findWithCredentials(dto.email(), dto.password());
        if(user.isEmpty()) {
            return ResponseEntity.status(401).build();
        }
        var responseDto = dtoUtil.toResponseDto(user.get(), HttpStatusCode.valueOf(200));
        return ResponseEntity.ok(responseDto);
    }

//    Controller level exception handling
//    @ExceptionHandler(MethodArgumentNotValidException.class)
//    public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
//        var errors = ex.getBindingResult().getFieldErrors().stream()
//                .map(error -> error.getField() + ": " + error.getDefaultMessage())
//                .toArray();
//        return ResponseEntity.badRequest().body(errors);
//    }
}
