package in.stackroute;

public sealed class Shape
        permits Circle, Rectangle {
}

//class X extends Shape {}
// Error: class X is not allowed to extend sealed class Shape

/**
 * Sealed classes
 * https://docs.oracle.com/en/java/javase/17/language/sealed-classes-and-interfaces.html
 */
