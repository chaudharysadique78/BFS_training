package com.natwest.cust.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.natwest.cust.model.Customer;
import com.natwest.cust.service.CustomerServiceImpl;


import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.ServletException;

@Tag(name = "Authentication", description = "The Authentication Service")
@RestController
@RequestMapping("auth/v1")
@CrossOrigin("*")
public class UserAuthenController {

	private Map<String,String> map = new HashMap<>();
	
	private CustomerServiceImpl custService;
	
	
	
	@Autowired
	public UserAuthenController(CustomerServiceImpl custService) {
		super();
		this.custService = custService;
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> doLogin(@RequestBody Customer cust) {
	    try {
	        String jwtToken = generateToken(cust.getCustomerid(), cust.getPassword());

	        map.put("message", "Customer Successfully LoggedIn");
	        map.put("token", jwtToken);

	        // Storing customerid and name in local storage
	        map.put("customerid", String.valueOf(cust.getCustomerid()));
	        

	    } catch (Exception e) {
	        map.put("message", e.getMessage());
	        map.put("token", null);
	        return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
	    }

	    return new ResponseEntity<>(map, HttpStatus.OK);
	}

	
//	@PostMapping("/login")
//	public ResponseEntity<?> doLogin(@RequestBody Customer cust) {
//	    try {
//	        String jwtToken = generateToken(cust.getCustomerid(), cust.getPassword());
//
//	        map.put("message", "Customer Successfully LoggedIn");
//	        map.put("token", jwtToken);
//
//	        // Storing customerid in local storage
//	        map.put("customerid", String.valueOf(cust.getCustomerid()));
//	        
//	       
//	        
//
//	    } catch (Exception e) {
//	        map.put("message", e.getMessage());
//	        map.put("token", null);
//	        return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
//	    }
//
//	    return new ResponseEntity<>(map, HttpStatus.OK);
//	}


	

//	@PostMapping("/login")
//	public ResponseEntity<?> doLogin(@RequestBody Customer cust){
//		try {
//			
//			String jwtToken = generateToken(cust.getCustomerid(), cust.getPassword());
//			
//
//		
//			map.put("message", "Customer Successfully LoggedIn");
//			
//			map.put("token", jwtToken);
//		
//		
//		} catch (Exception e) {
//			map.put("message", e.getMessage());
//			map.put("token", null);
//			return new ResponseEntity<>(map,HttpStatus.UNAUTHORIZED);
//		}
//		
//		return new ResponseEntity<>(map,HttpStatus.OK);
//	}
	
//	===kanchan===
//	 @PostMapping("/login")
//	    public ResponseEntity<?> doLogin(@RequestBody Customer cust) {
//	        try {
//	            int customerid = cust.getCustomerid();
//	            String password = cust.getPassword();
//	            
//	            // Validate the customer and get the first name
//	            String name = custService.getnamebycustid(customerid, password);
//	            System.out.println("Name: " + name);
//	            
//	            if (name != null) {
//	                String jwtToken = generateToken(customerid, password);
//	                Map<String, Object> response = new HashMap<>();
//	                response.put("message", "User Successfully LoggedIn");
//	                response.put("token", jwtToken);
//	                response.put("custid", customerid);
//
//	                return new ResponseEntity<>(response, HttpStatus.OK);
//	            } else {
//	                return new ResponseEntity<>("Invalid Credentials", HttpStatus.UNAUTHORIZED);
//	            }
//	        } catch (Exception e) {
//	            return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);
//	        }
//	    }
	
	private String generateToken(Integer customerid, String password) throws ServletException {
		String jwtToken = "";
		if(customerid == null || password == null) {
			throw new ServletException("Please send valid customerId and password");
		}
		// Convert the integer customerId to a string
       String customerIdStr = Integer.toString(customerid);
		
		//validate user aginst db
		boolean flag= 	custService.validateUserService(customerid, password);
		if(!flag)
			throw new ServletException("Invalid Credentials");
		else {
			jwtToken = Jwts.builder()
							.setSubject(customerIdStr)
					        .setIssuedAt(new Date())
					        .setExpiration(new Date(System.currentTimeMillis() + 3000000))
					        .signWith(SignatureAlgorithm.HS256, "secret key")
					        .compact();
		}
		return jwtToken;
	}	
	
	
	
}
