package in.stackroute.behavioral.strategy.billing;

public interface DeliveryCostStratergy {

    double calculateDeliveryCost(double distance);
}

/**
 * I want to calculate the delivery cost based on the distance.
 * I have two strategies to calculate the delivery cost.
 *  1. Normal delivery cost is 10 rupees per kilometer.
 *  2. Premium delivery cost is 5 rupees per kilometer.
 */