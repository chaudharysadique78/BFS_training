package com.natwest.AccountDetails.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
public class UserEntity {

    @Id
    private Integer customerid;
    private String debitcardno;
    private Integer pincode;
	public Integer getCustomerid() {
		return customerid;
	}
	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}
	public String getDebitcardno() {
		return debitcardno;
	}
	public void setDebitcardno(String debitcardno) {
		this.debitcardno = debitcardno;
	}
	public Integer getPincode() {
		return pincode;
	}
	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "UserEntity [customerid=" + customerid + ", debitcardno=" + debitcardno + ", pincode=" + pincode + "]";
	}


}
