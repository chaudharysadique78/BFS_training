package in.stackroute.greeting;

/**
 * This is a functional interface which has a single abstract method greet().
 */
@FunctionalInterface
public interface Greeting {

    public void greet();
}

@FunctionalInterface
interface Math {
    int perform(int a, int b);
}
