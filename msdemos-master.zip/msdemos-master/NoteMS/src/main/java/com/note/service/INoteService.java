package com.note.service;

import java.util.List;

import com.note.model.Note;

public interface INoteService 
{
	
	public Note saveNote(Note noteObj);
	public List<Note> getAllNotes();
	public Note getNote(String noteId);
	public boolean deleteNote(String noteId);
	public Note updateNote(Note noteObj, String noteId);
	public Note updateNoteTitle(String noteTitle,String noteId);		
}
