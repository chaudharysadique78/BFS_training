package in.stackroute.orderservice.controller;

import in.stackroute.orderservice.model.Order;
import in.stackroute.orderservice.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.tags.Tags;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/order")
@Tags({
        @Tag(name = "Order API", description = "Order API for managing orders"),
        @Tag(name = "Order API", description = "Allows to manage orders")
})
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    @Operation(summary = "Get all orders", description = "Get all orders")
    @ApiResponse(responseCode = "200", description = "Successful operation")
    @Schema(implementation = Order.class)
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get order by ID", description = "Get order by ID")
    @ApiResponse(responseCode = "200", description = "Successful operation")
    @Parameter(name = "id", description = "Order ID", required = true)
    public Order getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id);
    }

    @PostMapping
    @Operation(summary = "Create order", description = "Create order", method = "POST")
    @ApiResponse(responseCode = "200", description = "Successful operation")
    @Schema(implementation = Order.class)
    public Order createOrder(@RequestBody Order order) {
        return orderService.createOrder(order);
    }


    @DeleteMapping("/{id}")
    @Operation(summary = "Delete order", description = "Delete order", method = "DELETE")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Successful operation"),
            @ApiResponse(responseCode = "404", description = "Order not found")

    })
    @Parameter(name = "id", description = "Order ID", required = true)
    public void deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
    }
}
