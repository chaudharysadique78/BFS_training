package in.stackroute.creational.factory;

public class Main {
    public static void main(String[] args) {
        Shape circle = ShapeFactory.getShape("CIRCLE");
        circle.draw();

        Shape square = ShapeFactory.getShape("SQUARE");
        square.draw();

        if(circle instanceof Circle c) {
            // Circle c = (Circle) circle; // no need to cast in Java 16
            c.setRadius(5.0);
            System.out.println("Circle radius: " + c.getRadius());
        }
    }
}
