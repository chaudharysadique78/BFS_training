package com.authorFinder.user_service.controller;

import com.authorFinder.user_service.model.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.tags.Tags;
import org.springframework.http.ResponseEntity;


@Tag(name = "User API", description = "User API for managing Users")
public interface IUserController {

    @Operation(summary = "Register users", description = "Register users")
    @ApiResponse(responseCode = "200", description = "Successful operation")
    @Schema(implementation = User.class)
    ResponseEntity<User> registerUser(User user) throws JsonProcessingException;


    @Operation(summary = "Update users", description = "Update users")
    @ApiResponse(responseCode = "200", description = "Successful operation")
    @Schema(implementation = User.class)
    ResponseEntity<User> updateUser(User user, int id);

}
