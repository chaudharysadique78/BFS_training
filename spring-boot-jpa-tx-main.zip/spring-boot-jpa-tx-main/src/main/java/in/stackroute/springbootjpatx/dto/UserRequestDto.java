package in.stackroute.springbootjpatx.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import org.hibernate.validator.constraints.Length;

public record UserRequestDto(
        @NotEmpty(message = "Name is required")
        String name,

        @NotEmpty(message = "Email is required")
        @Email(message = "Email should be valid")
        String email,

        @NotEmpty(message = "Password is required")
        @Length(min = 6, message = "Password should be at least 6 characters")
        String password
) {
}
