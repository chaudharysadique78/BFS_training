package org.example;

public abstract class AbstractFactory {
    abstract Shape getShape(String shapeType);
}
