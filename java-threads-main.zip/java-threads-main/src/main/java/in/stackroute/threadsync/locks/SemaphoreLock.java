package in.stackroute.threadsync.locks;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class SemaphoreLock {

    private static final int MAX_PERMIT = 3;
    private static final Semaphore semaphore = new Semaphore(MAX_PERMIT);

    static class Resource implements Runnable{
        private final int taskId;

        Resource(int taskId) {
            this.taskId = taskId;
        }

        @Override
        public void run() {
            try {
                semaphore.acquire();
                System.out.println("Task " + taskId + " acquired the lock. Thread: " + Thread.currentThread().getName()
                        + " Available permits: " + semaphore.availablePermits());
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }finally {
                semaphore.release();
                System.out.println("Task " + taskId + " released the lock");
            }
        }
    }

    public static void main(String[] args) {

        ExecutorService executor = Executors.newFixedThreadPool(10);
        for (int i = 0; i < 10; i++) {
            executor.submit(new Resource(i));
        }
        executor.shutdown();
    }
}
