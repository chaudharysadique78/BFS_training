package com.authorFinder.author_service.service;

import com.authorFinder.author_service.entity.ApiResponse;
import lombok.val;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface AuthorService {

    ApiResponse fetchAuthor(String name);

}
