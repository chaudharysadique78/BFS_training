package in.stackroute;

public enum Operation {
    // create four math operation constants
    ADD {
        @Override
        public int apply(int a, int b) {
            return a + b;
        }

        @Override
        public int anotherMethod() {
            return 0;
        }
    },
    SUBTRACT {
        @Override
        public int apply(int a, int b) {
            return a - b;
        }

        @Override
        public int anotherMethod() {
            return 0;
        }
    },
    MULTIPLY {
        @Override
        public int apply(int a, int b) {
            return a * b;
        }

        @Override
        public int anotherMethod() {
            return 0;
        }
    },
    DIVIDE {
        @Override
        public int apply(int a, int b) {
            return a / b;
        }

        @Override
        public int anotherMethod() {
            return 0;
        }
    },
    MODULUS {
        @Override
        public int apply(int a, int b) {
            return a % b;
        }

        @Override
        public int anotherMethod() {
            return 0;
        }
    };

    public abstract int apply(int a, int b);    // abstract method

    public abstract int anotherMethod();    // abstract method
}
