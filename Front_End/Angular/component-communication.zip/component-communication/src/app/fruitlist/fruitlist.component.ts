import { Component, Input } from '@angular/core';
import { Fruit } from '../../../fruit';

@Component({
  selector: 'app-fruitlist',
  templateUrl: './fruitlist.component.html',
  styleUrl: './fruitlist.component.css'
})
export class FruitlistComponent {

  @Input()
  fruits:Fruit[]=[];

}
