package com.demo.service;

import java.util.List;

import com.demo.model.User;

public interface IUserService 
{
	public User createUser(User uobj);
	public List<User> getAllUsers();
	
	public User getUserById(int uid);
	public boolean deleteUserById(int uid);
	
	public User updateUserById(User uobj,int uid);

	
}
