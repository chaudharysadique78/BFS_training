package com.webc.dto;

public class NoteDto {
	
	private String noteId;
	private String noteTitle;
	private String noteDescription;
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public String getNoteTitle() {
		return noteTitle;
	}
	public void setNoteTitle(String noteTitle) {
		this.noteTitle = noteTitle;
	}
	public String getNoteDescription() {
		return noteDescription;
	}
	public void setNoteDescription(String noteDescription) {
		this.noteDescription = noteDescription;
	}
	@Override
	public String toString() {
		return "NoteDto [noteId=" + noteId + ", noteTitle=" + noteTitle + ", noteDescription=" + noteDescription + "]";
	}
}
