package com.restt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadNotesMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
