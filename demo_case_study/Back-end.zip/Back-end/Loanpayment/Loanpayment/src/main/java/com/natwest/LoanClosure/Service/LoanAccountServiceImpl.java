package com.natwest.LoanClosure.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.natwest.LoanClosure.Model.LoanAccount;
import com.natwest.LoanClosure.Repository.LoanAccountRepository;

@Service
public class LoanAccountServiceImpl implements ILoanAccountService {
	
	private final LoanAccountRepository loanRepository;
	
	@Autowired
    public LoanAccountServiceImpl(LoanAccountRepository loanRepository) {
        this.loanRepository = loanRepository;
    }

	@Override
	public List<LoanAccount> getLoansByCustomerId(Long customerId) {
	     return loanRepository.findByCustomerId(customerId);
	}
}
