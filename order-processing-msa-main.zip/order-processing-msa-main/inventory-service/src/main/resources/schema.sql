create table if not exists inventory (
    id serial primary key,
    product_id integer not null,
    quantity integer not null
);