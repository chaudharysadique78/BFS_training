package com.kafka.notificationProducer.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kafka.notificationProducer.entity.Notification;
import com.kafka.notificationProducer.service.ProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/producer")
public class ProducerController {

    @Autowired
    private ProducerService producerService;

    @PostMapping("/sendNotification")
    public String sendNotification(@RequestBody Notification notification) {
        try {
            producerService.sendMessage(notification);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return "Notification send to: " + notification.getRecipient();
    }
}
