import React, { useState, useEffect } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import './Chatbot.css';

function Chatbot() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const addMessage = (text, sender) => {
    const newMessage = { text, sender };
    setMessages([...messages, newMessage]);
  };

  const handleUserInput = (e) => {
    setInput(e.target.value);
  };

  const handleAutoResponse = (response) => {
    // Add user message
    addMessage(input, 'user');

    // Add chatbot's auto-response
    addMessage(response, 'chatbot');

    // Clear the input field
    setInput('');
  };

  useEffect(() => {
    // Simulate an initial chatbot greeting
    setTimeout(() => {
      const initialGreeting = 'Hello! How can I help you?';
      addMessage(initialGreeting, 'chatbot');
    }, 1000);
  }, []);

  const getChatbotResponse = (userMessage) => {
    userMessage = userMessage.toLowerCase();

    if (userMessage.includes('pay loan online')) {
      return "Are you a registered online user?";
    } else if (userMessage === 'yes') {
      return "Great! You can proceed with the online payment.";
    } else if (userMessage === 'no') {
      return "To register as an online user, please visit our website and follow the registration process.";
    } else {
      return `You said: "${userMessage}"`;
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (input.trim() === '') return;

    const response = getChatbotResponse(input);

    // If the chatbot response includes options, display buttons for "yes" and "no"
    if (response.includes('Are you a registered online user?')) {
      addMessage(input, 'user');
      handleAutoResponse(response);
    } else {
      handleAutoResponse(response);
    }
  };

  return (
    <Container className="chatbot-container">
      <Card className="chatbot-card">
        <Card.Body className="chatbot-messages">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`message ${message.sender}`}
            >
              {message.text}
            </div>
          ))}
        </Card.Body>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="chatInput">
            <Form.Control
              type="text"
              placeholder="Type a message..."
              value={input}
              onChange={handleUserInput}
            />
          </Form.Group>
          <Button variant="primary" type="submit">
            Send
          </Button>
        </Form>
      </Card>
    </Container>
  );
}

export default Chatbot;
