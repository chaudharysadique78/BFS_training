package in.stackroute.structural.adapter;

public class Stripe {

    public void processPayment() {
        System.out.println("Payment is done using Stripe");
    }
}
