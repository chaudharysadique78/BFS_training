package in.stackroute.creational.factory;

public interface Shape {

    void draw();
}
