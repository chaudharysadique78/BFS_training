package org.example;

public class Ractangle implements Shape{
    public void draw() {
     System.out.println("Draw Ractangle");
    }
}
