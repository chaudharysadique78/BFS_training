package in.stackroute.bookservice.clients.resttemplate;

import in.stackroute.bookservice.dto.AuthorDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class AuthorServiceRestTemplateClientImpl implements AuthorServiceRestTemplateClient {

    // RestTemple is in a maintenance mode
    // Synchronous communication
    private final RestTemplate restTemplate;
    private final String url = "http://localhost:8081/api/v1/author";

    public AuthorServiceRestTemplateClientImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public AuthorDto getAuthorByIdViaRestTemplate(String id) {
        ResponseEntity<AuthorDto> response = restTemplate.getForEntity(url.concat("/{id}"), AuthorDto.class, id);
        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        }
        throw new RuntimeException("Author not found");
    }

    @Override
    public AuthorDto postAuthorViaRestTemplate(AuthorDto authorDto) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        HttpEntity<AuthorDto> request = new HttpEntity<>(authorDto, headers);
        ResponseEntity<AuthorDto> response = restTemplate.postForEntity(url, request, AuthorDto.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        }
        throw new RuntimeException("Author not found");
    }


}
