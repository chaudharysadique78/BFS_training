package in.stackroute.behavioral.strategy.billing;

public class Main {

    public static void main(String[] args) {

        Customer regularCustomer = new Customer("John", false);
        Customer premiumCustomer = new Customer("Jane", true);

        ShipmentContext context = new ShipmentContext();

        Shipment regularShipment = new Shipment(10, regularCustomer);
        Shipment premiumShipment = new Shipment(8, premiumCustomer);

        if(regularCustomer.isPremiumCustomer()) {
            regularShipment.setDeliveryCost(context.calculateDeliveryCost(regularShipment.getDistance()));
        } else {
            context = new ShipmentContext(new RegularCustomerDeliveryCostStratergy());
            premiumShipment.setDeliveryCost(context.calculateDeliveryCost(regularShipment.getDistance()));
        }

        regularShipment.display();
        System.out.println();
        premiumShipment.display();
    }
}
