package com.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfiguration 
{

	@Bean
	public RouteLocator customRouteLocator(RouteLocatorBuilder builder) 
	{
		return builder.routes().route("NoteMSRoute", r -> r.path("/api/v1/**").uri("http://localhost:8082"))
//				.route("UserMSRoute", r -> r.path("api/v1/**").uri("http://localhost:8081"))
//				.route("AuthMSRoute", r -> r.path("api/v1/**").uri("http://localhost:8083"))
//				.route("CategoryMSRoute", r -> r.path("api/v1/**").uri("lb://CATEGORY-SERVICE"))
				.build();
	}
}