package in.stackroute.behavioral.strategy.payments;

public class PayPalStrategy implements PaymentStratergy {

    private final String paypalUserName;

    public PayPalStrategy(String paypalUserName) {
        this.paypalUserName = paypalUserName;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Amount paid using PayPal: " + amount + " with username: " + paypalUserName);
    }
}
