package com.stackroute.streams;

import java.util.*;
import java.util.stream.Collectors;

public class BatsmanService {

    public BatsmanService() {
    }

    public Optional<Batsman> getBatsman(List<Batsman> batsmanList, String bastmenName, String countryCode) {
        if (batsmanList != null && bastmenName != null) {
            List<String> bastmans = batsmanList.stream().map(Batsman::getName).map(bastmen -> bastmen.toLowerCase()).collect(Collectors.toList());
            if (!bastmans.contains(bastmenName.toLowerCase())) {
                return Optional.empty();
            }
        }
        if (batsmanList == null || bastmenName == null || countryCode == null) {
            return Optional.empty();
        }
        return Optional.of(batsmanList.stream().filter(batsman -> batsman.getName().equalsIgnoreCase(bastmenName) && batsman.getCountry().getCountryCode().equalsIgnoreCase(countryCode)).findFirst().orElseThrow(() -> new CountryNotFoundException("Country not found")));

    }

    public String getBatsmanNamesForCountry(List<Batsman> batsmanList, String countryCode) {
        if (batsmanList == null || countryCode == null || batsmanList.isEmpty()) {
            return null;
        }
        return batsmanList.stream().filter(batsman -> batsman.getCountry().getCountryCode().equalsIgnoreCase(countryCode)).map(Batsman::getName).sorted().collect(Collectors.joining(",", "[", "]"));
    }

    public Map<String, Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList) {
        if (batsmanList == null || batsmanList.isEmpty()) {
            return new HashMap<>();
        }
        return batsmanList.stream().filter(batsman -> batsman.getMatchesPlayed() > 50).collect(Collectors.toMap(Batsman::getName, Batsman::getTotalRuns));
    }

    public Integer getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String countryName) {
        if (batsmanList == null || batsmanList.isEmpty()) {
            return 0;
        }
        return batsmanList.stream().filter(batsman -> batsman.getCountry().getName().equalsIgnoreCase(countryName)).map(Batsman::getHighestScore).sorted(Comparator.reverseOrder()).findFirst().get();
    }

    public Optional<List<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String countryName) {
        if (batsmanList == null || batsmanList.isEmpty() || countryName == null) {
            return Optional.empty();
        }
        List<String> result = batsmanList.stream().filter(batsman -> batsman.getCountry().getName().equalsIgnoreCase(countryName) && batsman.getTotalRuns() > 5000).map(Batsman::getName).toList();
        LinkedList list = new LinkedList<>(result);
        list.sort(Comparator.reverseOrder());
        if (list.size() == 0) {
            return Optional.empty();
        }
        return Optional.of(list);
    }
}
