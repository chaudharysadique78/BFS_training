package in.stackroute.lambdas;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;

public class MoreStreams {
    public static void main(String[] args) {
        List<List<Double>> nestedDoubleList = new ArrayList<>();
        List<List<Integer>> nestedIntList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            nestedDoubleList.add(DoubleStream.generate(Math::random).map(v -> v * 10).limit(25)
                    .collect(ArrayList::new, ArrayList::add, ArrayList::addAll));
        }
        for (int i = 0; i < 5; i++) {
            nestedIntList.add(IntStream.generate(
                            () -> (int) (Math.random() * 1000)).limit(25)
                    .collect(ArrayList::new, ArrayList::add, ArrayList::addAll));
        }

//        workWithIntStream(nestedIntList);
        workWithDoubleStream(nestedDoubleList);

    }

    static void workWithIntStream(List<List<Integer>> nestedIntList) {

        // Summarize the nested list
        IntSummaryStatistics statistics = nestedIntList.stream().flatMapToInt(list -> list.stream().mapToInt(Integer::intValue)).summaryStatistics();
        System.out.println("Summary statistics:");
        System.out.println("Count: " + statistics.getCount());
        System.out.println("Sum: " + statistics.getSum());
        System.out.println("Min: " + statistics.getMin());
        System.out.println("Max: " + statistics.getMax());
        System.out.println("Average: " + statistics.getAverage());


    }

    static void workWithDoubleStream(List<List<Double>> nestedList) {
        // Print the nested list
        nestedList.forEach(System.out::println);

        // Print the sum of all elements in the nested list
        double sum = nestedList.stream().flatMapToDouble(list -> list.stream().mapToDouble(Double::doubleValue)).sum();
        System.out.println("Sum of all elements: " + sum);

        // Print the sum of each element in the nested list
        System.out.println("Sum of each element:");
        nestedList.stream().mapToDouble(list -> list.stream().mapToDouble(Double::doubleValue).sum()).forEach(System.out::println);

        // Calculate the summary statistics of the nested list
        System.out.println("Summary statistics:");
        DoubleSummaryStatistics statistics = nestedList.stream().flatMapToDouble(list -> list.stream().mapToDouble(Double::doubleValue)).summaryStatistics();
        System.out.println("Count: " + statistics.getCount());
        System.out.println("Sum: " + statistics.getSum());
        System.out.println("Min: " + statistics.getMin());
        System.out.println("Max: " + statistics.getMax());
        System.out.println("Average: " + statistics.getAverage());

        // Print the sum of all elements in the nested list using reduce
        double sumReduce = nestedList.stream()
                .flatMapToDouble(list -> list.stream().mapToDouble(Double::doubleValue)).reduce(0, Double::sum);
        System.out.println("Sum of all elements using reduce: " + sumReduce);

        // Print the sum of each element in the nested list using reduce
        System.out.println("Sum of each element using reduce:");
        nestedList.stream().mapToDouble(list -> list.stream().mapToDouble(Double::doubleValue).reduce(0, Double::sum)).forEach(System.out::println);
    }
}
