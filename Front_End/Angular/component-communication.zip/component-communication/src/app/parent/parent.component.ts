import { Component } from '@angular/core';
import { DatamgmtService } from '../datamgmt.service';
import { TestService } from '../test.service';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrl: './parent.component.css'
})
export class ParentComponent {
  constructor(private ser:DatamgmtService,private testobj:TestService){} // injection of service in component
recieveData(data:any)
{
  alert(data.country+" "+data.state);
 alert(this.ser.nameOfEmp);
 this.testobj.showMsg();
}

}
