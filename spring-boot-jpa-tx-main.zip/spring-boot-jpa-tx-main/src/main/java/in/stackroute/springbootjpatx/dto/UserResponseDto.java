package in.stackroute.springbootjpatx.dto;

public record UserResponseDto(int id, String name, String email, org.springframework.http.HttpStatusCode code) {
}
