import { Component } from '@angular/core';
import { product } from '../product';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Day2Project';

  products:product[]=[
    {pname:"mobile",qty:20,price:400},
    {pname:"TV",qty:10,price:500},
    {pname:"M oven",qty:4,price:300}
  ]
  
  wid:any='background-color:green';
  
  imgPath='../assets/building.jpg';
  isEnb=true;
   change()
  {
    this.isEnb=false;
  }

}


