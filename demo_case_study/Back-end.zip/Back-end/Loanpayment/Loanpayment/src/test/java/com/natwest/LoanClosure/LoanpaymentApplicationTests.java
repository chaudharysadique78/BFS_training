package com.natwest.LoanClosure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanpaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
