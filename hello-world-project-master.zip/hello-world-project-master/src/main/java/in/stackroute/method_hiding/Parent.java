package in.stackroute.method_hiding;

public class Parent {

    public void hello() {
        System.out.println("Hello from Parent");
    }

    public static void method() {
        System.out.println("Parent static method");
    }
}
