import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FruitcardComponent } from './fruitcard.component';

describe('FruitcardComponent', () => {
  let component: FruitcardComponent;
  let fixture: ComponentFixture<FruitcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FruitcardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FruitcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
