package in.stackroute.bookservice.controller;

import in.stackroute.bookservice.domain.Book;
import in.stackroute.bookservice.dto.AuthorDto;
import in.stackroute.bookservice.dto.BookDto;
import in.stackroute.bookservice.clients.restclient.AuthorServiceRestClient;
import in.stackroute.bookservice.clients.resttemplate.AuthorServiceRestTemplateClient;
import in.stackroute.bookservice.clients.feign.AuthorServiceFeignClient;
import in.stackroute.bookservice.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/v1/book")
@Slf4j
public class BookController {

    private final BookService bookService;
    private final AuthorServiceRestTemplateClient authorServiceRTClient;
    private final AuthorServiceRestClient authorServiceRestClient;
    private final AuthorServiceFeignClient authorServiceFeignClient;

    public BookController(BookService bookService, AuthorServiceRestTemplateClient authorService, AuthorServiceRestClient authorServiceRestClient, AuthorServiceFeignClient authorServiceClient) {
        this.bookService = bookService;
        this.authorServiceRTClient = authorService;
        this.authorServiceRestClient = authorServiceRestClient;
        this.authorServiceFeignClient = authorServiceClient;
    }

    // POST - Create a new Author
    @PostMapping("/author")
    public ResponseEntity<AuthorDto> saveAuthor(@RequestBody AuthorDto request) {
        // Convert the request to Author Entity and save it
//        var author = authorServiceClient.createAuthorViaFeignClient(request);
//        var author = authorServiceRTClient.postAuthorViaRestTemplate(request);
        var author = authorServiceRestClient.postAuthorViaRestClient(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(author);
    }

    // POST - Create a new Book
    @PostMapping
    public ResponseEntity<BookDto> saveBook(@RequestBody BookDto request) {
        // Convert the request to Book Entity and save it
        Book book = convertToBook(request);
        // Get author data from the author service
//        var author = authorServiceRTClient.getAuthorByIdViaRestTemplate(request.authorId()); // Using RestTemplate
//        var author = authorServiceRestClient.getAuthorByIdViaRestClient(request.authorId()); // Using RestClient
        var author = authorServiceFeignClient.getAuthorByIdViaFeignClient(request.authorId()); // Using FeignClient
        log.debug("Author data: {}", author);
        book.setAuthorName(author.name());
        book = bookService.saveBook(book);
        var response = convertToBookDto(book);
        // Return the response
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookService.getAllBooks());
    }

//    @PostMapping
//    public void saveFile(@RequestPart("file") MultipartFile file){}

    private BookDto convertToBookDto(Book book) {
        return new BookDto(book.getId(), book.getTitle(), book.getAuthorName(), book.getGenre(), book.getAuthorName());
    }

    private Book convertToBook(BookDto request) {
        return new Book(request.title(), request.authorName(), request.genre());
    }
}
