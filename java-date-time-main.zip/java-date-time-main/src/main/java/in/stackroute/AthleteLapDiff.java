package in.stackroute;

import java.time.Duration;

public record AthleteLapDiff(String name, Duration fastestTotalTime, Duration difference) {
}
