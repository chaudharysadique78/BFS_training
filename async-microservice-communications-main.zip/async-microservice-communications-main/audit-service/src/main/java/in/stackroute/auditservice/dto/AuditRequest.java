package in.stackroute.auditservice.dto;

public record AuditRequest(String auditMessage) {
}
