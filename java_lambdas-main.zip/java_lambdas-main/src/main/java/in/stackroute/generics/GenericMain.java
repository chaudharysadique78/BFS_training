package in.stackroute.generics;

import java.util.List;

public class GenericMain {

    public static void main(String[] args) {
        // Create a list of integers
        List<Integer> integers = List.of(1, 2, 3, 4, 5);
        System.out.println("Sum of integers: " + sum(integers));
        // Create a list of doubles
        List<Double> doubles = List.of(1.1, 2.2, 3.3, 4.4, 5.5);
        System.out.println("Sum of doubles: " + sum(doubles));
        // List of numbers
        List<Number> numbers = List.of(1, 2.2, 3, 4.4, 5);
        System.out.println("Sum of numbers: " + sum(numbers));

        print(integers);
        print(numbers);

        // print(doubles); // Compilation error -> Double is not a super type of Integer

    }

    /**
     * Lower bounded wildcard
     */
    public static void print(List<? super Integer> list) {
        System.out.println(list);
    }

    /**
     * Upper bounded wildcard
     */
    public static double sum(List<? extends Number> numbers) {
        double sum = 0.0;
        for (Number number : numbers) {
            sum += number.doubleValue();
        }
        return sum;
    }

}
