package com.aws.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aws.demo.dto.Product;
import com.aws.demo.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController 
{
	@Autowired
	private ProductService productService;
	
	// Add a product
	@PostMapping(produces = "application/json", consumes = "application/json")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		productService.addProduct(product);
		return new ResponseEntity(product, HttpStatus.CREATED);
	}
	
	// Get all products
	@GetMapping(produces = "application/json")
	public ResponseEntity<List<Product>> getProducts() {
		return new ResponseEntity(productService.getProducts(), HttpStatus.OK);
	}
	
	// Get a product by id
	@GetMapping(value = "/{id}", produces = "application/json")
	public ResponseEntity<Product> getProduct(@PathVariable String id) {
		Product product = productService.getProduct(id);
		if (product == null) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(product, HttpStatus.OK);
	}
	
	// Delete a product by id
	@DeleteMapping(value = "/{id}")
	public ResponseEntity deleteProduct(@PathVariable String id) {
		Product product = productService.getProduct(id);
		if (product == null) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		productService.deleteProduct(id);
		return new ResponseEntity(HttpStatus.NO_CONTENT);
	}
	
	// Update a product by id
	@PostMapping(value = "/{id}", produces = "application/json", consumes = "application/json")
	public ResponseEntity updateProduct(@PathVariable String id, @RequestBody Product product) {
		Product existingProduct = productService.getProduct(id);
		if (existingProduct == null) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		productService.updateProduct(id, product);
		return new ResponseEntity(HttpStatus.NO_CONTENT);
	}
}
