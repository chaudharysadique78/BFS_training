import React from 'react';
import {
  MDBFooter

} 
from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import './Footr.css';


export default function Footr() {
  return (
    <MDBFooter>
      <br/>
      <hr style={{ borderTop: '5px solid purple' }} />
      <div className='footr' >
        <a className='fp'> Legal Info </a>
        <a className='fp'>Security Centre </a>
        <a className='fp'> Privacy & Cookies </a>
        <a className='fp'> Accessibility </a>
        <br/>
        <a className='text-reset fw-bold' href='https://mdbootstrap.com/'>
        © 2005-2023 National Westminster Bank plc
        </a>
      </div>

    </MDBFooter>
  );
}