package in.stackroute.creational.builder;

public class PaymentGateway {

    private PaymentBuilder builder;

    public PaymentGateway(PaymentBuilder builder) {
        this.builder = builder;
    }

    public Payment buildCreditCardPayment() {
        return builder.setAmount(1000)
                .setCurrency("USD")
                .setPaymentMode("Credit Card")
                .setRecipient("John")
                .setSender("Doe")
                .build();
    }

    public Payment buildPayPalPayment() {
        return builder.setAmount(1000)
                .setCurrency("USD")
                .setPaymentMode("PayPal")
                .setRecipient("John")
                .setSender("Doe")
                .build();
    }
}
