package in.stackroute.inventoryservice.config;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI inventoryApi() {
        return new OpenAPI()
                .info(
                        new Info()
                                .title("Inventory API")
                                .description("Inventory API for managing products")
                                .version("v1")
                                .license(new License().name("Apache 2.0"))
                                .contact(new Contact().name("Stackroute").email("support@stackroute.in"))
                )
                .externalDocs(
                        new ExternalDocumentation()
                                .description("Inventory API Documentation")
                                .url("https://stackroute.in")
                );
    }
}
