package com.fegc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadNotesFgmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
