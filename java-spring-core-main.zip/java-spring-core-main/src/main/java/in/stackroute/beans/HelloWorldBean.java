package in.stackroute.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class HelloWorldBean implements DisposableBean, InitializingBean {

    private String message = "Hello World";

    public HelloWorldBean() {
        System.out.println("HelloWorldBean constructor called");
    }

    public HelloWorldBean(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public void destroy() {
        System.out.println("Bean will destroy now.");
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("Bean is going through afterPropertiesSet.");
        message = "Hello World! afterPropertiesSet";
    }
}
