package in.stackroute.persons;

//@FunctionalInterface
public interface CheckPerson {
    boolean test(Person p);
}

class AgeGreater implements CheckPerson {

    private int age;

    public AgeGreater(int age) {
        this.age = age;
    }
    @Override
    public boolean test(Person p) {
        return p.getAge() > age;
    }
}

class AgeBetween implements CheckPerson {

    private int min;

    private int max;

    public AgeBetween(int min, int max) {
        this.min = min;
        this.max = max;
    }

    @Override
    public boolean test(Person p) {
        return p.getAge() >= min && p.getAge() <= max;
    }
}
