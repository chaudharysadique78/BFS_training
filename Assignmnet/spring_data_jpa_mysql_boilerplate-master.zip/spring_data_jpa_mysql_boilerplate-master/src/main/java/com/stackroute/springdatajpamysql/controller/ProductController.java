package com.stackroute.springdatajpamysql.controller;

import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/product")
public class ProductController {
    // Add controllers here for CRUD operations on Product entity.

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getProductById(@PathVariable Long productId) {
        Product product = productService.getProductById(productId);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> saveProduct(Product product) {
        Product saveProduct = productService.saveProduct(product);
        return new ResponseEntity<>(saveProduct, HttpStatus.OK);
    }

    @PostMapping("/{id}")
    public ResponseEntity<?> updateProduct(Product updatedProduct,@PathVariable Long productId) {
        Product updateProduct = productService.updateProduct(updatedProduct, productId);
        return new ResponseEntity<>(updateProduct, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable Long productId) {
        productService.deleteProduct(productId);
        return new ResponseEntity<>("Product Deleted",HttpStatus.OK);
    }
@GetMapping("/lessThanPrice/{price}")
    public ResponseEntity<?> getAllProductsHavingPriceLessThan(@PathVariable double price) {
    List<Product> allProductsHavingPriceLessThan = productService.getAllProductsHavingPriceLessThan(price);
    return new ResponseEntity<>(allProductsHavingPriceLessThan,HttpStatus.OK);
    }

    public ResponseEntity<?> getAllProducts() {
        List<Product> allProducts = productService.getAllProducts();
        return new ResponseEntity<>(allProducts,HttpStatus.OK);
    }
}
