import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrl: './child.component.css'
})
export class ChildComponent {

  obj:any={country:'India',state:'Maharashtra'};
  @Output()
  childem:EventEmitter<any>=new EventEmitter();
 

  showDataCtoP()
  {
    this.childem.emit(this.obj);
   
    
  }


}
