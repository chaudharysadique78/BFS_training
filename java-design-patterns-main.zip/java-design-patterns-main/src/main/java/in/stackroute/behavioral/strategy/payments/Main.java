package in.stackroute.behavioral.strategy.payments;

public class Main {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext(new PayPalStrategy("ashish"));
        paymentContext.pay(1000);

        paymentContext.setPaymentStrategy(new CreditCardStrategy(123, "1234567890"));
        paymentContext.pay(2000);
    }
}
