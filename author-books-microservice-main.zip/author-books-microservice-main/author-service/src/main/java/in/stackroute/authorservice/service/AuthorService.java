package in.stackroute.authorservice.service;

import in.stackroute.authorservice.domain.Author;

import java.util.List;
import java.util.Optional;

public interface AuthorService {

    List<Author> findByGenreIn(List<String> genre);

    Author saveAuthor(Author author);

    List<Author> getAllAuthors();

    Optional<Author> getAuthorById(String id);

    Author updateAuthor(Author author);

    void deleteAuthor(Author author);

    List<Author> getAuthorsByName(String name);

}
