package in.stackroute.creational.builder;

public class PaymentBuilder implements Builder {

    private final Payment payment;

    public PaymentBuilder() {
        payment = new Payment();
    }

    @Override
    public Builder setAmount(double amount) {
        payment.setAmount(amount);
        return this;
    }

    @Override
    public Builder setPaymentMode(String paymentMode) {
        payment.setPaymentMode(paymentMode);
        return this;
    }

    @Override
    public Builder setCurrency(String currency) {
        payment.setCurrency(currency);
        return this;
    }

    @Override
    public Builder setRecipient(String recipient) {
        payment.setRecipient(recipient);
        return this;
    }

    @Override
    public Builder setSender(String sender) {
        payment.setSender(sender);
        return this;
    }

    @Override
    public Payment build() {
        return payment;
    }
}
