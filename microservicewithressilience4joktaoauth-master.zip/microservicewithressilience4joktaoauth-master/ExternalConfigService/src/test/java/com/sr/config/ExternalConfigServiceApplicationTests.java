package com.sr.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExternalConfigServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
