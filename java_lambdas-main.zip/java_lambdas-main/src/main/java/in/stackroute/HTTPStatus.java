package in.stackroute;

public enum HTTPStatus {

    OK(200, "Success"),
    CREATED(201, "Created"),
    REDIRECT(301, "Redirecting"),
    FORBIDDEN(403, "Access denied");

    private final int code;
    private final String status;

    HTTPStatus(int code, String status){
        System.out.println("HTTPStatus constructor called");
        this.code = code;
        this.status = status;
    }

    public int getCode(){
        return code;
    }

    public String getStatus(){
        return status;
    }

}
