package com.natwest.complimentform.repository;


import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.natwest.complimentform.modal.ComplimentForm;

public interface CompFormRepository extends MongoRepository<ComplimentForm, ObjectId> {

}
