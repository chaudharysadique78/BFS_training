package in.stackroute;

public non-sealed class Circle extends Shape {
}
