package com.natwest.rs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.natwest.rs.model.Request;
@Repository
public interface IRequestRepo extends JpaRepository<Request, String> {

}
