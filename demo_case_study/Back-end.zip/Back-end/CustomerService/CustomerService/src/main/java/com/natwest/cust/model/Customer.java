package com.natwest.cust.model;

import jakarta.persistence.Entity;

import jakarta.persistence.Id;

@Entity
public class Customer {
	
	@Id
	private int customerid;
	private String name;
	private String dateofbirth;
	private String emailid;
	private String address;
	private String accountno;
	private int sortcode;
	private String mobileno;
	private String password;
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAccountno() {
		return accountno;
	}
	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}
	public int getSortcode() {
		return sortcode;
	}
	public void setSortcode(int sortcode) {
		this.sortcode = sortcode;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", name=" + name + ", dateofbirth=" + dateofbirth + ", emailid="
				+ emailid + ", address=" + address + ", accountno=" + accountno + ", sortcode=" + sortcode
				+ ", mobileno=" + mobileno + ", password=" + password + "]";
	}
	
	
}

