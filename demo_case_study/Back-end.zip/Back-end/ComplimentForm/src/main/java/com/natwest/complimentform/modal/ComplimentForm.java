package com.natwest.complimentform.modal;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;





@Document
public class ComplimentForm {

	@Id
    private ObjectId _id;
    private String fullName;
    private String mobileNumber;
//    private boolean isExistingCustomer;
    private String complimentMessage;
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
//	public boolean isExistingCustomer() {
//		return isExistingCustomer;
//	}
//	public void setExistingCustomer(boolean isExistingCustomer) {
//		this.isExistingCustomer = isExistingCustomer;
//	}
	public String getComplimentMessage() {
		return complimentMessage;
	}
	public void setComplimentMessage(String complimentMessage) {
		this.complimentMessage = complimentMessage;
	}
	@Override
	public String toString() {
		return "ComplimentForm [_id=" + _id + ", fullName=" + fullName + ", mobileNumber=" + mobileNumber
				+ ",  complimentMessage=" + complimentMessage + "]";
	}
}
