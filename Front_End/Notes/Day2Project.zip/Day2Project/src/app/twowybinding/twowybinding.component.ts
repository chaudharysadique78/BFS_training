import { Component } from '@angular/core';

@Component({
  selector: 'app-twowybinding',
  templateUrl: './twowybinding.component.html',
  styleUrl: './twowybinding.component.css'
})
export class TwowybindingComponent {
uname:string='';
pwd:string='';

show()
{
  alert(this.uname+"  "+this.pwd);
}
}
