import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import './Trial.css';
import DashHeader from '../../WelcomePage/DashHeader/DashHeader';
import Footer from '../../HomePage/Footer/Footer';
import swal from 'sweetalert';
const Trial = () => {
  const initialValues = {
    customerid: '',
    name: '',
    email: '',
    phoneno: '',
    requestfor: '',
  };
  const validationSchema = Yup.object({
    customerid: Yup.string()
      .required('Customer ID is required')
      .max(8, 'Customer ID must be 8 characters or less'),
    name: Yup.string().required('Name is required'),
    email: Yup.string()
      .email('Invalid email address')
      .required('Email is required'),
    phoneno: Yup.string()
      .matches(/^[0-9]+$/, 'Must be a number')
      .max(10, 'Phone number must be 10 digits')
      .required('Phone number is required'),
    requestfor: Yup.string().required('Request is required'),
  });
  const handleSubmit = (values, { resetForm }) => {
    // Send the request to the backend
    fetch('http://localhost:8084/rapi/v1/addreq', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(values),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Response from the server:', data);
        // Handle success or error here
        swal('Request Registered Succesfully! We will get back to you!', { icon: 'success' });
        resetForm();
      })
      .catch((error) => {
        console.error('Error:', error);
        // Handle error here
        alert('An error occurred. Please try again later.');
      });
  };
  return (
    <div>
      <DashHeader/> <br/>
    <div className="con">
      <div className="k2">
        <h2 style={{ color:'white' }}>Request Form</h2>
      </div>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        <Form className="k1" autoComplete='off'>
          <div className="lab">
            <label htmlFor="customerid">Customer ID</label>
            <Field type="text" id="customerid" name="customerid" />
            <ErrorMessage name="customerid" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="name">Name</label>
            <Field type="text" id="name" name="name" />
            <ErrorMessage name="name" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="email">Email</label>
            <Field type="email" id="email" name="email" />
            <ErrorMessage name="email" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="phoneno">Phone Number</label>
            <Field type="text" id="phoneno" name="phoneno" />
            <ErrorMessage name="phoneno" component="div" className="error" />
          </div>
          <div className="lab">
            <label htmlFor="requestfor">Request For</label>
            <Field type="text" id="requestfor" name="requestfor" />
            <ErrorMessage name="requestfor" component="div" className="error" />
          </div>
          <button type="submit">Submit</button>
        </Form>
      </Formik>
    </div> <br/>
    <Footer/>
    </div>
  );
};
export default Trial;