package com.fegc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fegc.config.ConnectNoteMS;
import com.fegc.model.Note;

@RestController
@RequestMapping("/path")
public class NoteFGController 
{
	@Autowired
	private ConnectNoteMS connectNoteMS;


	@GetMapping("/getall")
	public List<Note> getAllNotes() 
	{
		List<Note> noteList = connectNoteMS.getAllNotes();
		
		if (noteList.isEmpty()) {
			return null;
		} else {
			return noteList;
		}
	}
}
