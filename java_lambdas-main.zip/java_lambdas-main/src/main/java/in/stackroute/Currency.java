package in.stackroute;

public enum Currency {
    USD {
        @Override
        public String getSymbol() {
            return "$";
        }
    },
    GBP {
        @Override
        public String getSymbol() {
            return "£";
        }
    },
    EUR {
        @Override
        public String getSymbol() {
            return "€";
        }
    },
    INR {
        @Override
        public String getSymbol() {
            return "₹";
        }
    };
    public abstract String getSymbol();
}

enum MoneyType {
    USD, INR, GPB
}
