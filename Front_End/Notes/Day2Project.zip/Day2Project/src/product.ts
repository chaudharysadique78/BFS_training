export interface product
{
    pname:string;
    qty:number;
    price:number;
}